# Flashbang - A free Jexactyl theme
This theme is designed to introduce a light and vibrant look to your Panel.
It's easy to install and setup, with just 4 steps required.

## 1) Install build dependencies
You need to install the packages and tools required to build Jexactyl's frontend.
You can do this with the commands below:
```bash
curl -sL https://deb.nodesource.com/setup_16.x | sudo -E bash -
apt install -y nodejs
npm i -g yarn
```
Then, navigate to the `/var/www/jexactyl/directory` and install the Yarn packages.
```bash
cd /var/www/jexactyl/
yarn
```

## 2) Add new Tailwind file
In this folder you'll find a file named `tailwind.config.js`. This file needs to be present
in your `/var/www/jexactyl` directory in order for the theme to be added. Even if a tailwind config
file already exists in this directory, overwrite it.
```bash
cd /var/www/jexactyl
rm tailwind.config.js # Delete old TailwindCSS configuration
curl -Lo tailwind.config.js https://raw.githubusercontent.com/Jexactyl/themes/main/flashbang/tailwind.config.js # Download the new config for this theme
```

## 3) Add extra theme files needed
This theme requires you to replace another file, `Console.tsx`, so the console
renders properly and can be read easily.
Doing this is straightforward and can be done with the following commands:
```bash
cd /var/www/jexactyl/resources/scripts/components/server
rm Console.tsx
curl -Lo Console.tsx https://raw.githubusercontent.com/Jexactyl/themes/main/flashbang/extra-files/Console.tsx
```
After you've gone ahead and added this file, you can move onto stage 4.

## 4) Build Jexactyl with theme installed
Once you've downloaded the new configuration file, you can rebuild the Panel.
```bash
cd /var/www/jexactyl
yarn build:production
```
This operation may take some time depending on your machines specifications.
Please make sure you meet the [requirements](https://documentation.jexactyl.com/docs/prerequisites#modifying-and-building) for building Jexactyl.

## Install complete!
Assuming you've followed all the previous steps correctly, your Panel should now have the Lights Out theme installed. Here's some screenshots of what the Panel will look like with this theme.

## Screenshots
### Server List
[![ServerList](https://raw.githubusercontent.com/Jexactyl/themes/main/flashbang/screenshots/home.png)](https://raw.githubusercontent.com/Jexactyl/themes/main/flashbang/screenshots/home.png)
### Account
[![Account](https://raw.githubusercontent.com/Jexactyl/themes/main/flashbang/screenshots/account.png)](https://raw.githubusercontent.com/Jexactyl/themes/main/flashbang/screenshots/account.png)
### Store
[![Store](https://raw.githubusercontent.com/Jexactyl/themes/main/flashbang/screenshots/store.png)](https://raw.githubusercontent.com/Jexactyl/themes/main/flashbang/screenshots/store.png)
### Console
[![Console](https://raw.githubusercontent.com/Jexactyl/themes/main/flashbang/screenshots/console.png)](https://raw.githubusercontent.com/Jexactyl/themes/main/flashbang/screenshots/console.png)
### Files
[![Files](https://raw.githubusercontent.com/Jexactyl/themes/main/flashbang/screenshots/files.png)](https://raw.githubusercontent.com/Jexactyl/themes/main/flashbang/screenshots/files.png)

