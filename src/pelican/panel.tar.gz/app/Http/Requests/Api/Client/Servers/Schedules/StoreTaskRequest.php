<?php

namespace App\Http\Requests\Api\Client\Servers\Schedules;

use App\Enums\SubuserPermission;

class StoreTaskRequest extends ViewScheduleRequest
{
    /**
     * Determine if the user is allowed to create a new task for this schedule. We simply
     * check if they can modify a schedule to determine if they're able to do this. There
     * are no task specific permissions.
     */
    public function permission(): SubuserPermission
    {
        return SubuserPermission::ScheduleUpdate;
    }

    public function rules(): array
    {
        return [
            'action' => 'required|in:command,power,backup,delete_files',
            'payload' => 'required_unless:action,backup|string|nullable',
            'time_offset' => 'required|numeric|min:0|max:900',
            'sequence_id' => 'sometimes|required|numeric|min:1',
            'continue_on_failure' => 'sometimes|required|boolean',
        ];
    }
}
