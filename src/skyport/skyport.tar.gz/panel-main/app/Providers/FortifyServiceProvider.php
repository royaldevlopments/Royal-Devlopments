<?php

namespace App\Providers;

use App\Actions\Fortify\CreateNewUser;
use App\Actions\Fortify\ResetUserPassword;
use App\Http\Responses\LoginResponse;
use App\Http\Responses\RegisterResponse;
use App\Http\Responses\TwoFactorLoginResponse;
use App\Models\User;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Str;
use Inertia\Inertia;
use Laravel\Fortify\Contracts\LoginResponse as LoginResponseContract;
use Laravel\Fortify\Contracts\RegisterResponse as RegisterResponseContract;
use Laravel\Fortify\Contracts\TwoFactorLoginResponse as TwoFactorLoginResponseContract;
use Laravel\Fortify\Features;
use Laravel\Fortify\Fortify;

class FortifyServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        $this->app->singleton(LoginResponseContract::class, LoginResponse::class);
        $this->app->singleton(RegisterResponseContract::class, RegisterResponse::class);
        $this->app->singleton(TwoFactorLoginResponseContract::class, TwoFactorLoginResponse::class);
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        $this->configureActions();
        $this->configureViews();
        $this->configureRateLimiting();
    }

    /**
     * Configure Fortify actions.
     */
    private function configureActions(): void
    {
        Fortify::resetUserPasswordsUsing(ResetUserPassword::class);
        Fortify::createUsersUsing(CreateNewUser::class);
        Fortify::authenticateUsing(function (Request $request): ?User {
            $username = $request->string(Fortify::username())->toString();
            $password = $request->string('password')->toString();

            $user = User::query()
                ->where(Fortify::username(), $username)
                ->first();

            if (! $user || ! Hash::check($password, $user->password)) {
                return null;
            }

            if ($user->isSuspended()) {
                throw new HttpResponseException(
                    Redirect::back()->withErrors([
                        Fortify::username() => 'This account is suspended.',
                    ]),
                );
            }

            return $user;
        });
    }

    /**
     * Configure Fortify views.
     */
    private function configureViews(): void
    {
        Fortify::loginView(
            fn (Request $request) => Inertia::render('auth/login', [
                'canResetPassword' => Features::enabled(
                    Features::resetPasswords(),
                ),
                'canRegister' => Features::enabled(Features::registration()),
                'canUsePasskeys' => true,
                'status' => $request->session()->get('status'),
            ]),
        );

        Fortify::resetPasswordView(
            fn (Request $request) => Inertia::render('auth/reset-password', [
                'email' => $request->email,
                'token' => $request->route('token'),
            ]),
        );

        Fortify::requestPasswordResetLinkView(
            fn (Request $request) => Inertia::render('auth/forgot-password', [
                'status' => $request->session()->get('status'),
            ]),
        );

        Fortify::registerView(fn () => Inertia::render('auth/register'));

        Fortify::twoFactorChallengeView(
            fn () => Inertia::render('auth/two-factor-challenge'),
        );

        Fortify::confirmPasswordView(
            fn () => Inertia::render('auth/confirm-password'),
        );
    }

    /**
     * Configure rate limiting.
     */
    private function configureRateLimiting(): void
    {
        RateLimiter::for('two-factor', function (Request $request) {
            return Limit::perMinute(5)->by(
                $request->session()->get('login.id'),
            );
        });

        RateLimiter::for('login', function (Request $request) {
            $throttleKey = Str::transliterate(
                Str::lower($request->input(Fortify::username())).
                    '|'.
                    $request->ip(),
            );

            return Limit::perMinute(5)->by($throttleKey);
        });

        RateLimiter::for('passkeys.login', function (Request $request) {
            return Limit::perMinute(5)->by('passkeys|'.$request->ip());
        });
    }
}
