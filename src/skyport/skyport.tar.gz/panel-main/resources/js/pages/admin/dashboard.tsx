import { Head, Link } from '@inertiajs/react';
import { Area, AreaChart, ResponsiveContainer, Tooltip } from 'recharts';
import AdminLayout from '@/layouts/admin/layout';
import AppLayout from '@/layouts/app-layout';
import { index as adminServers } from '@/routes/admin/servers';
import { index as adminUsers } from '@/routes/admin/users';
import type { BreadcrumbItem } from '@/types';

type ChartPoint = {
    day: string;
    amount: number;
};

type NodeInfo = {
    name: string;
    fqdn: string;
    status: string;
    servers_count: number;
    allocations_count: number;
    last_seen_at: string | null;
};

type Props = {
    recentUsers: ChartPoint[];
    recentUsersTotal: number;
    usersTrendText: string;
    recentServers: ChartPoint[];
    recentServersTotal: number;
    serversTrendText: string;
    nodes: NodeInfo[];
    totalNodes: number;
    totalMemoryMib: number;
    totalDiskMib: number;
    version: string;
    commit: string;
};

function ChartTooltip({
    active,
    payload,
    label,
}: {
    active?: boolean;
    payload?: { payload: ChartPoint }[];
    label?: string;
}) {
    if (!active || !payload?.length) {
        return null;
    }

    const { day, amount } = payload[0].payload;

    return (
        <div className="rounded-md border border-sidebar-accent bg-background px-2.5 py-1.5 shadow-md">
            <p className="text-xs font-medium text-foreground">
                {amount} {label ?? 'items'}
            </p>
            <p className="text-xs text-muted-foreground">{day}</p>
        </div>
    );
}

function ChartCard({
    title,
    subtitle,
    total,
    totalLabel,
    data,
    tooltipUnit,
    color,
    gradientId,
    footerText,
    footerLink,
    footerLinkLabel,
}: {
    title: string;
    subtitle: string;
    total: number;
    totalLabel: string;
    data: ChartPoint[];
    tooltipUnit: string;
    color: string;
    gradientId: string;
    footerText: string;
    footerLink: string;
    footerLinkLabel: string;
}) {
    return (
        <div className="relative flex h-full flex-col gap-1 rounded-md bg-sidebar p-1">
            <div className="relative flex aspect-16/7 flex-col justify-between overflow-hidden rounded-md border border-sidebar-accent bg-background p-4">
                <div className="absolute inset-x-0 bottom-0 z-10 h-1/3 bg-linear-to-t from-background to-transparent" />
                <div className="absolute inset-x-0 bottom-0 h-2/4">
                    <ResponsiveContainer width="100%" height="100%">
                        <AreaChart
                            data={data}
                            margin={{
                                top: 0,
                                right: 0,
                                left: 0,
                                bottom: 0,
                            }}
                        >
                            <defs>
                                <linearGradient
                                    id={gradientId}
                                    x1="0"
                                    y1="0"
                                    x2="0"
                                    y2="1"
                                >
                                    <stop
                                        offset="0%"
                                        stopColor={color}
                                        stopOpacity="0.3"
                                    />
                                    <stop
                                        offset="100%"
                                        stopColor={color}
                                        stopOpacity="0"
                                    />
                                </linearGradient>
                            </defs>
                            <Tooltip
                                content={<ChartTooltip label={tooltipUnit} />}
                                cursor={{
                                    stroke: color,
                                    strokeWidth: 1,
                                    strokeDasharray: '4 4',
                                }}
                            />
                            <Area
                                type="monotone"
                                dataKey="amount"
                                stroke={color}
                                strokeWidth={2}
                                fill={`url(#${gradientId})`}
                                dot={false}
                                activeDot={{
                                    r: 4,
                                    fill: color,
                                    stroke: color,
                                    strokeWidth: 0,
                                }}
                                isAnimationActive
                                animationDuration={800}
                                animationEasing="ease-out"
                            />
                        </AreaChart>
                    </ResponsiveContainer>
                </div>
                <div className="relative">
                    <h1 className="text-md font-semibold tracking-tight text-foreground">
                        {title}
                    </h1>
                    <span className="text-xs text-muted-foreground">
                        {subtitle}
                    </span>
                </div>
                <span className="relative z-20 text-sm font-semibold text-foreground">
                    {total} {totalLabel}
                </span>
            </div>
            <div className="flex items-center justify-between px-2">
                <span className="text-xs font-medium text-muted-foreground">
                    {footerText}
                </span>
                <Link
                    href={footerLink}
                    className="rounded-md border border-sidebar-accent bg-background px-2 py-1 text-xs font-medium text-foreground transition-colors hover:bg-sidebar-accent"
                >
                    {footerLinkLabel}
                </Link>
            </div>
        </div>
    );
}

function StatCard({
    label,
    value,
    sub,
}: {
    label: string;
    value: string | number;
    sub?: string;
}) {
    return (
        <div className="flex h-full flex-col gap-1 rounded-md bg-sidebar p-1">
            <div className="rounded-md border border-sidebar-accent bg-background p-4">
                <span className="text-xs text-muted-foreground">{label}</span>
                <p className="text-2xl font-semibold tracking-tight text-foreground">
                    {value}
                </p>
                {sub && (
                    <span className="text-xs text-muted-foreground">{sub}</span>
                )}
            </div>
        </div>
    );
}

function formatMib(mib: number): string {
    if (mib >= 1024) {
        return `${(mib / 1024).toFixed(1)} GB`;
    }

    return `${mib} MB`;
}

const breadcrumbs: BreadcrumbItem[] = [
    {
        title: 'Admin',
        href: '/admin',
    },
    {
        title: 'Overview',
        href: '/admin',
    },
];

export default function AdminDashboard({
    recentUsers,
    recentUsersTotal,
    usersTrendText,
    recentServers,
    recentServersTotal,
    serversTrendText,
    nodes,
    totalNodes,
    totalMemoryMib,
    totalDiskMib,
    version,
    commit,
}: Props) {
    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <Head title="Admin — Overview" />

            <AdminLayout
                title="Overview"
                description="A quick overview of the system."
            >
                <div className="flex flex-1 flex-col gap-4 overflow-x-auto">
                    <div className="flex flex-1 rounded-md bg-sidebar p-1">
                        <div className="flex flex-1 flex-col justify-center rounded-md border border-sidebar-accent bg-background p-4">
                            <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                                <div>
                                    <h2 className="text-sm font-semibold text-foreground">
                                        Skyport Panel
                                    </h2>
                                    <p className="mt-1 text-xs text-muted-foreground">
                                        Thank you for trying out Skyport! This is a <strong>very early</strong> release, so please report any issues you find.
                                    </p>
                                </div>
                                <div className="grid gap-3 sm:grid-cols-1 p-2">
                                    <div className="min-w-40 rounded-lg">
                                        <p className="mt-1 font-mono text-sm font-medium text-foreground">
                                            skyportsh/panel @ v{version} ({commit})
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="grid auto-rows-min gap-4 md:grid-cols-3">
                        <StatCard
                            label="Nodes"
                            value={totalNodes}
                            sub={`${nodes.filter((n) => n.status === 'online').length} online`}
                        />
                        <StatCard
                            label="Memory allocated"
                            value={formatMib(totalMemoryMib)}
                            sub="Across all servers"
                        />
                        <StatCard
                            label="Disk allocated"
                            value={formatMib(totalDiskMib)}
                            sub="Across all servers"
                        />
                    </div>
                </div>
            </AdminLayout>
        </AppLayout>
    );
}
