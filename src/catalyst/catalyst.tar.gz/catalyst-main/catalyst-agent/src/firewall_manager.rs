use crate::errors::{AgentError, AgentResult};
use std::collections::HashSet;
use std::io::Write;
use std::path::Path;
use std::sync::{Mutex, OnceLock};
use std::time::Duration;
use tokio::process::Command;
use tracing::{info, warn};

async fn run_firewall_command(cmd: &str, args: &[&str]) -> AgentResult<std::process::Output> {
    let output = tokio::time::timeout(
        Duration::from_secs(30),
        Command::new(cmd).args(args).output(),
    )
    .await
    .map_err(|_| AgentError::FirewallError(format!("{} command timed out", cmd)))?
    .map_err(|e| AgentError::FirewallError(format!("Failed to run {}: {}", cmd, e)))?;
    Ok(output)
}

static IPTABLES_MUTEX: tokio::sync::Mutex<()> = tokio::sync::Mutex::const_new(());

/// Persistent state file path — set once at startup via `FirewallManager::init()`.
/// Derives from the agent's `data_dir` so that firewall rule state follows
/// the data directory when the user overrides it.
static RULE_STATE_FILE: std::sync::OnceLock<std::path::PathBuf> = std::sync::OnceLock::new();

// ---------------------------------------------------------------------------
// Firewall manager
// ---------------------------------------------------------------------------

/// Firewall manager for automatically configuring firewall rules.
pub struct FirewallManager;

#[derive(Debug, PartialEq, Clone, Copy)]
pub enum FirewallType {
    Ufw,
    Ipset,
    Iptables,
    Firewalld,
    None,
}

static DETECTED_FIREWALL: OnceLock<FirewallType> = OnceLock::new();

// ---------------------------------------------------------------------------
// Rule tracking
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct FirewallRule {
    pub port: u16,
    pub proto: String,
    pub server_id: String,
    pub container_ip: String,
}

static TRACKED_RULES: Mutex<Vec<FirewallRule>> = Mutex::new(Vec::new());

fn lock_rules() -> std::sync::MutexGuard<'static, Vec<FirewallRule>> {
    TRACKED_RULES
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner())
}

/// Return the rule state file path, panicking if init() was never called.
fn rule_state_file() -> &'static std::path::PathBuf {
    RULE_STATE_FILE
        .get()
        .expect("FirewallManager::init() was not called before using rule state")
}

/// Load tracked rules from the persistent state file, merging with any
/// already loaded in memory (used on agent startup).
fn load_tracked_rules() {
    let state_file = rule_state_file();
    let mut rules = lock_rules();
    if !rules.is_empty() {
        return; // already loaded
    }

    if !Path::new(state_file).exists() {
        return;
    }

    match std::fs::read_to_string(state_file) {
        Ok(contents) => {
            let count = contents
                .lines()
                .filter(|line| !line.trim().is_empty())
                .filter_map(|line| serde_json::from_str::<FirewallRule>(line).ok())
                .inspect(|rule| rules.push(rule.clone()))
                .count();
            if count > 0 {
                info!(
                    "Loaded {} tracked firewall rules from {}",
                    count,
                    state_file.display()
                );
            }
        }
        Err(e) => warn!("Could not load firewall rule state: {}", e),
    }
}

/// Persist tracked rules to disk.
fn save_tracked_rules() {
    let state_file = rule_state_file();
    let rules = lock_rules();
    let temp = state_file.with_extension("jsonl.tmp");
    let data = rules
        .iter()
        .map(|r| serde_json::to_string(r).unwrap_or_default())
        .collect::<Vec<_>>()
        .join("\n")
        + "\n";
    drop(rules);
    if let Err(e) = std::fs::write(&temp, data) {
        warn!("Could not save firewall rule state: {}", e);
        return;
    }
    if let Err(e) = std::fs::rename(&temp, state_file) {
        warn!("Could not atomically replace firewall rule state: {}", e);
        let _ = std::fs::remove_file(state_file.with_extension("jsonl.tmp"));
    }
}

/// Append a single rule to the state file without rewriting the whole file.
fn append_tracked_rule(rule: &FirewallRule) {
    let state_file = rule_state_file();
    let line = format!("{}\n", serde_json::to_string(rule).unwrap_or_default());
    if let Err(e) = std::fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(state_file)
        .and_then(|mut f| f.write_all(line.as_bytes()))
    {
        warn!("Could not append firewall rule state: {}", e);
    }
}

/// Record that we added a firewall rule for a server port.
/// Pure dedup-and-push logic: adds a rule to the vec only if it doesn't
/// already exist.  Used by `track_rule` (production) and unit tests.
pub(crate) fn push_dedup(rules: &mut Vec<FirewallRule>, rule: FirewallRule) -> bool {
    let exists = rules.iter().any(|r| {
        r.port == rule.port
            && r.proto == rule.proto
            && r.server_id == rule.server_id
            && r.container_ip == rule.container_ip
    });
    if !exists {
        rules.push(rule);
        true
    } else {
        false
    }
}

/// Pure retain-and-collect logic: removes all rules for a server_id and
/// returns the removed rules.  Used by `untrack_server_rules` (production)
/// and unit tests.
pub(crate) fn retain_and_collect(
    rules: &mut Vec<FirewallRule>,
    server_id: &str,
) -> Vec<FirewallRule> {
    let mut removed = Vec::new();
    rules.retain(|r| {
        if r.server_id == server_id {
            removed.push(r.clone());
            false
        } else {
            true
        }
    });
    removed
}

fn track_rule(port: u16, proto: &str, server_id: &str, container_ip: &str) {
    let mut rules = lock_rules();
    let rule = FirewallRule {
        port,
        proto: proto.to_string(),
        server_id: server_id.to_string(),
        container_ip: container_ip.to_string(),
    };
    if push_dedup(&mut rules, rule.clone()) {
        drop(rules);
        append_tracked_rule(&rule);
    }
}

/// Remove all tracked rules for a given server and return the removed rules.
fn untrack_server_rules(server_id: &str) -> Vec<FirewallRule> {
    let mut rules = lock_rules();
    let original_len = rules.len();
    let removed = retain_and_collect(&mut rules, server_id);
    if removed.len() != original_len {
        drop(rules);
        save_tracked_rules();
    }
    removed
}

// ---------------------------------------------------------------------------
// Firewall detection
// ---------------------------------------------------------------------------

impl FirewallManager {
    /// Detect which firewall is active on the system.
    /// The result is cached after the first call.
    pub async fn detect_firewall() -> FirewallType {
        if let Some(ft) = DETECTED_FIREWALL.get() {
            return *ft;
        }

        let ft = if let Ok(output) = run_firewall_command("ufw", &["status"]).await {
            let status = String::from_utf8_lossy(&output.stdout);
            if output.status.success() && status.contains("Status: active") {
                info!("Detected active UFW firewall");
                FirewallType::Ufw
            } else {
                FirewallType::None
            }
        } else {
            FirewallType::None
        };

        if ft != FirewallType::None {
            let _ = DETECTED_FIREWALL.set(ft);
            return ft;
        }

        let ft = if let Ok(output) = run_firewall_command("firewall-cmd", &["--state"]).await {
            let status = String::from_utf8_lossy(&output.stdout);
            if output.status.success() && status.contains("running") {
                info!("Detected active firewalld");
                FirewallType::Firewalld
            } else {
                FirewallType::None
            }
        } else {
            FirewallType::None
        };

        if ft != FirewallType::None {
            let _ = DETECTED_FIREWALL.set(ft);
            return ft;
        }

        let ft = if run_firewall_command("ipset", &["list"]).await.is_ok() {
            let iptables_ok = run_firewall_command("iptables", &["-L", "-n"])
                .await
                .is_ok();
            let ip6tables_ok = run_firewall_command("ip6tables", &["-L", "-n"])
                .await
                .is_ok();
            if iptables_ok || ip6tables_ok {
                if iptables_ok && ip6tables_ok {
                    info!("Using ipset + iptables/ip6tables for firewall management");
                } else if iptables_ok {
                    info!("Using ipset + iptables for firewall management");
                } else {
                    info!("Using ipset + ip6tables for firewall management");
                }
                FirewallType::Ipset
            } else {
                FirewallType::None
            }
        } else {
            FirewallType::None
        };

        if ft != FirewallType::None {
            let _ = DETECTED_FIREWALL.set(ft);
            return ft;
        }

        let ft = if run_firewall_command("iptables", &["-L", "-n"])
            .await
            .is_ok()
        {
            info!("Using iptables for firewall management");
            if run_firewall_command("ip6tables", &["-L", "-n"])
                .await
                .is_ok()
            {
                info!("ip6tables is also available");
            }
            FirewallType::Iptables
        } else if run_firewall_command("ip6tables", &["-L", "-n"])
            .await
            .is_ok()
        {
            info!("Using ip6tables for firewall management");
            FirewallType::Iptables
        } else {
            warn!("No firewall detected or iptables not available");
            FirewallType::None
        };

        let _ = DETECTED_FIREWALL.set(ft);
        ft
    }

    /// Initialize the firewall manager with the agent's data directory.
    /// Sets the persistent rule state file path to `{data_dir}/firewall-rules.jsonl`
    /// and loads any existing tracked rules from disk.
    /// Call once at startup.
    pub fn init(data_dir: &std::path::Path) {
        let state_file = data_dir.join("firewall-rules.jsonl");
        let _ = RULE_STATE_FILE.set(state_file);
        info!("Firewall rule state file: {}", rule_state_file().display());
        load_tracked_rules();
    }

    // -----------------------------------------------------------------------
    // Public API — allow / remove ports
    // -----------------------------------------------------------------------

    /// Allow a port through the detected firewall for a specific server.
    /// The rule is tracked so it can be removed later.
    pub async fn allow_port(
        port: u16,
        protocol: &str,
        container_ip: &str,
        server_id: &str,
    ) -> AgentResult<()> {
        Self::validate_container_ip(container_ip)?;

        // Always apply both tcp and udp for game servers.
        let protos = match protocol {
            "tcp" => vec!["tcp"],
            "udp" => vec!["udp"],
            _ => vec!["tcp", "udp"],
        };

        let firewall_type = Self::detect_firewall().await;
        for proto in &protos {
            let result = match firewall_type {
                FirewallType::Ufw => Self::allow_port_ufw(port).await,
                FirewallType::Firewalld => Self::allow_port_firewalld(port, proto).await,
                FirewallType::Ipset => Self::allow_port_ipset(port, proto, container_ip).await,
                FirewallType::Iptables => {
                    Self::allow_port_iptables(port, proto, container_ip).await
                }
                FirewallType::None => {
                    info!(
                        "No firewall detected, skipping allow for port {}/{}",
                        port, proto
                    );
                    Ok(())
                }
            };

            if result.is_ok() {
                track_rule(port, proto, server_id, container_ip);
            } else if let Err(e) = result {
                warn!(
                    "Firewall allow failed for port {}/{} (non-fatal): {}",
                    port, proto, e
                );
            }
        }

        Ok(())
    }

    /// Remove all firewall rules associated with a server.
    /// Called when a server is deleted or its container is removed.
    pub async fn remove_server_ports(server_id: &str) {
        let rules = untrack_server_rules(server_id);
        if rules.is_empty() {
            return;
        }

        info!(
            "Removing {} firewall rule(s) for server {}",
            rules.len(),
            server_id
        );

        let firewall_type = Self::detect_firewall().await;
        // Deduplicate by (port, proto) to avoid redundant calls.
        let mut seen: HashSet<(u16, String)> = HashSet::new();
        for rule in &rules {
            let key = (rule.port, rule.proto.clone());
            if seen.insert(key) {
                let result = match firewall_type {
                    FirewallType::Ufw => Self::remove_port_ufw(rule.port).await,
                    FirewallType::Firewalld => {
                        Self::remove_port_firewalld(rule.port, &rule.proto).await
                    }
                    FirewallType::Ipset => {
                        Self::remove_port_ipset(rule.port, &rule.proto, &rule.container_ip).await
                    }
                    FirewallType::Iptables => {
                        Self::remove_port_iptables(rule.port, &rule.proto, &rule.container_ip).await
                    }
                    FirewallType::None => Ok(()),
                };
                if let Err(e) = result {
                    warn!(
                        "Firewall remove failed for port {}/{} (non-fatal): {}",
                        rule.port, rule.proto, e
                    );
                }
            }
        }
    }

    /// Remove all tracked firewall rules on agent shutdown.
    /// This is a safety net — rules are normally removed per-server.
    pub async fn remove_all_tracked() {
        let rules: Vec<_> = {
            let guard = lock_rules();
            guard.iter().cloned().collect()
        };
        if rules.is_empty() {
            return;
        }

        info!(
            "Removing all {} tracked firewall rules (agent shutdown)",
            rules.len()
        );

        let firewall_type = Self::detect_firewall().await;
        let mut seen: HashSet<(u16, String, String)> = HashSet::new();
        for rule in &rules {
            let key = (rule.port, rule.proto.clone(), rule.container_ip.clone());
            if seen.insert(key) {
                let _ = match firewall_type {
                    FirewallType::Ufw => Self::remove_port_ufw(rule.port).await,
                    FirewallType::Firewalld => {
                        Self::remove_port_firewalld(rule.port, &rule.proto).await
                    }
                    FirewallType::Ipset => {
                        Self::remove_port_ipset(rule.port, &rule.proto, &rule.container_ip).await
                    }
                    FirewallType::Iptables => {
                        Self::remove_port_iptables(rule.port, &rule.proto, &rule.container_ip).await
                    }
                    FirewallType::None => Ok(()),
                };
            }
        }
    }

    /// Allow traffic to a specific container IP (FORWARD rules only, no INPUT).
    /// Used by iptables-based setups for macvlan/bridge networking.
    pub async fn allow_container_ip(container_ip: &str) -> AgentResult<()> {
        Self::validate_container_ip(container_ip)?;
        let firewall_type = Self::detect_firewall().await;

        match firewall_type {
            FirewallType::Ufw | FirewallType::Firewalld | FirewallType::None => {
                // UFW and firewalld handle forwarding internally.
                // No FORWARD rules needed for port-based allow rules.
                Ok(())
            }
            FirewallType::Ipset | FirewallType::Iptables => {
                Self::allow_container_ip_iptables(container_ip).await
            }
        }
    }

    /// Remove FORWARD rules for a container IP.
    pub async fn remove_container_ip(container_ip: &str) -> AgentResult<()> {
        Self::validate_container_ip(container_ip)?;
        let firewall_type = Self::detect_firewall().await;

        match firewall_type {
            FirewallType::Ufw | FirewallType::Firewalld | FirewallType::None => Ok(()),
            FirewallType::Ipset | FirewallType::Iptables => {
                Self::remove_container_ip_iptables(container_ip).await
            }
        }
    }

    // -----------------------------------------------------------------------
    // UFW implementation
    // -----------------------------------------------------------------------

    /// Allow a port through UFW.
    ///
    /// Uses a comment tag so we can identify our rules later.
    async fn allow_port_ufw(port: u16) -> AgentResult<()> {
        info!("Configuring UFW to allow port {}", port);

        let output = run_firewall_command(
            "ufw",
            &[
                "allow",
                &port.to_string(),
                "comment",
                "catalyst-game-server",
            ],
        )
        .await?;

        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr);
            return Err(AgentError::FirewallError(format!(
                "UFW allow failed: {}",
                stderr
            )));
        }

        // No need to reload — `ufw allow` applies immediately.
        info!("✓ UFW configured to allow port {}", port);
        Ok(())
    }

    /// Remove a UFW rule by comment.  We search numbered rules to find the
    /// one with our comment and delete it by number, which avoids the
    /// interactive `y/N` prompt that `ufw delete allow` would produce.
    async fn remove_port_ufw(port: u16) -> AgentResult<()> {
        info!("Removing UFW rule for port {}", port);

        // List rules with numbers and find ours.
        let output = run_firewall_command("ufw", &["status", "numbered"]).await?;

        if !output.status.success() {
            warn!(
                "Could not list UFW rules, skipping removal for port {}",
                port
            );
            return Ok(());
        }

        let stdout = String::from_utf8_lossy(&output.stdout);
        // Collect rule numbers that match our port AND have the catalyst comment.
        // UFW numbered output looks like:
        //   [ 1] 25565/tcp    ALLOW IN    Anywhere                   (catalyst-game-server)
        // We need to parse from bottom to top when deleting.
        let mut matching_numbers: Vec<String> = Vec::new();
        for line in stdout.lines() {
            if (line.contains(&format!("{}/tcp", port)) || line.contains(&format!("{}/udp", port)))
                && line.contains("catalyst-game-server")
            {
                // Extract the number between [ and ].
                if let Some(start) = line.find('[') {
                    if let Some(end) = line[start..].find(']') {
                        let num = line[start + 1..start + end].trim();
                        matching_numbers.push(num.to_string());
                    }
                }
            }
        }

        if matching_numbers.is_empty() {
            info!("No UFW rule found for port {}", port);
            return Ok(());
        }

        // Delete from highest number to lowest to avoid index shifting.
        matching_numbers.sort_by(|a, b| b.cmp(a));
        for num in &matching_numbers {
            let output = run_firewall_command("ufw", &["delete", num]).await?;

            if output.status.success() {
                info!("✓ Removed UFW rule #{}", num);
            } else {
                warn!(
                    "Failed to remove UFW rule #{}: {}",
                    num,
                    String::from_utf8_lossy(&output.stderr)
                );
            }
        }

        Ok(())
    }

    // -----------------------------------------------------------------------
    // firewalld implementation
    // -----------------------------------------------------------------------

    async fn allow_port_firewalld(port: u16, protocol: &str) -> AgentResult<()> {
        info!("Configuring firewalld to allow port {}/{}", port, protocol);

        let output = run_firewall_command(
            "firewall-cmd",
            &[
                "--permanent",
                "--add-port",
                &format!("{}/{}", port, protocol),
            ],
        )
        .await?;

        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr);
            return Err(AgentError::FirewallError(format!(
                "firewalld add failed: {}",
                stderr
            )));
        }

        Self::reload_firewalld().await?;

        info!("✓ firewalld configured to allow port {}/{}", port, protocol);
        Ok(())
    }

    async fn remove_port_firewalld(port: u16, protocol: &str) -> AgentResult<()> {
        info!("Removing firewalld rule for port {}/{}", port, protocol);

        let output = run_firewall_command(
            "firewall-cmd",
            &[
                "--permanent",
                "--remove-port",
                &format!("{}/{}", port, protocol),
            ],
        )
        .await?;

        if !output.status.success() {
            warn!(
                "Failed to remove firewalld rule for port {}/{} (may not exist)",
                port, protocol
            );
            // Don't return error — try reload anyway.
        }

        Self::reload_firewalld().await?;
        Ok(())
    }

    async fn reload_firewalld() -> AgentResult<()> {
        let output = run_firewall_command("firewall-cmd", &["--reload"]).await?;
        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr);
            return Err(AgentError::FirewallError(format!(
                "firewalld reload failed: {}",
                stderr
            )));
        }
        Ok(())
    }

    // -----------------------------------------------------------------------
    // iptables implementation
    // -----------------------------------------------------------------------

    /// Add idempotent iptables rules using the `catalyst` comment match.
    /// `-C` checks first to avoid duplicates.
    async fn allow_port_iptables(port: u16, protocol: &str, container_ip: &str) -> AgentResult<()> {
        let cmd = Self::iptables_cmd(container_ip);
        info!(
            "Configuring {} to allow port {}/{} for container {}",
            cmd, port, protocol, container_ip
        );
        let port_str = port.to_string();

        // INPUT rule — allow traffic to the host port.
        Self::iptables_ensure_rule(
            cmd,
            &[
                "-I",
                "INPUT",
                "-p",
                protocol,
                "--dport",
                &port_str,
                "-m",
                "comment",
                "--comment",
                "catalyst-game-server",
                "-j",
                "ACCEPT",
            ],
        )
        .await?;

        // FORWARD rule — incoming to container.
        Self::iptables_ensure_rule(
            cmd,
            &[
                "-I",
                "FORWARD",
                "-p",
                protocol,
                "--dport",
                &port_str,
                "-d",
                container_ip,
                "-m",
                "comment",
                "--comment",
                "catalyst-game-server",
                "-j",
                "ACCEPT",
            ],
        )
        .await?;

        // FORWARD rule — outgoing from container.
        Self::iptables_ensure_rule(
            cmd,
            &[
                "-I",
                "FORWARD",
                "-p",
                protocol,
                "--sport",
                &port_str,
                "-s",
                container_ip,
                "-m",
                "comment",
                "--comment",
                "catalyst-game-server",
                "-j",
                "ACCEPT",
            ],
        )
        .await?;

        info!(
            "✓ {} configured to allow port {}/{} for container {}",
            cmd, port, protocol, container_ip
        );
        Ok(())
    }

    /// Remove iptables rules by comment match.  Parses all rule numbers in
    /// one pass and deletes from highest to lowest to avoid O(n²) behaviour.
    async fn remove_port_iptables(
        port: u16,
        protocol: &str,
        container_ip: &str,
    ) -> AgentResult<()> {
        let cmd = Self::iptables_cmd(container_ip);
        info!(
            "Removing {} rules for port {}/{} container {}",
            cmd, port, protocol, container_ip
        );
        let port_str = port.to_string();

        for chain in &["INPUT", "FORWARD"] {
            let output = run_firewall_command(cmd, &["-L", chain, "-n", "--line-numbers"]).await?;

            if !output.status.success() {
                continue;
            }

            let stdout = String::from_utf8_lossy(&output.stdout);
            let mut numbers: Vec<usize> = Vec::new();
            for line in stdout.lines() {
                if line.contains("catalyst-game-server")
                    && line.contains(&port_str)
                    && line.contains(protocol)
                {
                    if let Some(num_str) = line.split_whitespace().next() {
                        if let Ok(num) = num_str.parse::<usize>() {
                            numbers.push(num);
                        }
                    }
                }
            }

            // Delete from highest number to lowest to avoid index shifting
            numbers.sort_unstable_by(|a, b| b.cmp(a));
            numbers.dedup();
            for num in numbers {
                let _ = run_firewall_command(cmd, &["-D", chain, &num.to_string()]).await;
            }
        }

        Ok(())
    }

    /// Allow all traffic to/from a container IP in the FORWARD chain.
    async fn allow_container_ip_iptables(container_ip: &str) -> AgentResult<()> {
        let cmd = Self::iptables_cmd(container_ip);
        let rules: &[(&str, &[&str])] = &[
            (
                "incoming",
                &[
                    "-I",
                    "FORWARD",
                    "-d",
                    container_ip,
                    "-j",
                    "ACCEPT",
                    "-m",
                    "comment",
                    "--comment",
                    "catalyst-container",
                ],
            ),
            (
                "outgoing",
                &[
                    "-I",
                    "FORWARD",
                    "-s",
                    container_ip,
                    "-j",
                    "ACCEPT",
                    "-m",
                    "comment",
                    "--comment",
                    "catalyst-container",
                ],
            ),
        ];
        for (args_desc, args) in rules {
            Self::iptables_ensure_rule(cmd, args)
                .await
                .map_err(|e| {
                    warn!(
                        "{} FORWARD {} rule for {} failed (non-fatal): {}",
                        cmd, args_desc, container_ip, e
                    );
                    e
                })
                .ok();
        }
        Ok(())
    }

    async fn remove_container_ip_iptables(container_ip: &str) -> AgentResult<()> {
        let cmd = Self::iptables_cmd(container_ip);
        for chain in &["FORWARD"] {
            loop {
                let output =
                    run_firewall_command(cmd, &["-L", chain, "-n", "--line-numbers"]).await?;

                if !output.status.success() {
                    break;
                }

                let stdout = String::from_utf8_lossy(&output.stdout);
                let mut found_num: Option<usize> = None;

                for line in stdout.lines() {
                    if line.contains("catalyst-container") && (line.contains(container_ip)) {
                        if let Some(num_str) = line.split_whitespace().next() {
                            if let Ok(num) = num_str.parse::<usize>() {
                                found_num = Some(num);
                                break;
                            }
                        }
                    }
                }

                match found_num {
                    Some(num) => {
                        let output =
                            run_firewall_command(cmd, &["-D", chain, &num.to_string()]).await?;
                        if !output.status.success() {
                            break;
                        }
                    }
                    None => break,
                }
            }
        }
        Ok(())
    }

    /// Ensure an iptables rule exists — uses `-C` to check first, only
    /// inserts if missing (idempotent).  Uses a mutex to prevent races
    /// between the check and the insert.
    async fn iptables_ensure_rule(cmd: &str, args: &[&str]) -> AgentResult<()> {
        let _guard = IPTABLES_MUTEX.lock().await;

        // Build the check command: replace -I with -C.
        let mut check_args: Vec<&str> = Vec::with_capacity(args.len());
        for arg in args {
            if *arg == "-I" {
                check_args.push("-C");
            } else {
                check_args.push(arg);
            }
        }

        let check = run_firewall_command(cmd, &check_args).await;
        if let Ok(output) = check {
            if output.status.success() {
                return Ok(()); // rule already exists
            }
        }

        // Rule doesn't exist — insert it.
        let output = run_firewall_command(cmd, args).await?;

        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr);
            Err(AgentError::FirewallError(format!(
                "{} failed: {}",
                cmd, stderr
            )))
        } else {
            Ok(())
        }
    }

    // -----------------------------------------------------------------------
    // ipset implementation
    // -----------------------------------------------------------------------

    async fn allow_port_ipset(port: u16, _protocol: &str, container_ip: &str) -> AgentResult<()> {
        let _guard = IPTABLES_MUTEX.lock().await;
        let cmd = Self::iptables_cmd(container_ip);

        // Ensure the ipset exists
        let create = run_firewall_command(
            "ipset",
            &[
                "create",
                "catalyst_ports",
                "bitmap:port",
                "range",
                "1-65535",
                "-exist",
            ],
        )
        .await?;
        if !create.status.success() {
            let stderr = String::from_utf8_lossy(&create.stderr);
            return Err(AgentError::FirewallError(format!(
                "ipset create failed: {}",
                stderr
            )));
        }

        // Ensure iptables/ip6tables references the set (INPUT and FORWARD)
        for chain in &["INPUT", "FORWARD"] {
            let check = run_firewall_command(
                cmd,
                &[
                    "-C",
                    chain,
                    "-m",
                    "set",
                    "--match-set",
                    "catalyst_ports",
                    "dst",
                    "-j",
                    "ACCEPT",
                ],
            )
            .await;
            if check.is_err() || !check.unwrap().status.success() {
                let _ = run_firewall_command(
                    cmd,
                    &[
                        "-I",
                        chain,
                        "-m",
                        "set",
                        "--match-set",
                        "catalyst_ports",
                        "dst",
                        "-j",
                        "ACCEPT",
                    ],
                )
                .await;
            }
        }

        let output = run_firewall_command(
            "ipset",
            &["add", "catalyst_ports", &port.to_string(), "-exist"],
        )
        .await?;
        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr);
            return Err(AgentError::FirewallError(format!(
                "ipset add failed: {}",
                stderr
            )));
        }

        info!("✓ ipset configured to allow port {}", port);
        Ok(())
    }

    async fn remove_port_ipset(port: u16, _protocol: &str, _container_ip: &str) -> AgentResult<()> {
        let _guard = IPTABLES_MUTEX.lock().await;
        let output = run_firewall_command(
            "ipset",
            &["del", "catalyst_ports", &port.to_string(), "-exist"],
        )
        .await?;
        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr);
            return Err(AgentError::FirewallError(format!(
                "ipset del failed: {}",
                stderr
            )));
        }
        Ok(())
    }

    // -----------------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------------

    fn validate_container_ip(container_ip: &str) -> AgentResult<()> {
        container_ip
            .parse::<std::net::IpAddr>()
            .map_err(|_| AgentError::InvalidRequest("Invalid container IP".to_string()))?;
        Ok(())
    }

    fn iptables_cmd(ip: &str) -> &'static str {
        if ip.contains(':') {
            "ip6tables"
        } else {
            "iptables"
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn test_detect_firewall() {
        let firewall = FirewallManager::detect_firewall().await;
        assert!(matches!(
            firewall,
            FirewallType::Ufw
                | FirewallType::Iptables
                | FirewallType::Firewalld
                | FirewallType::None
        ));
    }

    #[test]
    fn test_validate_container_ip() {
        assert!(FirewallManager::validate_container_ip("10.42.0.5").is_ok());
        assert!(FirewallManager::validate_container_ip("2001:db8::1").is_ok());
        assert!(FirewallManager::validate_container_ip("not-an-ip").is_err());
    }

    #[test]
    fn test_track_and_untrack() {
        // Initialize the rule state file path so save_tracked_rules() doesn't panic.
        let tmp = std::env::temp_dir().join("catalyst-test-fw-track");
        let _ = std::fs::create_dir_all(&tmp);
        FirewallManager::init(&tmp);

        // Clear any existing rules in test.
        lock_rules().clear();

        track_rule(25565, "tcp", "srv-1", "10.42.0.5");
        track_rule(25565, "udp", "srv-1", "10.42.0.5");
        track_rule(25566, "tcp", "srv-2", "10.42.0.6");

        // Duplicate should be ignored.
        track_rule(25565, "tcp", "srv-1", "10.42.0.5");

        let rules = lock_rules();
        assert_eq!(rules.len(), 3);

        drop(rules);

        let removed = untrack_server_rules("srv-1");
        assert_eq!(removed.len(), 2);

        let remaining = lock_rules();
        assert_eq!(remaining.len(), 1);
        assert_eq!(remaining[0].server_id, "srv-2");

        // Clean up
        drop(remaining);
        untrack_server_rules("srv-2");
        lock_rules().clear();
    }

    /// Multi-port firewall rule lifecycle test (issue #134).
    /// Simulates the hot-add / hot-remove cycle for a server with multiple
    /// secondary allocations and verifies tracked rules stay consistent.
    ///
    /// Uses a dedicated Vec with the production `push_dedup` / `retain_and_collect`
    /// functions to avoid cross-test interference from global TRACKED_RULES while
    /// still exercising the real dedup/removal logic.
    #[test]
    fn test_multi_port_firewall_lifecycle() {
        let mut rules: Vec<FirewallRule> = Vec::new();

        let server_id = "srv-lifecycle-134";
        let container_ip = "10.42.0.10";

        // Phase 1: Server starts with primary port only
        push_dedup(
            &mut rules,
            FirewallRule {
                port: 25565,
                proto: "tcp".into(),
                server_id: server_id.into(),
                container_ip: container_ip.into(),
            },
        );
        push_dedup(
            &mut rules,
            FirewallRule {
                port: 25565,
                proto: "udp".into(),
                server_id: server_id.into(),
                container_ip: container_ip.into(),
            },
        );
        let my_rules: Vec<_> = rules.iter().filter(|r| r.server_id == server_id).collect();
        assert_eq!(my_rules.len(), 2);

        // Phase 2: Hot-add three secondary ports
        push_dedup(
            &mut rules,
            FirewallRule {
                port: 25566,
                proto: "tcp".into(),
                server_id: server_id.into(),
                container_ip: container_ip.into(),
            },
        );
        push_dedup(
            &mut rules,
            FirewallRule {
                port: 25567,
                proto: "tcp".into(),
                server_id: server_id.into(),
                container_ip: container_ip.into(),
            },
        );
        push_dedup(
            &mut rules,
            FirewallRule {
                port: 25568,
                proto: "tcp".into(),
                server_id: server_id.into(),
                container_ip: container_ip.into(),
            },
        );
        push_dedup(
            &mut rules,
            FirewallRule {
                port: 25566,
                proto: "udp".into(),
                server_id: server_id.into(),
                container_ip: container_ip.into(),
            },
        );
        push_dedup(
            &mut rules,
            FirewallRule {
                port: 25567,
                proto: "udp".into(),
                server_id: server_id.into(),
                container_ip: container_ip.into(),
            },
        );
        push_dedup(
            &mut rules,
            FirewallRule {
                port: 25568,
                proto: "udp".into(),
                server_id: server_id.into(),
                container_ip: container_ip.into(),
            },
        );
        let my_rules: Vec<_> = rules.iter().filter(|r| r.server_id == server_id).collect();
        // 2 primary (tcp+udp) + 6 secondary (3 ports × 2 protos) = 8
        assert_eq!(my_rules.len(), 8);
        let ports: std::collections::HashSet<u16> = my_rules.iter().map(|r| r.port).collect();
        assert!(ports.contains(&25565));
        assert!(ports.contains(&25566));
        assert!(ports.contains(&25567));
        assert!(ports.contains(&25568));

        // Phase 3: Hot-remove one secondary port (remove_server_ports + re-add survivors)
        let removed = retain_and_collect(&mut rules, server_id);
        assert_eq!(removed.len(), 8);
        assert!(rules
            .iter()
            .filter(|r| r.server_id == server_id)
            .collect::<Vec<_>>()
            .is_empty());

        // Re-add surviving ports (all except 25568 which was removed)
        push_dedup(
            &mut rules,
            FirewallRule {
                port: 25565,
                proto: "tcp".into(),
                server_id: server_id.into(),
                container_ip: container_ip.into(),
            },
        );
        push_dedup(
            &mut rules,
            FirewallRule {
                port: 25565,
                proto: "udp".into(),
                server_id: server_id.into(),
                container_ip: container_ip.into(),
            },
        );
        push_dedup(
            &mut rules,
            FirewallRule {
                port: 25566,
                proto: "tcp".into(),
                server_id: server_id.into(),
                container_ip: container_ip.into(),
            },
        );
        push_dedup(
            &mut rules,
            FirewallRule {
                port: 25566,
                proto: "udp".into(),
                server_id: server_id.into(),
                container_ip: container_ip.into(),
            },
        );
        push_dedup(
            &mut rules,
            FirewallRule {
                port: 25567,
                proto: "tcp".into(),
                server_id: server_id.into(),
                container_ip: container_ip.into(),
            },
        );
        push_dedup(
            &mut rules,
            FirewallRule {
                port: 25567,
                proto: "udp".into(),
                server_id: server_id.into(),
                container_ip: container_ip.into(),
            },
        );
        // Note: 25568 is NOT re-added (it was removed)
        let my_rules: Vec<_> = rules.iter().filter(|r| r.server_id == server_id).collect();
        assert_eq!(my_rules.len(), 6);
        let ports: std::collections::HashSet<u16> = my_rules.iter().map(|r| r.port).collect();
        assert!(!ports.contains(&25568)); // removed port should be gone
        assert!(ports.contains(&25567)); // other ports still present

        // Phase 4: Server deleted — all remaining rules removed
        let removed = retain_and_collect(&mut rules, server_id);
        assert_eq!(removed.len(), 6);
        assert!(rules
            .iter()
            .filter(|r| r.server_id == server_id)
            .collect::<Vec<_>>()
            .is_empty());
    }

    /// Test that duplicate tracking is idempotent even with multi-port servers.
    #[test]
    fn test_multi_port_duplicate_tracking() {
        let mut rules: Vec<FirewallRule> = Vec::new();

        let server_id = "srv-dup-134";
        let container_ip = "10.42.0.11";

        // Add 5 ports using push_dedup (same function used by production track_rule)
        for port in 30000..30005 {
            push_dedup(
                &mut rules,
                FirewallRule {
                    port,
                    proto: "tcp".into(),
                    server_id: server_id.into(),
                    container_ip: container_ip.into(),
                },
            );
        }
        assert_eq!(rules.len(), 5);

        // Re-add all 5 — should not increase count (dedup)
        for port in 30000..30005 {
            push_dedup(
                &mut rules,
                FirewallRule {
                    port,
                    proto: "tcp".into(),
                    server_id: server_id.into(),
                    container_ip: container_ip.into(),
                },
            );
        }
        assert_eq!(rules.len(), 5);
    }
}
