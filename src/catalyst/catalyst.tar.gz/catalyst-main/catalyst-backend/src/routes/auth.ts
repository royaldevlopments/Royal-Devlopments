import { prisma } from '../db.js';
import type { FastifyInstance, FastifyRequest, FastifyReply } from "fastify";
import { z } from 'zod';

import { getAuth } from '../auth';
import { captureSystemError } from "../services/error-logger";
import { fromNodeHeaders } from "better-auth/node";
import { logAuthAttempt } from "../middleware/audit";
import { serialize } from '../utils/serialize';
import { revokeSftpTokensForUser } from '../services/sftp-token-manager';
import {
  bruteForceProtection,
  handleFailedLogin,
  handleSuccessfulLogin,
} from "../middleware/brute-force";
import {
  passwordSchema,
  userRegistrationSchema,
  userLoginSchema,
} from "../lib/validation";

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// Helper to forward response headers (set-auth-token, set-cookie) from better-auth to Fastify reply.
// Must use getSetCookie() when available because Headers.get("set-cookie")
// returns a comma-separated string which browsers cannot parse.
function forwardAuthHeaders(response: any, reply: FastifyReply) {
  const headers = "headers" in response ? response.headers : null;

  const tokenHeader = headers?.get?.("set-auth-token") ?? null;
  if (tokenHeader) {
    reply.header("set-auth-token", tokenHeader);
    reply.header("Access-Control-Expose-Headers", "set-auth-token");
  }

  if (!headers) return tokenHeader;

  const rawSetCookie =
    typeof (headers as any).getSetCookie === "function"
      ? (headers as any).getSetCookie()
      : headers.get?.("set-cookie");

  if (!rawSetCookie) return tokenHeader;

  const cookies: string[] = Array.isArray(rawSetCookie)
    ? rawSetCookie
    : [rawSetCookie];

  for (const cookie of cookies) {
    reply.header("set-cookie", cookie);
  }

  return tokenHeader;
}

// Extract the data payload from a better-auth response (handles both wrapped and unwrapped)
function extractResponseData(response: any) {
  return "headers" in response && response.response ? response.response : response;
}

export async function authRoutes(app: FastifyInstance) {

  const loadUserPermissions = async (userId: string) => {
    const roles = await prisma.role.findMany({
      where: { users: { some: { id: userId } } },
      select: { permissions: true },
    });
    return roles.flatMap((role) => role.permissions);
  };

  // Helper to get the request headers in the format better-auth expects
  const getHeaders = (request: FastifyRequest) =>
    fromNodeHeaders(request.headers as Record<string, string | string[] | undefined>);

  // ── Register ─────────────────────────────────────────────────────────
  app.post(
    "/register",
    async (request: FastifyRequest, reply: FastifyReply) => {
      // Validate all registration fields using the pre-built schema
      const regValidation = userRegistrationSchema.safeParse(request.body);
      if (!regValidation.success) {
        return reply.status(400).send({
          error: 'Validation failed',
          details: regValidation.error.issues.map(err => ({
            field: err.path.join('.'),
            message: err.message,
          })),
        });
      }
      const { email, username, password } = regValidation.data;

      try {
        const response = await getAuth().api.signUpEmail({
          headers: getHeaders(request),
          body: { email, password, name: username, username } as any,
          returnHeaders: true,
        });

        const data = extractResponseData(response);
        const user = data?.user;
        if (!user) {
          return reply.status(400).send({ error: "Registration failed" });
        }

        const tokenHeader = forwardAuthHeaders(response, reply);
        const permissions = await loadUserPermissions(user.id);

        // Fetch role + profile fields from DB (same rationale as login).
        const profile = await prisma.user.findUnique({
          where: { id: user.id },
          select: {
            name: true, firstName: true, lastName: true, image: true,
            roles: { select: { name: true } },
          },
        });

        // Send welcome email (non-blocking)
        try {
          const { sendEmail } = await import('../services/mailer');
          const rawPanelName = (await import('../db').then(m => m.prisma.themeSettings.findUnique({ where: { id: 'default' } })))?.panelName || process.env.APP_NAME || 'Catalyst';
          const panelName = escapeHtml(rawPanelName);
          const safeUsername = escapeHtml(username);
          await sendEmail({
            to: email,
            subject: `Welcome to ${panelName}`,
            html: `<p>Welcome to ${panelName}, ${safeUsername}!</p><p>Your account has been created successfully.</p><p>You can now log in and start managing your servers.</p>`,
            text: `Welcome to ${panelName}, ${username}! Your account has been created successfully.`,
          });
        } catch (emailErr: any) {
          // Log but don't fail registration
          captureSystemError({
            level: 'warn',
            component: 'AuthRoutes',
            message: `Failed to send welcome email: ${emailErr?.message || String(emailErr)}`,
            stack: emailErr?.stack,
            metadata: { emailError: emailErr?.message || String(emailErr) },
          }).catch(() => {});
          console.error('Failed to send welcome email:', emailErr);
        }

        reply.send({
          success: true,
          data: {
            userId: user.id,
            email: user.email,
            username: user.username ?? username,
            name: profile?.name ?? null,
            firstName: profile?.firstName ?? null,
            lastName: profile?.lastName ?? null,
            image: profile?.image ?? null,
            role: profile?.roles[0]?.name || 'user',
            permissions,
            token: tokenHeader ?? null,
          },
        });
      } catch (err: any) {
        const isDuplicate = err?.code === 'P2002' || (err?.message || '').includes('Unique constraint') || (err?.message || '').includes('already exists');
        if (isDuplicate) {
          return reply.status(409).send({ error: 'Email or username already in use' });
        }
        throw err;
      }
    }
  );

  // ── Login ────────────────────────────────────────────────────────────
  app.post(
    "/login",
    async (request: FastifyRequest, reply: FastifyReply) => {
      // Validate login fields using the pre-built schema
      const loginValidation = userLoginSchema.safeParse(request.body);
      if (!loginValidation.success) {
        return reply.status(400).send({
          error: 'Validation failed',
          details: loginValidation.error.issues.map(err => ({
            field: err.path.join('.'),
            message: err.message,
          })),
        });
      }
      const { email, password } = loginValidation.data;
      const normalizedEmail = email;

      // Always check brute-force protection before any user lookup to prevent
      // email enumeration via timing differences and to rate-limit unknown emails.
      await bruteForceProtection(prisma, normalizedEmail, request);

      // Resolve the actual email (case-insensitive lookup)
      const userRecord = await prisma.user.findFirst({
        where: { email: { equals: normalizedEmail, mode: "insensitive" } },
      });

      if (!userRecord) {
        await logAuthAttempt(normalizedEmail, false, request.ip, request.headers["user-agent"]);
        return reply.status(401).send({ error: "Invalid credentials" });
      }

      try {

        const response = await getAuth().api.signInEmail({
          headers: getHeaders(request),
          body: {
            email: userRecord.email,
            password,
            rememberMe: loginValidation.data.rememberMe,
          },
          returnHeaders: true,
        });

        const data = extractResponseData(response);

        // 2FA redirect
        if (data?.twoFactorRedirect) {
          await logAuthAttempt(normalizedEmail, true, request.ip, request.headers["user-agent"]);
          const tokenHeader = forwardAuthHeaders(response, reply);
          return reply.status(202).send({
            success: false,
            data: { twoFactorRequired: true, token: tokenHeader ?? null },
          });
        }

        const user = data?.user;
        if (!user) {
          const errorCode = data?.code || data?.error?.code;
          if (errorCode === "PASSKEY_REQUIRED") {
            return reply.status(403).send({ error: "Passkey required", code: "PASSKEY_REQUIRED" });
          }
          throw new Error(data?.error?.message || data?.error || "Invalid credentials");
        }

        // Handle successful login - reset failed attempts
        await handleSuccessfulLogin(prisma, user.id);
        await logAuthAttempt(normalizedEmail, true, request.ip, request.headers["user-agent"]);

        const tokenHeader = forwardAuthHeaders(response, reply);
        const permissions = await loadUserPermissions(user.id);

        // Fetch role + profile fields from DB.  better-auth's signInEmail
        // response only includes fields it manages (id, email, username, …);
        // custom Prisma fields like firstName, lastName, image, and the
        // role (from the roles table) are NOT included.
        const profile = await prisma.user.findUnique({
          where: { id: user.id },
          select: {
            name: true, firstName: true, lastName: true, image: true,
            roles: { select: { name: true } },
          },
        });

        reply.send({
          success: true,
          data: {
            userId: user.id,
            email: user.email,
            username: user.username ?? userRecord.username,
            name: profile?.name ?? null,
            firstName: profile?.firstName ?? null,
            lastName: profile?.lastName ?? null,
            image: profile?.image ?? null,
            role: profile?.roles[0]?.name || 'user',
            permissions,
            token: tokenHeader ?? null,
          },
        });
      } catch (err: any) {
        const isCredentialError =
          err?.message?.toLowerCase().includes('invalid') ||
          err?.message?.toLowerCase().includes('credential') ||
          err?.status === 401 ||
          err?.code === 'INVALID_PASSWORD';

        if (isCredentialError && userRecord) {
          await handleFailedLogin(prisma, request);
          await logAuthAttempt(normalizedEmail, false, request.ip, request.headers["user-agent"]);
          return reply.status(401).send({ error: "Invalid credentials" });
        }
        
        // Log unexpected errors and return 500
        app.log.error({ err }, 'Unexpected error during login');
        captureSystemError({
          level: 'error',
          component: 'AuthRoutes',
          message: err?.message || 'Unexpected login error',
          stack: err?.stack,
          metadata: { email: normalizedEmail, code: err?.code },
        }).catch(() => {});
        return reply.status(500).send({ error: "An error occurred during login. Please try again." });
      }
    }
  );

  // ── Get current user ─────────────────────────────────────────────────
  app.get(
    "/me",
    { onRequest: [app.authenticate], config: { rateLimit: { max: 120, timeWindow: "1 minute" } } },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const user = await prisma.user.findUnique({
        where: { id: request.user.userId },
        select: {
          id: true, email: true, username: true, name: true, firstName: true, lastName: true,
          image: true, createdAt: true,
          roles: { select: { name: true, permissions: true } },
        },
      });

      if (!user) {
        return reply.status(404).send({ error: "User not found" });
      }

      reply.send({
        success: true,
        data: {
          id: user.id, email: user.email, username: user.username,
          name: user.name, firstName: user.firstName, lastName: user.lastName,
          image: user.image,
          role: user.roles[0]?.name || 'user',
          permissions: user.roles.flatMap((role) => role.permissions),
          createdAt: user.createdAt,
        },
      });
    }
  );

  // ── Profile summary ──────────────────────────────────────────────────
  app.get(
    "/profile",
    { onRequest: [app.authenticate], config: { rateLimit: { max: 120, timeWindow: "1 minute" } } },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const userRecord = await prisma.user.findUnique({
        where: { id: request.user.userId },
        select: {
          id: true, email: true, username: true, name: true, firstName: true, lastName: true,
          image: true, emailVerified: true, twoFactorEnabled: true, createdAt: true,
          lastSuccessfulLogin: true,
          preferences: true,
          accounts: { select: { id: true, providerId: true, accountId: true, createdAt: true, updatedAt: true } },
        },
      });

      if (!userRecord) {
        return reply.status(404).send({ error: "User not found" });
      }

      reply.send({
        success: true,
        data: {
          id: userRecord.id, email: userRecord.email, username: userRecord.username,
          name: userRecord.name, firstName: userRecord.firstName, lastName: userRecord.lastName,
          image: userRecord.image, emailVerified: userRecord.emailVerified,
          twoFactorEnabled: userRecord.twoFactorEnabled,
          hasPassword: userRecord.accounts.some((a) => a.providerId === "credential"),
          createdAt: userRecord.createdAt,
          lastSuccessfulLogin: userRecord.lastSuccessfulLogin,
          preferences: userRecord.preferences,
          accounts: userRecord.accounts,
        },
      });
    }
  );

  app.post(
    "/profile/sso/unlink",
    { onRequest: [app.authenticate] },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const { providerId, accountId } = request.body as {
        providerId: string; accountId?: string;
      };
      if (!providerId) {
        return reply.status(400).send({ error: "Missing providerId" });
      }
      const userRecord = await prisma.user.findUnique({
        where: { id: request.user.userId },
        select: {
          accounts: { select: { providerId: true } },
        },
      });
      const remainingProviders = userRecord?.accounts.filter(a => a.providerId !== providerId && a.providerId !== 'credential') ?? [];
      const hasPassword = userRecord?.accounts.some(a => a.providerId === 'credential');
      if (!hasPassword && remainingProviders.length === 0) {
        return reply.status(409).send({ error: 'You cannot unlink your only sign-in method. Set a password first.' });
      }
      try {
        const response = await getAuth().api.unlinkAccount({
          headers: getHeaders(request),
          body: { providerId, accountId },
        });
        reply.send(serialize({ success: true, data: response }));
      } catch (err: any) {
        request.log.error({ err }, 'Failed to unlink SSO account');
        reply.status(500).send({
          success: false,
          error: err?.message || 'Failed to unlink SSO account',
        });
      }
    }
  );

  // ── Update profile ──────────────────────────────────────────────────
  app.patch(
    "/profile",
    { onRequest: [app.authenticate], config: { rateLimit: { max: 20, timeWindow: '1 minute' } } },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const { username, firstName, lastName } = request.body as {
        username?: string; firstName?: string; lastName?: string;
      };

      // Build update payload
      const data: Record<string, string> = {};
      if (firstName !== undefined) {
        if (firstName.length > 100) {
          return reply.status(400).send({ error: 'First name must be at most 100 characters' });
        }
        data.firstName = firstName;
      }
      if (lastName !== undefined) {
        if (lastName.length > 100) {
          return reply.status(400).send({ error: 'Last name must be at most 100 characters' });
        }
        data.lastName = lastName;
      }
      if (username !== undefined) {
        if (!username || username.length < 3 || username.length > 32 || !/^[a-zA-Z0-9_-]+$/.test(username)) {
          return reply.status(400).send({ error: 'Username must be 3-32 characters and contain only letters, numbers, hyphens, and underscores' });
        }
        data.username = username;
      }

      if (Object.keys(data).length === 0) {
        return reply.status(400).send({ error: 'No fields to update' });
      }

      try {
        const user = await prisma.user.update({
          where: { id: request.user.userId },
          data,
          select: { id: true, username: true, firstName: true, lastName: true },
        });
        reply.send(serialize({ success: true, data: user }));
      } catch (err: any) {
        if (err.code === 'P2002' && err.meta?.target?.includes('username')) {
          return reply.status(409).send({ error: 'Username already taken' });
        }
        throw err;
      }
    }
  );

  // ── Update user preferences ─────────────────────────────────────────
  app.patch(
    "/profile/preferences",
    { onRequest: [app.authenticate], config: { rateLimit: { max: 20, timeWindow: '1 minute' } } },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const preferencesSchema = z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).refine(
        obj => JSON.stringify(obj).length <= 16384,
        { message: 'Preferences payload too large' }
      );
      const parsed = preferencesSchema.safeParse(request.body);
      if (!parsed.success) {
        return reply.status(400).send({ error: parsed.error.issues[0]?.message || 'Invalid preferences' });
      }
      await prisma.user.update({
        where: { id: request.user.userId },
        data: { preferences: parsed.data as any },
      });
      reply.send(serialize({ success: true }));
    }
  );

  // ── Avatar upload ───────────────────────────────────────────────────
  app.post(
    "/profile/avatar",
    { onRequest: [app.authenticate], config: { rateLimit: { max: 20, timeWindow: '1 minute' } } },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const data = await request.file();
      if (!data) {
        return reply.status(400).send({ error: 'No file uploaded' });
      }

      // Validate file type
      const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
      if (!allowedTypes.includes(data.mimetype)) {
        return reply.status(400).send({ error: 'Only JPEG, PNG, GIF, and WebP images are allowed' });
      }

      // Validate file size (max 2MB)
      const MAX_SIZE = 2 * 1024 * 1024;
      const buffer = await data.toBuffer();
      if (buffer.length > MAX_SIZE) {
        return reply.status(400).send({ error: 'Image must be under 2MB' });
      }

      const magic = buffer.slice(0, 4).toString('hex');
      const isJpeg = magic.startsWith('ffd8');
      const isPng = magic === '89504e47';
      const isGif = magic.startsWith('474946');
      const isWebp = buffer.slice(0, 12).toString('hex').startsWith('52494646');
      if (!isJpeg && !isPng && !isGif && !isWebp) {
        return reply.status(400).send({ error: 'Invalid image format' });
      }

      // Store as data URI in the user record
      const ext = data.mimetype.split('/')[1]?.replace('svg+xml', 'svg') || 'png';
      const base64 = buffer.toString('base64');
      const dataUri = `data:${data.mimetype};base64,${base64}`;

      await prisma.user.update({
        where: { id: request.user.userId },
        data: { image: dataUri },
      });

      reply.send(serialize({ success: true, data: { image: dataUri } }));
    }
  );

  // ── Remove avatar ───────────────────────────────────────────────────
  app.delete(
    "/profile/avatar",
    { onRequest: [app.authenticate] },
    async (request: FastifyRequest, reply: FastifyReply) => {
      await prisma.user.update({
        where: { id: request.user.userId },
        data: { image: null },
      });
      reply.send(serialize({ success: true, message: 'Avatar removed' }));
    }
  );

  // ── Personal audit log ──────────────────────────────────────────────
  app.get(
    "/profile/audit-log",
    { onRequest: [app.authenticate] },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const { limit = 50, offset = 0 } = request.query as { limit?: string; offset?: string };
      const [logs, total] = await Promise.all([
        prisma.auditLog.findMany({
          where: { userId: request.user.userId },
          orderBy: { timestamp: 'desc' },
          take: Math.min(Number(limit) || 50, 200),
          skip: Number(offset) || 0,
          select: { id: true, action: true, resource: true, resourceId: true, details: true, timestamp: true },
        }),
        prisma.auditLog.count({ where: { userId: request.user.userId } }),
      ]);
      reply.send(serialize({ success: true, data: { logs, total } }));
    }
  );

  // ── Export account data (GDPR) ──────────────────────────────────────
  app.get(
    "/profile/export",
    { onRequest: [app.authenticate] },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const userId = request.user.userId;
      const [user, sessions, accounts, apiKeys, auditLogs, serverAccess] = await Promise.all([
        prisma.user.findUnique({
          where: { id: userId },
          select: { id: true, email: true, username: true, name: true, firstName: true, lastName: true, image: true, createdAt: true, updatedAt: true },
        }),
        prisma.session.findMany({
          where: { userId },
          select: { id: true, createdAt: true, updatedAt: true, ipAddress: true, userAgent: true },
        }),
        prisma.account.findMany({
          where: { userId },
          select: { id: true, providerId: true, accountId: true, createdAt: true },
        }),
        prisma.apikey.findMany({
          where: { userId },
          select: { id: true, name: true, prefix: true, createdAt: true, lastRequest: true, requestCount: true, expiresAt: true },
        }),
        prisma.auditLog.findMany({
          where: { userId },
          orderBy: { timestamp: 'desc' },
          select: { id: true, action: true, resource: true, resourceId: true, details: true, timestamp: true },
          take: 500,
        }),
        prisma.serverAccess.findMany({
          where: { userId },
          select: { id: true, serverId: true, permissions: true, createdAt: true },
        }),
      ]);

      const exportData = {
        exportedAt: new Date().toISOString(),
        user,
        sessions: sessions.map(s => ({ ...s, id: undefined })), // don't expose session IDs
        accounts: accounts.map(a => ({ ...a, accountId: undefined })),
        apiKeys: apiKeys.map(k => ({ ...k, id: undefined, prefix: undefined, start: undefined })),
        auditLogs: auditLogs.map(l => ({ ...l, details: undefined })),
        serverAccess,
      };

      reply
        .header('Content-Type', 'application/json')
        .header('Content-Disposition', 'attachment; filename="catalyst-account-export.json"')
        .send(JSON.stringify(exportData, null, 2));
    }
  );

  // ── User's API keys overview ────────────────────────────────────────
  app.get(
    "/profile/api-keys",
    { onRequest: [app.authenticate] },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const keys = await prisma.apikey.findMany({
        where: { userId: request.user.userId },
        select: {
          id: true, name: true, prefix: true, start: true, enabled: true,
          allPermissions: true, permissions: true,
          lastRequest: true, requestCount: true, expiresAt: true, createdAt: true,
        },
        orderBy: { createdAt: 'desc' },
      });
      reply.send(serialize({ success: true, data: keys }));
    }
  );

  // ── Forgot password ──────────────────────────────────────────────────
  app.post(
    "/forgot-password",
    { config: { rateLimit: { max: 10, timeWindow: '15 minutes' } } },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const { email } = request.body as { email: string };
      if (!email || !email.trim()) {
        return reply.status(400).send({ error: "Email is required" });
      }

      const normalizedEmail = email.trim().toLowerCase();

      try {
        const redirectUrl = `${process.env.FRONTEND_URL || "http://localhost:5173"}/reset-password`;
        await getAuth().api.requestPasswordReset({
          body: { email: normalizedEmail, redirectTo: redirectUrl },
        });
      } catch (error: any) {
        // Log but don't expose to prevent email enumeration
        app.log.warn({ error: error.message }, "Password reset request failed");
      }

      // Always return success to prevent email enumeration
      reply.send({ success: true, message: "If an account exists, a reset link has been sent" });
    }
  );

  // ── Validate reset token ─────────────────────────────────────────────
  app.post(
    "/reset-password/validate",
    { config: { rateLimit: { max: 10, timeWindow: '15 minutes' } } },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const { token } = request.body as { token?: string };
      if (!token) {
        return reply.status(400).send({ error: "Token is required", valid: false });
      }

      try {
        const verification = await prisma.verification.findFirst({
          where: { value: token, expiresAt: { gt: new Date() }, identifier: { startsWith: 'reset-password' } },
        });
        await new Promise(r => setTimeout(r, 100));
        reply.send({ success: Boolean(verification), valid: Boolean(verification), ...(verification ? {} : { error: "Invalid or expired token" }) });
      } catch {
        reply.send({ success: false, valid: false, error: "Invalid or expired token" });
      }
    }
  );

  // ── Delete own account ─────────────────────────────────────────────
  // Users can delete their own account if they don't own any servers.
  // Sub-users (no servers) can delete freely.
  app.post(
    "/profile/delete",
    { onRequest: [app.authenticate], config: { rateLimit: { max: 20, timeWindow: '1 minute' } } },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const userId = request.user.userId;
      const { confirm, currentPassword } = request.body as { confirm?: string; currentPassword?: string };

      if (confirm !== "DELETE") {
        return reply.status(400).send({
          error: 'Confirmation required. Send { "confirm": "DELETE" } to proceed.',
        });
      }

      if (!currentPassword) {
        return reply.status(400).send({ error: 'Current password is required' });
      }

      // Verify current password
      try {
        await getAuth().api.signInEmail({
          headers: getHeaders(request),
          body: { email: request.user.email || '', password: currentPassword },
        });
      } catch {
        return reply.status(401).send({ error: 'Invalid password' });
      }

      // Check for owned servers
      const ownedServers = await prisma.server.findMany({
        where: { ownerId: userId },
        select: { id: true, name: true },
      });

      if (ownedServers.length > 0) {
        return reply.status(409).send({
          error: `You own ${ownedServers.length} server(s). Transfer or delete them before deleting your account.`,
          ownedServers: ownedServers.map((s) => ({ id: s.id, name: s.name })),
        });
      }

      const userRecord = await prisma.user.findUnique({
        where: { id: userId },
        select: { email: true },
      });
      const userEmail = userRecord?.email || '';

      await prisma.$transaction(async (tx) => {
        // Delete all sessions
        await tx.session.deleteMany({ where: { userId } });

        // Delete the user
        await tx.user.delete({ where: { id: userId } });
      });

      // Revoke all SFTP tokens
      await revokeSftpTokensForUser(userId);

      // Disconnect WebSocket sessions
      const wsGateway = (app as any).wsGateway;
      if (wsGateway?.disconnectUser) {
        await wsGateway.disconnectUser(userId);
      }

      // Fire webhook
      const webhookService: any = (app as any).webhookService;
      if (webhookService) {
        webhookService.userDeleted(userId, userEmail, "self-deleted", userId).catch(() => {});
      }

      // Clear all better-auth cookies
      const secureAttr = process.env.NODE_ENV !== "development" && process.env.COOKIE_SECURE !== 'false' ? '; Secure' : '';
      const cookieNames = [
        'better-auth.session_token',
        'better-auth.passkey',
        'better-auth.two_factor',
      ];
      cookieNames.forEach(name => {
        reply.header('set-cookie', `${name}=; Max-Age=0; Path=/; SameSite=Strict; HttpOnly${secureAttr}`);
      });
      reply.send({ success: true, message: "Account deleted" });
    }
  );
}

