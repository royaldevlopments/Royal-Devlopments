import type { FastifyInstance, FastifyRequest, FastifyReply } from "fastify";
import { prisma } from "../../db.js";
import { hasNodeAccess } from "../../lib/permissions.js";
import { checkIsAdmin, collectUsedHostPortsByIp, ensureNotSuspended, findPortConflict, parsePortValue, parseStoredPortBindings, shouldUseIpam } from './_helpers.js';

/** Statuses that allow allocation changes. Stopped servers can always change allocations;
 *  running servers support hot-add / hot-remove (the agent will sync firewall rules). */
const ALLOCATION_ALLOWED_STATUSES = new Set(["stopped", "running", "crashed", "error"]);

export async function serverNetworkRoutes(app: FastifyInstance) {
  app.get(
    "/:serverId/allocations",
    { onRequest: [app.authenticate] },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const { serverId } = request.params as { serverId: string };
      const userId = request.user.userId;

      const server = await prisma.server.findUnique({
        where: { id: serverId },
        include: {
          node: true,
          access: true,
        },
      });

      if (!server) {
        return reply.status(404).send({ error: "Server not found" });
      }

      if (!ensureNotSuspended(server, reply)) {
        return;
      }

      // Admin bypass - admins can access any server
      if (checkIsAdmin(request, 'admin.read')) {
        // Admin bypass - proceed to return allocations
      } else {
        // Check if user is owner OR has server.read permission via access entry
        const hasAccess = server.ownerId === userId || server.access.some(
          (access) => access.userId === userId && access.permissions.includes("server.read")
        );
        if (!hasAccess) {
          return reply.status(403).send({ error: "Forbidden" });
        }
      }

      const bindings = parseStoredPortBindings(server.portBindings);

      const allocations = Object.entries(bindings)
        .map(([containerPort, hostPort]) => ({
          containerPort: Number(containerPort),
          hostPort,
          isPrimary: Number(containerPort) === server.primaryPort,
        }))
        .sort((a, b) => a.containerPort - b.containerPort);

      if (!allocations.length && server.primaryPort) {
        allocations.push({
          containerPort: server.primaryPort,
          hostPort: server.primaryPort,
          isPrimary: true,
        });
      }

      reply.send({ success: true, data: allocations, subdomain: server.subdomain ?? null });
    }
  );

  // Add allocation (hot-add supported for running servers)
  // TODO(#134): Add Zod request-body schema for containerPort/hostPort validation
  // TODO(#134): Add RBAC middleware (rbac.checkPermission) to onRequest array
  app.post(
    "/:serverId/allocations",
    { onRequest: [app.authenticate] },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const { serverId } = request.params as { serverId: string };
      const { containerPort, hostPort } = request.body as {
        containerPort: number;
        hostPort: number;
      };
      const userId = request.user.userId;

      const server = await prisma.server.findUnique({
        where: { id: serverId },
        include: { access: true, node: true },
      });

      if (!server) {
        return reply.status(404).send({ error: "Server not found" });
      }

      if (!ensureNotSuspended(server, reply)) {
        return;
      }

      const isAdmin = checkIsAdmin(request, 'admin.read');
      const hasWriteAccess = server.access.some(
        (access) => access.userId === userId &&
          (access.permissions.includes('server.update') || access.permissions.includes('server.delete'))
      );
      const hasNodeAccessResult = await hasNodeAccess(prisma, userId, server.nodeId);
      const hasAccess = server.ownerId === userId || hasWriteAccess || isAdmin || hasNodeAccessResult;
      if (!hasAccess) {
        return reply.status(403).send({ error: "Forbidden" });
      }

      // Allow allocation changes on stopped, running, crashed, and error servers (hot-add)
      if (!ALLOCATION_ALLOWED_STATUSES.has(server.status)) {
        return reply.status(409).send({
          error: `Server must be in one of these statuses to update allocations: ${[...ALLOCATION_ALLOWED_STATUSES].join(', ')}`,
        });
      }

      const parsedContainerPort = parsePortValue(containerPort);
      const parsedHostPort = parsePortValue(hostPort);
      if (!parsedContainerPort || !parsedHostPort) {
        return reply.status(400).send({ error: "Invalid port value" });
      }

      const bindings = parseStoredPortBindings(server.portBindings);
      if (bindings[parsedContainerPort]) {
        return reply.status(409).send({ error: "Allocation already exists for container port" });
      }

      const usedHostPorts = new Set(Object.values(bindings));
      if (!bindings[server.primaryPort]) {
        const primaryHostPort = parsePortValue(server.primaryPort ?? undefined);
        if (primaryHostPort) {
          usedHostPorts.add(primaryHostPort);
        }
      }
      const isPrimaryBinding =
        parsedContainerPort === server.primaryPort && parsedHostPort === server.primaryPort;
      if (!isPrimaryBinding && usedHostPorts.has(parsedHostPort)) {
        return reply.status(409).send({ error: "Host port already assigned to allocation" });
      }

      if (!shouldUseIpam(server.networkMode ?? undefined) && server.networkMode !== "host") {
        const siblingServers = await prisma.server.findMany({
          where: {
            nodeId: server.nodeId,
            id: { not: serverId },
          },
          select: {
            id: true,
            primaryPort: true,
            primaryIp: true,
            portBindings: true,
            networkMode: true,
          },
        });
        const usedPorts = collectUsedHostPortsByIp(siblingServers, serverId);
        const hostIp = server.primaryIp ?? null;
        const conflictPort = findPortConflict(usedPorts, hostIp, [parsedHostPort]);
        if (conflictPort) {
          return reply.status(400).send({
            error: `Port ${parsedHostPort} is already in use on this node`,
          });
        }
      }

      bindings[parsedContainerPort] = parsedHostPort;
      const updated = await prisma.server.update({
        where: { id: serverId },
        data: {
          portBindings: bindings,
        },
      });

      const wsGateway = app.wsGateway;

      // If server is running, notify the agent to open the firewall port
      if (server.status === "running" && wsGateway?.sendToAgent) {
        const containerIp = server.primaryIp ?? "";
        wsGateway.sendToAgent(server.nodeId, {
          type: "allocation_added",
          serverId,
          serverUuid: server.uuid,
          containerPort: parsedContainerPort,
          hostPort: parsedHostPort,
          containerIp,
          networkMode: server.networkMode ?? "bridge",
          protocol: "tcp",
        }).catch(() => {
          // Best-effort — agent may be temporarily disconnected; reconciliation will catch up.
        });
      }

      if (wsGateway?.pushToAdminSubscribers) {
        wsGateway.pushToAdminSubscribers('server_updated', {
          type: 'server_updated',
          serverId,
          updatedBy: userId,
          change: 'allocation_added',
          timestamp: new Date().toISOString(),
        });
      }
      if (wsGateway?.pushToGlobalSubscribers) {
        wsGateway.pushToGlobalSubscribers('server_updated', {
          type: 'server_updated',
          serverId,
          updatedBy: userId,
          change: 'allocation_added',
          timestamp: new Date().toISOString(),
        });
      }

      reply.send({
        success: true,
        data: {
          containerPort: parsedContainerPort,
          hostPort: parsedHostPort,
          isPrimary: parsedContainerPort === updated.primaryPort,
        },
      });
    }
  );

  // TODO(#134): Port bindings read-modify-write should use prisma.$transaction
  // with optimistic concurrency to prevent lost updates under concurrent requests.
  // Remove allocation (hot-remove supported for running servers)
  app.delete(
    "/:serverId/allocations/:containerPort",
    { onRequest: [app.authenticate] },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const { serverId, containerPort } = request.params as {
        serverId: string;
        containerPort: string;
      };
      const userId = request.user.userId;

      const server = await prisma.server.findUnique({
        where: { id: serverId },
        include: { access: true, node: true },
      });

      if (!server) {
        return reply.status(404).send({ error: "Server not found" });
      }

      if (!ensureNotSuspended(server, reply)) {
        return;
      }

      const isAdmin = checkIsAdmin(request, 'admin.read');
      const hasWriteAccess = server.access.some(
        (access) => access.userId === userId &&
          (access.permissions.includes('server.update') || access.permissions.includes('server.delete'))
      );
      const hasNodeAccessResult = await hasNodeAccess(prisma, userId, server.nodeId);
      const hasAccess = server.ownerId === userId || hasWriteAccess || isAdmin || hasNodeAccessResult;
      if (!hasAccess) {
        return reply.status(403).send({ error: "Forbidden" });
      }

      // Allow allocation removal on stopped, running, crashed, and error servers (hot-remove)
      if (!ALLOCATION_ALLOWED_STATUSES.has(server.status)) {
        return reply.status(409).send({
          error: `Server must be in one of these statuses to update allocations: ${[...ALLOCATION_ALLOWED_STATUSES].join(', ')}`,
        });
      }

      const parsedContainerPort = parsePortValue(containerPort);
      if (!parsedContainerPort) {
        return reply.status(400).send({ error: "Invalid port value" });
      }

      // Primary allocation cannot be removed regardless of server status (AC-4)
      if (parsedContainerPort === server.primaryPort) {
        return reply.status(400).send({ error: "Cannot remove primary allocation" });
      }

      const bindings = parseStoredPortBindings(server.portBindings);
      if (!bindings[parsedContainerPort]) {
        return reply.status(404).send({ error: "Allocation not found" });
      }

      const removedHostPort = bindings[parsedContainerPort];

      delete bindings[parsedContainerPort];

      await prisma.server.update({
        where: { id: serverId },
        data: { portBindings: bindings },
      });

      const wsGateway = app.wsGateway;

      // If server is running, notify the agent to close the firewall port
      if (server.status === "running" && wsGateway?.sendToAgent) {
        const containerIp = server.primaryIp ?? "";
        // Send the remaining port bindings so the agent can re-add surviving rules
        // after removing all rules for this server (remove_server_ports is server-scoped)
        wsGateway.sendToAgent(server.nodeId, {
          type: "allocation_removed",
          serverId,
          serverUuid: server.uuid,
          containerPort: parsedContainerPort,
          hostPort: removedHostPort,
          containerIp,
          networkMode: server.networkMode ?? "bridge",
          protocol: "tcp",
          remainingPortBindings: bindings, // the updated bindings after deletion
        }).catch(() => {
          // Best-effort — agent may be temporarily disconnected; reconciliation will catch up.
        });
      }

      if (wsGateway?.pushToAdminSubscribers) {
        wsGateway.pushToAdminSubscribers('server_updated', {
          type: 'server_updated',
          serverId,
          updatedBy: userId,
          change: 'allocation_removed',
          timestamp: new Date().toISOString(),
        });
      }
      if (wsGateway?.pushToGlobalSubscribers) {
        wsGateway.pushToGlobalSubscribers('server_updated', {
          type: 'server_updated',
          serverId,
          updatedBy: userId,
          change: 'allocation_removed',
          timestamp: new Date().toISOString(),
        });
      }

      reply.send({ success: true });
    }
  );

  // Set primary allocation (allowed when running — no firewall change needed, just metadata swap)
  app.post(
    "/:serverId/allocations/primary",
    { onRequest: [app.authenticate] },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const { serverId } = request.params as { serverId: string };
      const { containerPort } = request.body as { containerPort: number };
      const userId = request.user.userId;

      const server = await prisma.server.findUnique({
        where: { id: serverId },
        include: { access: true },
      });

      if (!server) {
        return reply.status(404).send({ error: "Server not found" });
      }

      if (!ensureNotSuspended(server, reply)) {
        return;
      }

      const isAdmin = checkIsAdmin(request, 'admin.read');
      const hasWriteAccess = server.access.some(
        (access) => access.userId === userId &&
          (access.permissions.includes('server.update') || access.permissions.includes('server.delete'))
      );
      const hasNodeAccessResult = await hasNodeAccess(prisma, userId, server.nodeId);
      const hasAccess = server.ownerId === userId || hasWriteAccess || isAdmin || hasNodeAccessResult;
      if (!hasAccess) {
        return reply.status(403).send({ error: "Forbidden" });
      }

      // Primary allocation change is allowed on stopped, running, crashed, and error servers
      if (!ALLOCATION_ALLOWED_STATUSES.has(server.status)) {
        return reply.status(409).send({
          error: `Server must be in one of these statuses to update allocations: ${[...ALLOCATION_ALLOWED_STATUSES].join(', ')}`,
        });
      }

      const parsedContainerPort = parsePortValue(containerPort);
      if (!parsedContainerPort) {
        return reply.status(400).send({ error: "Invalid port value" });
      }

      const bindings = parseStoredPortBindings(server.portBindings);
      if (!bindings[parsedContainerPort]) {
        return reply.status(404).send({ error: "Allocation not found" });
      }

      const updated = await prisma.server.update({
        where: { id: serverId },
        data: { primaryPort: parsedContainerPort },
      });

      const wsGateway = app.wsGateway;
      if (wsGateway?.pushToAdminSubscribers) {
        wsGateway.pushToAdminSubscribers('server_updated', {
          type: 'server_updated',
          serverId,
          updatedBy: userId,
          change: 'primary_allocation_changed',
          timestamp: new Date().toISOString(),
        });
      }
      if (wsGateway?.pushToGlobalSubscribers) {
        wsGateway.pushToGlobalSubscribers('server_updated', {
          type: 'server_updated',
          serverId,
          updatedBy: userId,
          change: 'primary_allocation_changed',
          timestamp: new Date().toISOString(),
        });
      }

      reply.send({
        success: true,
        data: {
          primaryPort: updated.primaryPort,
        },
      });
    }
  );

  // Update restart policy
}
