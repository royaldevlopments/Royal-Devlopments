import type pino from "pino";
import crypto from "crypto";
import type { PrismaClient } from "@prisma/client";
import { Prisma } from "@prisma/client";
import type { FastifyRequest } from "fastify";
import { auth } from "../auth";
import { verifyAgentApiKey } from "../lib/agent-auth";
import type {
  WsEvent} from "../shared-types";
import {
  ServerState,
  CatalystError,
  ErrorCodes,
} from "../shared-types";
import { hasPermission, hasNodeAccess } from "../lib/permissions";
import { sanitizeInput } from "../lib/validation";
import { ServerStateMachine } from "../services/state-machine";
import { normalizeHostIp } from "../utils/ipam";
import { captureSystemError } from "../services/error-logger";

/**
 * Simple capped Map that evicts the oldest entries when max size is reached.
 * Used as a lightweight LRU when lru-cache is not available.
 */
class CappedMap<K, V> extends Map<K, V> {
  constructor(private maxSize: number) {
    super();
  }

  set(key: K, value: V): this {
    if (this.size >= this.maxSize && !this.has(key)) {
      const first = this.keys().next().value;
      if (first !== undefined) {
        this.delete(first);
      }
    }
    return super.set(key, value);
  }
}

const DEFAULT_CONSOLE_OUTPUT_BYTE_LIMIT = 2 * 1024 * 1024; // 2MB/s per server
const MIN_CONSOLE_OUTPUT_BYTE_LIMIT = 256 * 1024;
const MAX_CONSOLE_OUTPUT_BYTE_LIMIT = 10 * 1024 * 1024;

const resolveConsoleOutputByteLimit = (value?: number | null) => {
  const raw =
    typeof value === "number" && Number.isFinite(value) && value > 0
      ? value
      : Number.parseInt(process.env.CONSOLE_OUTPUT_BYTE_LIMIT_BYTES ?? "", 10);
  if (!Number.isFinite(raw) || raw <= 0) {
    return DEFAULT_CONSOLE_OUTPUT_BYTE_LIMIT;
  }
  return Math.min(MAX_CONSOLE_OUTPUT_BYTE_LIMIT, Math.max(MIN_CONSOLE_OUTPUT_BYTE_LIMIT, raw));
};

/**
 * Syncs port-related environment variables with the primaryPort.
 * This ensures that the server listens on the same port that is used for port forwarding.
 */
const syncPortEnvironmentVariables = (
  environment: Record<string, string>,
  primaryPort: number,
  portBindings?: Record<string, unknown>
): Record<string, string> => {
  const syncedEnv = { ...environment };

  // List of common primary port environment variable names
  const primaryPortVarNames = ["SERVER_PORT", "PORT", "GAME_PORT"];

  // Sync primary port variables if they exist in the environment
  for (const varName of primaryPortVarNames) {
    if (syncedEnv[varName] !== undefined) {
      syncedEnv[varName] = String(primaryPort);
    }
  }

  // Handle QUERY_PORT specially - if it's the primary port + 1, update it accordingly
  if (syncedEnv.QUERY_PORT !== undefined && portBindings) {
    // Find if there's a secondary port binding that's primary + 1
    const queryBinding = Object.entries(portBindings).find(
      ([containerPort, hostPort]) => {
        const cp = Number(containerPort);
        const hp = Number(hostPort);
        // Check if this is a query port (typically game port + 1)
        return cp === primaryPort + 1 || hp === primaryPort + 1;
      }
    );
    if (queryBinding) {
      syncedEnv.QUERY_PORT = queryBinding[0]; // Use container port
    }
  }

  return syncedEnv;
};

interface ConnectedAgent {
  nodeId: string;
  socket: any;
  authenticated: boolean;
  lastHeartbeat: number;
}

interface ClientConnection {
  userId: string;
  socket: any;
  authenticated: boolean;
  subscriptions: Set<string>;
  lastAuthAt?: number;
}

type PendingAgentRequest = {
  resolve: (value: any) => void;
  reject: (error: Error) => void;
  timeout: ReturnType<typeof setTimeout>;
  kind: "json" | "binary";
  chunks?: Buffer[];
  onChunk?: (chunk: Buffer) => void;
};

export class WebSocketGateway {
  private agents = new Map<string, ConnectedAgent>();
  private clients = new Map<string, ClientConnection>();
  private logger: pino.Logger;
  private pendingAgentRequests = new Map<string, PendingAgentRequest>();
  private activeBackupRelay: { sourceNodeId: string; targetNodeId: string; resolve: () => void; reject: (err: Error) => void } | null = null;
  private consoleOutputCounters = new Map<string, { count: number; resetAt: number; warned: boolean }>();
  private clientCommandCounters = new Map<string, { count: number; resetAt: number }>();
  private agentMessageCounters = new Map<string, { count: number; resetAt: number }>();
  private agentMetricsCounters = new Map<string, { count: number; resetAt: number }>();
  private serverMetricsCounters = new Map<string, { count: number; resetAt: number }>();
  private agentLimitWarnings = new Map<string, { resetAt: number }>();
  private serverCommandCounters = new Map<string, { count: number; resetAt: number }>();

  // Cache server access lists to avoid DB query on every routeToClients call.
  // Refreshed every 30 seconds per server.
  private serverAccessCache = new CappedMap<string, { allowedUsers: Set<string>; expiresAt: number }>(5000);
  private latestResourceStats = new CappedMap<string, Record<string, unknown>>(5000);
  private static readonly SERVER_ACCESS_TTL_MS = 30_000;
  private serverConsoleBytes = new Map<string, { count: number; resetAt: number }>();
  private consoleResumeTimestamps = new Map<string, number>();
  private lastConsoleLimitRefreshAt = 0;
  private consoleOutputLimit = { max: 2000, windowMs: 1000 };
  private readonly consoleLimitRefreshIntervalMs = 5000;
  private consoleInputLimit = { max: 10, windowMs: 1000 };
  private agentMessageLimit = { max: 10000, windowMs: 1000 };
  private agentMetricsLimit = { max: 1000, windowMs: 1000 };
  private serverMetricsLimit = { max: 1, windowMs: 1000 };
  private readonly agentConsoleBytesLimit = { maxBytes: resolveConsoleOutputByteLimit() };
  private readonly pendingAgentRequestLimit = 2000;
  private readonly autoRestartingServers = new Set<string>();
  // Track the last agent update version requested per node to avoid spamming.
  // Maps nodeId → target version string that was already sent.
  private readonly agentUpdateSent = new Map<string, string>();
  private heartbeatInterval?: ReturnType<typeof setInterval>;
  private subscriberSweepInterval?: ReturnType<typeof setInterval>;

  // SSE console stream subscribers — maps serverId → subscriberId → { push, lastActivity }
  private readonly sseSubscribers = new Map<string, Map<string, { push: (event: string, data: any) => void; lastActivity: number }>>();
  // SSE event subscribers — maps serverId → subscriberId → { eventTypes, push, lastActivity }
  // Used for non-console events (state updates, backups, alerts, etc.)
  private readonly sseEventSubscribers = new Map<string, Map<string, { eventTypes: string[]; push: (event: string, data: any) => void; lastActivity: number }>>();
  // Global SSE event subscribers — receive ALL events across all servers (for AppLayout)
  private readonly globalSseSubscribers = new Map<string, { eventTypes: string[]; push: (event: string, data: any) => void; serverIds?: Set<string>; lastActivity: number }>();
  // Admin SSE event subscribers — receive entity-level admin events (users, nodes, templates, alerts)
  private readonly adminEventSubscribers = new Map<string, { eventTypes: string[]; push: (event: string, data: any) => void; lastActivity: number }>();
  // Discovered containers on nodes (for auto-import of existing servers)
  private discoveredContainers = new Map<string, Array<{
    containerId: string;
    image: string;
    status: string;
    labels: Record<string, string>;
    networkMode?: string;
    memoryLimitMb?: number;
    cpuCores?: number;
    startupCommand?: string;
    envVarNames?: string[];
    discoveredAt: number;
  }>>();

  // ── Agent auth lockout tracker (progressive backoff) ───────────────────────
  // Tracks failed auth attempts per nodeId. Lockout durations increase with
  // each successive failure: 5s, 15s, 60s, 300s, 900s, 3600s (max 1 hour).
  private agentAuthFailures = new Map<string, { count: number; lockedUntil: number }>();
  private static readonly AGENT_LOCKOUT_BASE_SECONDS = [5, 15, 60, 300, 900, 3600];

  private getAgentLockoutSeconds(failureCount: number): number {
    const tiers = WebSocketGateway.AGENT_LOCKOUT_BASE_SECONDS;
    return tiers[Math.min(failureCount - 1, tiers.length - 1)];
  }

  private recordAgentAuthFailure(nodeId: string): number {
    const entry = this.agentAuthFailures.get(nodeId);
    const now = Date.now();
    if (!entry || now >= entry.lockedUntil) {
      // First failure or previous lockout expired — start fresh
      const lockoutSeconds = this.getAgentLockoutSeconds(1);
      this.agentAuthFailures.set(nodeId, { count: 1, lockedUntil: now + lockoutSeconds * 1000 });
      return lockoutSeconds;
    }
    // Still within lockout window — increment and extend
    entry.count += 1;
    const lockoutSeconds = this.getAgentLockoutSeconds(entry.count);
    entry.lockedUntil = now + lockoutSeconds * 1000;
    return lockoutSeconds;
  }

  private checkAgentLockout(nodeId: string): { locked: boolean; retryAfterSeconds: number } {
    const entry = this.agentAuthFailures.get(nodeId);
    if (!entry) return { locked: false, retryAfterSeconds: 0 };
    const now = Date.now();
    if (now >= entry.lockedUntil) {
      // Lockout expired, clean up
      this.agentAuthFailures.delete(nodeId);
      return { locked: false, retryAfterSeconds: 0 };
    }
    return { locked: true, retryAfterSeconds: Math.ceil((entry.lockedUntil - now) / 1000) };
  }

  private clearAgentAuthFailures(nodeId: string): void {
    this.agentAuthFailures.delete(nodeId);
  }

  // ── Plugin WebSocket handler dispatch ─────────────────────────────────────
  // Maps prefixed message types (e.g. "plugin:ticketing-plugin:subscribe")
  // to the handler registered by the plugin and the plugin name.
  private pluginWsHandlers = new Map<
    string,
    { handler: (data: any, clientId?: string, userId?: string) => Promise<void> | void; pluginName: string }
  >();

  // Connection limits (environment-driven with safe defaults)
  private readonly MAX_AGENT_CONNECTIONS = Number(process.env.MAX_AGENT_CONNECTIONS || 1000);
  private readonly MAX_CLIENT_CONNECTIONS = Number(process.env.MAX_CLIENT_CONNECTIONS || 10000);
  private readonly MAX_CONNECTIONS_PER_USER = Number(process.env.MAX_CONNECTIONS_PER_USER || 10);

  // SSE hard caps
  private readonly MAX_SSE_CONSOLE_PER_SERVER = 50;
  private readonly MAX_SSE_EVENTS_PER_SERVER = 100;

  constructor(private prisma: PrismaClient, logger: pino.Logger) {
    this.logger = logger.child({ component: "WebSocketGateway" });
    this.startHeartbeatCheck();
    this.startMaintenanceSweep();
    this.refreshConsoleLimits().catch((err) =>
      this.logger.warn({ err }, "Failed to load console rate limits")
    );
  }

  private async refreshConsoleLimits() {
    const settings = await this.prisma.systemSetting.findUnique({ where: { id: "security" } });
    if (settings?.consoleRateLimitMax && settings.consoleRateLimitMax > 0) {
      this.consoleInputLimit = { max: settings.consoleRateLimitMax, windowMs: settings.consoleRateLimitWindowMs ?? 60_000 };
    }
    if (settings?.consoleRateLimitWindowMs && settings.consoleRateLimitWindowMs > 0) {
      this.consoleInputLimit = { ...this.consoleInputLimit, windowMs: settings.consoleRateLimitWindowMs };
    }
    if (settings?.consoleOutputLinesMax && settings.consoleOutputLinesMax > 0) {
      this.consoleOutputLimit = { ...this.consoleOutputLimit, max: settings.consoleOutputLinesMax };
    }
    if (settings?.agentMessageMax && settings.agentMessageMax > 0) {
      this.agentMessageLimit = { ...this.agentMessageLimit, max: settings.agentMessageMax };
    }
    if (settings?.agentMetricsMax && settings.agentMetricsMax > 0) {
      this.agentMetricsLimit = { ...this.agentMetricsLimit, max: settings.agentMetricsMax };
    }
    if (settings?.serverMetricsMax && settings.serverMetricsMax > 0) {
      this.serverMetricsLimit = { ...this.serverMetricsLimit, max: settings.serverMetricsMax };
    }
    this.agentConsoleBytesLimit.maxBytes = resolveConsoleOutputByteLimit(
      settings?.consoleOutputByteLimitBytes
    );
  }

  private async authenticateAgentToken(nodeId: string, tokenValue: string) {
    if (!tokenValue) return null;
    const node = await this.prisma.node.findUnique({ where: { id: nodeId } });
    if (!node) return null;
    if (await verifyAgentApiKey(this.prisma, nodeId, tokenValue)) {
      return { node, authType: "api_key" as const };
    }
    return null;
  }

  async handleConnection(socket: any, request: FastifyRequest) {
    const query = (request.query as any) || {};
    const token = typeof query.token === "string" ? query.token : null;
    const nodeId =
      typeof query.nodeId === "string"
        ? query.nodeId
        : null;

    if (nodeId) {
      // Agent connection (token is expected in handshake if not provided here)
      await this.handleAgentConnection(socket, nodeId, token);
    } else {
      // Client connection (token expected via Authorization header)
      await this.handleClientConnection(socket, request);
    }
  }

  private async handleAgentConnection(socket: any, nodeId: string, token: string | null) {
    try {
      // Check agent connection limit
      if (this.agents.size >= this.MAX_AGENT_CONNECTIONS) {
        this.logger.warn({ nodeId }, `Agent connection rejected: limit reached (${this.MAX_AGENT_CONNECTIONS})`);
        socket.send(JSON.stringify({ type: 'error', error: 'Connection limit reached' }));
        socket.close();
        return;
      }
      
      const agent: ConnectedAgent = {
        nodeId,
        socket,
        authenticated: false,
        lastHeartbeat: Date.now(),
      };
      const onMessage = (data: any, isBinary: boolean) => this.handleAgentMessage(nodeId, socket, data, isBinary);
      const onClose = () => {
        const current = this.agents.get(nodeId);
        if (!current || current.socket !== socket) {
          this.logger.debug({ nodeId }, "Ignoring close from stale agent socket");
          return;
        }
        this.agents.delete(nodeId);
        this.agentUpdateSent.delete(nodeId);
        this.discoveredContainers.delete(nodeId);
        this.prisma.node.update({
          where: { id: nodeId },
          data: { isOnline: false },
        }).catch(err => {
          this.logger.error({ err, nodeId }, 'Failed to update node status on disconnect');
          captureSystemError({
            level: 'error',
            component: 'WebSocketGateway',
            message: `Failed to update node status on disconnect: ${nodeId}`,
            stack: err instanceof Error ? err.stack : undefined,
            metadata: { nodeId },
          }).catch(() => {});
        });

        // Revert stuck backup/restore states for servers on this node
        this.prisma.server.findMany({
          where: {
            nodeId,
            status: { in: [ServerState.CREATING_BACKUP, ServerState.RESTORING] },
          },
          select: { id: true, status: true },
        }).then(async (stuckServers) => {
          for (const server of stuckServers) {
            await this.prisma.server.update({
              where: { id: server.id },
              data: { status: ServerState.STOPPED },
            });
            await this.prisma.serverLog.create({
              data: {
                serverId: server.id,
                stream: "system",
                data: `[Node Disconnect] Node ${nodeId} went offline while server was in ${server.status}. Transitioned to STOPPED.`,
              },
            });
            await this.routeToClients(server.id, {
              type: "server_state_update",
              serverId: server.id,
              state: ServerState.STOPPED,
              reason: `Node ${nodeId} disconnected during ${server.status}`,
              timestamp: Date.now(),
            });
            this.logger.info(
              { serverId: server.id, nodeId, fromStatus: server.status },
              "Reverted stuck state to STOPPED on node disconnect"
            );
          }
        }).catch(err => {
          this.logger.error({ err, nodeId }, "Failed to revert stuck states on node disconnect");
        });

        this.pushToAdminSubscribers('node_updated', {
          type: 'node_updated',
          nodeId,
          isOnline: false,
          timestamp: Date.now(),
        });
        this.logger.info(`Agent disconnected: ${nodeId}`);
      };

      if (token) {
        // Check progressive lockout before attempting auth
        const lockout = this.checkAgentLockout(nodeId);
        if (lockout.locked) {
          this.logger.warn(
            { nodeId, retryAfterSeconds: lockout.retryAfterSeconds },
            `Agent connection rejected: auth lockout active for ${lockout.retryAfterSeconds}s`,
          );
          socket.send(JSON.stringify({ type: 'error', error: 'auth_lockout', retryAfterSeconds: lockout.retryAfterSeconds }));
          socket.close();
          return;
        }

        const authResult = await this.authenticateAgentToken(nodeId, token);
        if (authResult) {
          this.clearAgentAuthFailures(nodeId);
          const existing = this.agents.get(nodeId);
          if (existing && existing.socket !== socket) {
            this.logger.warn({ nodeId }, "Replacing existing agent connection");
            try {
              existing.socket.close();
            } catch {
              // ignore close errors
            }
          }
          this.agents.set(nodeId, agent);
          socket.on("message", onMessage);
          socket.on("close", onClose);
          this.logger.info(
            { nodeId, authType: authResult.authType },
            "Agent authenticated during connection",
          );
          agent.authenticated = true;
          await this.finalizeAgentConnection(authResult.node, agent);
        } else {
          const lockoutSeconds = this.recordAgentAuthFailure(nodeId);
          this.logger.warn(
            { nodeId, failureCount: this.agentAuthFailures.get(nodeId)?.count, lockoutSeconds },
            `Agent authentication failed for node: ${nodeId} — locked out for ${lockoutSeconds}s`,
          );
          socket.send(JSON.stringify({ type: 'error', error: 'auth_failed', retryAfterSeconds: lockoutSeconds }));
          agent.socket.close();
        }
      } else {
        // No token in URL - agent will send handshake with token
        // Add to agents map so handleAgentMessage can find it
        const existing = this.agents.get(nodeId);
        if (existing && existing.socket !== socket) {
          this.logger.warn({ nodeId }, "Replacing existing agent connection");
          try {
            existing.socket.close();
          } catch {
            // ignore close errors
          }
        }
        this.agents.set(nodeId, agent);
        socket.on("message", onMessage);
        socket.on("close", onClose);
        // Check progressive lockout for handshake path too
        const lockout = this.checkAgentLockout(nodeId);
        if (lockout.locked) {
          this.logger.warn(
            { nodeId, retryAfterSeconds: lockout.retryAfterSeconds },
            `Agent connection rejected: auth lockout active for ${lockout.retryAfterSeconds}s (handshake path)`,
          );
          socket.send(JSON.stringify({ type: 'error', error: 'auth_lockout', retryAfterSeconds: lockout.retryAfterSeconds }));
          socket.close();
          return;
        }

        this.logger.info({ nodeId }, "Agent connected, awaiting handshake");

        // Disconnect agent if handshake not completed within 10 seconds
        setTimeout(() => {
          const pending = this.agents.get(nodeId);
          if (pending && pending.socket === socket && !pending.authenticated) {
            pending.socket.close();
            this.agents.delete(nodeId);
        this.agentUpdateSent.delete(nodeId);
            this.logger.warn({ nodeId }, "Agent handshake timeout");
          }
        }, 10000);
      }
    } catch (err) {
      this.logger.error(err, "Error in agent connection");
      captureSystemError({
        level: 'error',
        component: 'WebSocketGateway',
        message: err instanceof Error ? err.message : 'Error in agent connection',
        stack: err instanceof Error ? err.stack : undefined,
        metadata: { nodeId },
      }).catch(() => {});
      socket.close();
    }
  }

  private async finalizeAgentConnection(node: any, agent: ConnectedAgent) {
    // Note: agent.authenticated should be set to true BEFORE calling this function
    // to prevent race conditions with the handshake timeout
    await this.prisma.node.update({
      where: { id: node.id },
      data: { isOnline: true, lastSeenAt: new Date() },
    });
    this.pushToAdminSubscribers('node_updated', {
      type: 'node_updated',
      nodeId: node.id,
      isOnline: true,
      timestamp: Date.now(),
    });
    this.logger.info(`Agent connected: ${node.id} (${node.hostname})`);
    agent.socket.send(
      JSON.stringify({
        type: "node_handshake_response",
        success: true,
        backendAddress: process.env.BACKEND_EXTERNAL_ADDRESS || "http://localhost:3000",
      })
    );
    await this.resumeConsoleStreams(node.id);
  }

  private async resumeConsoleStreams(nodeId: string) {
    try {
      const servers = await this.prisma.server.findMany({
        where: {
          nodeId,
          status: { in: ["running", "starting"] },
        },
        select: {
          id: true,
          uuid: true,
        },
      });

      if (!servers.length) {
        return;
      }

      const agent = this.agents.get(nodeId);
      if (!agent || agent.socket.readyState !== 1) {
        return;
      }

      for (const server of servers) {
        agent.socket.send(
          JSON.stringify({
            type: "resume_console",
            serverId: server.id,
            serverUuid: server.uuid,
          })
        );
      }
    } catch (err) {
      captureSystemError({
        level: 'error',
        component: 'WebSocketGateway',
        message: err instanceof Error ? err.message : 'Failed to resume console streams',
        stack: err instanceof Error ? err.stack : undefined,
        metadata: { nodeId },
      }).catch(() => {});
      this.logger.error(err, "Failed to resume console streams");
    }
  }

  private async handleClientConnection(socket: any, request: FastifyRequest) {
    try {
      // Check overall client connection limit
      if (this.clients.size >= this.MAX_CLIENT_CONNECTIONS) {
        this.logger.warn('Client connection rejected: overall limit reached');
        socket.send(JSON.stringify({ type: 'error', error: 'Connection limit reached' }));
        socket.close();
        return;
      }
      
      const clientId = `pending-${Date.now()}-${Math.random().toString(36).slice(2)}`;
      const client: ClientConnection = {
        userId: "",
        socket,
        authenticated: false,
        subscriptions: new Set<string>(),
      };
      this.clients.set(clientId, client);
      this.logger.info(`Client connected (pending auth): ${clientId}`);

      // Try to authenticate immediately via cookies from upgrade request
      try {
        const cookieHeader = request.headers.cookie || "";
        this.logger.debug({ clientId, hasCookie: !!cookieHeader, cookieLength: cookieHeader.length }, "Attempting cookie auth");
        const session = await auth.api.getSession({
          headers: new Headers({ cookie: cookieHeader }),
        });
        if (session?.user?.id) {
          // Check per-user connection limit
          const userConnections = Array.from(this.clients.values()).filter(c => c.userId === session.user.id).length;
          if (userConnections >= this.MAX_CONNECTIONS_PER_USER) {
            this.logger.warn({ userId: session.user.id, current: userConnections }, 'User connection limit reached');
            socket.send(JSON.stringify({ type: 'error', error: 'Too many connections for this user' }));
            this.clients.delete(clientId);
            socket.close();
            return;
          }
          
          client.userId = session.user.id;
          client.authenticated = true;
          client.lastAuthAt = Date.now();
          this.logger.info({ clientId, userId: session.user.id }, "Client authenticated via cookie");
        } else {
          this.logger.debug({ clientId, hasSession: !!session }, "Cookie auth returned no user");
        }
      } catch (cookieErr) {
        this.logger.debug({ clientId, err: cookieErr }, "Cookie auth failed, waiting for handshake");
      }

      socket.on("message", (data: any) => {
        this.logger.info({ clientId, dataType: typeof data, dataLength: data?.length }, "Raw message received");
        this.handleClientMessage(clientId, data);
      });
      socket.on("close", () => {
        this.clients.delete(clientId);
        this.clientCommandCounters.delete(clientId);
        this.logger.info(`Client disconnected: ${clientId}`);
      });

      setTimeout(() => {
        const pending = this.clients.get(clientId);
        if (pending && !pending.authenticated) {
          pending.socket.close();
          this.clients.delete(clientId);
          this.logger.warn({ clientId }, "Client handshake timeout");
        }
      }, 3000);  // Reduced from 5s to 3s
    } catch (err) {
      this.logger.error(err, "Error in client connection");
      captureSystemError({
        level: 'error',
        component: 'WebSocketGateway',
        message: err instanceof Error ? err.message : 'Error in client connection',
        stack: err instanceof Error ? err.stack : undefined,
      }).catch(() => {});
      socket.close();
    }
  }

  private async userHasAdminRead(userId: string) {
    try {
      return await hasPermission(this.prisma, userId, "admin.read");
    } catch (err) {
      this.logger.warn({ err, userId }, "Failed to evaluate admin.read permission");
      return false;
    }
  }

  private allowAgentMessage(nodeId: string, limit: { max: number; windowMs: number }) {
    const now = Date.now();
    const existing = this.agentMessageCounters.get(nodeId);
    if (!existing || now >= existing.resetAt) {
      this.agentMessageCounters.set(nodeId, { count: 1, resetAt: now + limit.windowMs });
      return true;
    }
    if (existing.count >= limit.max) {
      return false;
    }
    existing.count += 1;
    return true;
  }

  private allowAgentMetrics(nodeId: string, count = 1) {
    const now = Date.now();
    const existing = this.agentMetricsCounters.get(nodeId);
    if (!existing || now >= existing.resetAt) {
      this.agentMetricsCounters.set(nodeId, { count, resetAt: now + this.agentMetricsLimit.windowMs });
      return true;
    }
    if (existing.count + count > this.agentMetricsLimit.max) {
      return false;
    }
    existing.count += count;
    return true;
  }

  private allowServerMetrics(serverId: string, count = 1) {
    const now = Date.now();
    const existing = this.serverMetricsCounters.get(serverId);
    if (!existing || now >= existing.resetAt) {
      this.serverMetricsCounters.set(serverId, { count, resetAt: now + this.serverMetricsLimit.windowMs });
      return true;
    }
    if (existing.count + count > this.serverMetricsLimit.max) {
      return false;
    }
    existing.count += count;
    return true;
  }

  private shouldWarnRateLimit(nodeId: string, windowMs: number) {
    const now = Date.now();
    const existing = this.agentLimitWarnings.get(nodeId);
    if (!existing || now >= existing.resetAt) {
      this.agentLimitWarnings.set(nodeId, { resetAt: now + windowMs });
      return true;
    }
    return false;
  }

  private allowServerCommand(serverId: string) {
    const now = Date.now();
    const existing = this.serverCommandCounters.get(serverId);
    if (!existing || now >= existing.resetAt) {
      this.serverCommandCounters.set(serverId, { count: 1, resetAt: now + this.consoleInputLimit.windowMs });
      return true;
    }
    if (existing.count >= this.consoleInputLimit.max) {
      return false;
    }
    existing.count += 1;
    return true;
  }

  private allowConsoleOutputBytes(serverId: string, bytes: number) {
    const now = Date.now();
    const windowMs = this.consoleOutputLimit.windowMs;
    const limit = this.agentConsoleBytesLimit.maxBytes;
    this.maybeRefreshConsoleLimits(now);
    const existing = this.serverConsoleBytes.get(serverId);
    if (!existing || now >= existing.resetAt) {
      this.serverConsoleBytes.set(serverId, { count: bytes, resetAt: now + windowMs });
      return bytes <= limit;
    }
    existing.count += bytes;
    return existing.count <= limit;
  }

  private parseAgentMessage(data: any): { ok: true; value: any } | { ok: false } {
    try {
      if (typeof data === "string") {
        return { ok: true, value: JSON.parse(data) };
      }
      if (Buffer.isBuffer(data)) {
        return { ok: true, value: JSON.parse(data.toString()) };
      }
      if (data?.toString) {
        return { ok: true, value: JSON.parse(data.toString()) };
      }
      return { ok: false };
    } catch {
      return { ok: false };
    }
  }

  private async handleAgentMessage(nodeId: string, socket: any, data: any, isBinary?: boolean) {
    try {
      // Binary frames: forward to active relay if one exists
      if (isBinary && this.activeBackupRelay) {
        const targetAgent = this.agents.get(this.activeBackupRelay.targetNodeId);
        if (targetAgent && targetAgent.socket.readyState === 1) {
          targetAgent.socket.send(data);
        }
        return;
      }

      if (!this.allowAgentMessage(nodeId, this.agentMessageLimit)) {
        if (this.shouldWarnRateLimit(nodeId, this.agentMessageLimit.windowMs)) {
          this.logger.warn({ nodeId }, "Agent message rate limit exceeded");
        }
        return;
      }
      const parsed = this.parseAgentMessage(data);
      if (!parsed.ok || !parsed.value || typeof parsed.value !== "object") {
        this.logger.warn({ nodeId }, "Invalid agent message payload");
        return;
      }
      const message = parsed.value;
      if (typeof message.type !== "string") {
        this.logger.warn({ nodeId }, "Agent message missing type");
        return;
      }
      const agent = this.agents.get(nodeId);
      if (!agent) return;
      if (agent.socket !== socket) {
        this.logger.debug({ nodeId }, "Ignoring message from stale agent socket");
        return;
      }
      if (!agent.authenticated && message.type !== "node_handshake") {
        this.logger.warn({ nodeId }, "Rejected agent message before handshake");
        return;
      }
      if (message.type === "node_handshake") {
        if (agent.authenticated) {
          this.logger.debug({ nodeId }, "Ignoring redundant node_handshake for authenticated agent");
          return;
        }
        this.logger.info({ nodeId, hasToken: Boolean(message.token) }, "Received node_handshake from agent");
        const tokenValue = typeof message.token === "string" ? message.token : "";
        const authResult = await this.authenticateAgentToken(nodeId, tokenValue);
        this.logger.debug(
          { nodeId, tokenProvided: Boolean(tokenValue), authType: authResult?.authType },
          "Agent auth check",
        );
        if (!authResult) {
          const lockoutSeconds = this.recordAgentAuthFailure(nodeId);
          this.logger.warn(
            { nodeId, token: Boolean(tokenValue), lockoutSeconds },
            `Agent authentication failed for node: ${nodeId} — locked out for ${lockoutSeconds}s`,
          );
          try {
            agent.socket.send(JSON.stringify({ type: 'error', error: 'auth_failed', retryAfterSeconds: lockoutSeconds }));
          } catch { /* socket may already be closing */ }
          agent.socket.close();
          this.agents.delete(nodeId);
        this.agentUpdateSent.delete(nodeId);
          return;
        }
        this.clearAgentAuthFailures(nodeId);
        // Set authenticated flag IMMEDIATELY to prevent timeout from disconnecting during async operations
        agent.authenticated = true;
        await this.finalizeAgentConnection(authResult.node, agent);

        // Check if agent needs update immediately on handshake,
        // rather than waiting for the first health_report.
        // Also persist the version to the database.
        if (message.agentVersion && typeof message.agentVersion === 'string') {
          await this.prisma.node.update({
            where: { id: nodeId },
            data: { agentVersion: String(message.agentVersion) },
          }).catch(() => {});
          this.checkAgentUpdate(nodeId, message.agentVersion).catch(() => {});
        }
        return;
      }
      // Treat any authenticated agent message as liveness to avoid false disconnects
      // when heartbeat packets are delayed but other traffic is active.
      agent.lastHeartbeat = Date.now();

      if (message.type === "backup_download_response") {
        const pending = message.requestId
          ? this.pendingAgentRequests.get(message.requestId)
          : undefined;
        if (pending) {
          clearTimeout(pending.timeout);
          if (message.success === false) {
            pending.reject(new Error("Backup download failed"));
          } else {
            pending.resolve(message);
          }
          this.pendingAgentRequests.delete(message.requestId);
        } else {
          this.logger.warn({ requestId: message.requestId }, "No pending download request");
        }
        return;
      }

      if (message.type === "backup_upload_response") {
        const pending = message.requestId
          ? this.pendingAgentRequests.get(message.requestId)
          : undefined;
        if (pending) {
          clearTimeout(pending.timeout);
          if (message.success === false) {
            pending.reject(new Error("Backup upload failed"));
          } else {
            pending.resolve(message);
          }
          this.pendingAgentRequests.delete(message.requestId);
        } else {
          this.logger.warn({ requestId: message.requestId }, "No pending upload request");
        }
        return;
      }

      if (message.type === "backup_upload_chunk_response") {
        return;
      }

      if (message.type === "backup_stream_complete") {
        this.resolveBackupRelay(nodeId);
        return;
      }

      // Generic pending request resolver — any message with a requestId that
      // matches a pending request will resolve it.
      if (message.requestId) {
        const pending = this.pendingAgentRequests.get(message.requestId);
        if (pending && pending.kind === "json") {
          clearTimeout(pending.timeout);
          this.pendingAgentRequests.delete(message.requestId);
          pending.resolve(message);
          return;
        }
      }

      if (message.type === "backup_download_chunk") {
        const pending = message.requestId
          ? this.pendingAgentRequests.get(message.requestId)
          : undefined;
        if (!pending || pending.kind !== "binary") {
          this.logger.warn({ requestId: message.requestId }, "No pending chunk request");
          return;
        }
        if (message.error) {
          clearTimeout(pending.timeout);
          captureSystemError({
            level: 'error',
            component: 'WebSocketGateway',
            message: `Agent download chunk error: ${message.error}`,
            metadata: { requestId: message.requestId, error: message.error },
          }).catch(() => {});
          this.logger.error(
            { requestId: message.requestId, error: message.error },
            "Agent download chunk error",
          );
          pending.reject(new Error("Backup download failed"));
          this.pendingAgentRequests.delete(message.requestId);
          return;
        }
        if (message.data) {
          const buffer = Buffer.from(message.data, "base64");
          if (pending.onChunk) {
            try {
              pending.onChunk(buffer);
            } catch (error) {
              captureSystemError({
                level: 'error',
                component: 'WebSocketGateway',
                message: error instanceof Error ? error.message : 'Failed to handle backup download chunk',
                stack: error instanceof Error ? error.stack : undefined,
                metadata: { requestId: message.requestId },
              }).catch(() => {});
              this.logger.error(
                { requestId: message.requestId, err: error },
                "Failed to handle backup download chunk",
              );
            }
          }
          pending.chunks?.push(buffer);
        }
        if (message.done) {
          clearTimeout(pending.timeout);
          if (pending.chunks) {
            const payload = Buffer.concat(pending.chunks);
            pending.resolve(payload);
          } else {
            pending.resolve(undefined);
          }
          this.pendingAgentRequests.delete(message.requestId);
        }
        return;
      }

      if (message.type === "heartbeat") {
        if (agent) {
          agent.lastHeartbeat = Date.now();
          try {
            await this.prisma.node.update({
              where: { id: nodeId },
              data: { lastSeenAt: new Date() },
            });
          } catch (err) {
            captureSystemError({
              level: 'error',
              component: 'WebSocketGateway',
              message: err instanceof Error ? err.message : 'WebSocket handler error: heartbeat node update failed',
              stack: err instanceof Error ? err.stack : undefined,
              metadata: { nodeId },
            }).catch(() => {});
            this.logger.error({ err, nodeId }, 'WebSocket handler error: heartbeat node update failed');
          }
        }
      } else if (message.type === "health_report") {
        if (!this.allowAgentMetrics(nodeId)) {
          if (this.shouldWarnRateLimit(nodeId, this.agentMetricsLimit.windowMs)) {
            this.logger.warn({ nodeId }, "Agent metrics rate limit exceeded");
          }
          return;
        }
        const node = await this.prisma.node.findUnique({
          where: { id: nodeId },
        });
        if (!node) {
          return;
        }
        const cpuPercent = Number(message.cpuPercent);
        const memoryUsageMb = Number(message.memoryUsageMb);
        const memoryTotalMb = Number(message.memoryTotalMb ?? node.maxMemoryMb);
        const diskUsageMb = Number(message.diskUsageMb ?? 0);
        const diskTotalMb = Number(message.diskTotalMb ?? 0);
        const containerCount = Number(message.containerCount);
        const networkRxBytes = BigInt(Math.max(0, Number(message.networkRxBytes ?? 0)));
        const networkTxBytes = BigInt(Math.max(0, Number(message.networkTxBytes ?? 0)));
        if (
          !Number.isFinite(cpuPercent) ||
          !Number.isFinite(memoryUsageMb) ||
          !Number.isFinite(memoryTotalMb) ||
          !Number.isFinite(diskUsageMb) ||
          !Number.isFinite(diskTotalMb) ||
          !Number.isFinite(containerCount)
        ) {
          this.logger.warn({ nodeId }, "Invalid health report payload");
          return;
        }
        try {
          await this.prisma.node.update({
            where: { id: nodeId },
            data: {
              isOnline: true,
              lastSeenAt: new Date(),
              ...(message.agentVersion ? { agentVersion: String(message.agentVersion) } : {}),
            },
          });
          await this.prisma.nodeMetrics.create({
            data: {
              nodeId,
              cpuPercent,
              memoryUsageMb: Math.round(memoryUsageMb),
              memoryTotalMb: Math.round(memoryTotalMb),
              diskUsageMb: Math.round(diskUsageMb),
              diskTotalMb: Math.round(diskTotalMb),
              networkRxBytes,
              networkTxBytes,
              containerCount: Math.max(0, Math.round(containerCount)),
            },
          });
        } catch (err) {
          captureSystemError({
            level: 'error',
            component: 'WebSocketGateway',
            message: err instanceof Error ? err.message : 'WebSocket handler error: failed to persist health report',
            stack: err instanceof Error ? err.stack : undefined,
            metadata: { nodeId },
          }).catch(() => {});
          this.logger.error({ err, nodeId }, 'WebSocket handler error: failed to persist health report');
        }

        // --- Agent auto-update check ---
        // Compare the agent's version against the panel version.
        // If the agent is behind, send an update_agent command with the target version.
        // Track which version was last requested to avoid sending duplicate commands.
        this.checkAgentUpdate(nodeId, message.agentVersion).catch(() => {});
      } else if (message.type === "agent_update_started") {
        this.logger.info(
          { nodeId, targetVersion: message.targetVersion },
          'Agent confirmed update is being applied',
        );
        // The agent will exec() the new binary and reconnect.
        // No further update commands needed for this node until reconnect.
      } else if (message.type === "agent_update_failed") {
        this.logger.warn(
          { nodeId, error: message.error },
          'Agent reported update failure — clearing tracking so next health_report retries',
        );
        // Clear the tracking entry so the next health_report will
        // re-trigger the update_agent command instead of silently
        // skipping it because "we already sent that version".
        this.agentUpdateSent.delete(nodeId);
      } else if (message.type === "resource_stats") {
        if (!this.allowAgentMetrics(nodeId)) {
          if (this.shouldWarnRateLimit(nodeId, this.agentMetricsLimit.windowMs)) {
            this.logger.warn({ nodeId }, "Agent metrics rate limit exceeded");
          }
          return;
        }
        const serverUuid = message.serverUuid;
        if (!serverUuid) {
          this.logger.warn("resource_stats missing serverUuid");
          return;
        }
        // Note: serverUuid here is actually the serverId (container name from agent)
        // Agent uses server.id as container name, so lookup by id not uuid
        const server = await this.prisma.server.findUnique({
          where: { id: serverUuid },
        });
        if (!server) {
          this.logger.warn({ serverId: serverUuid }, "resource_stats for unknown server");
          return;
        }
        if (server.nodeId !== nodeId) {
          this.logger.warn({ nodeId, serverId: server.id }, "resource_stats for wrong node");
          return;
        }

        const cpuPercent = Number(message.cpuPercent);
        const memoryUsageMb = Number(message.memoryUsageMb);
        const diskUsageMb = Number(message.diskUsageMb ?? 0);
        const diskIoMb = Number(message.diskIoMb ?? 0);
        const diskTotalMb = Number(message.diskTotalMb ?? 0);
        const networkRxBytes = BigInt(Math.max(0, Number(message.networkRxBytes ?? 0)));
        const networkTxBytes = BigInt(Math.max(0, Number(message.networkTxBytes ?? 0)));

        if (!this.allowServerMetrics(server.id)) {
          return;
        }
        // Persist metrics to DB — fire-and-forget to avoid blocking SSE broadcast
        const metricsData = {
          serverId: server.id,
          cpuPercent: Number.isFinite(cpuPercent) ? Math.min(Math.max(cpuPercent, 0), 100) : 0,
          memoryUsageMb: Math.round(Number.isFinite(memoryUsageMb) ? Math.max(memoryUsageMb, 0) : 0),
          networkRxBytes,
          networkTxBytes,
          diskIoMb: Math.round(Number.isFinite(diskIoMb) ? Math.max(diskIoMb, 0) : 0),
          diskUsageMb: Math.round(Number.isFinite(diskUsageMb) ? Math.max(diskUsageMb, 0) : 0),
        };
        this.prisma.serverMetrics.create({ data: metricsData }).catch((err) => {
          this.logger.warn({ err, serverId: server.id }, 'Failed to persist serverMetrics');
        });

        // Persist to historical ServerStat table (fire-and-forget)
        // Clamp to 32-bit signed int max to avoid Prisma overflow for large servers.
        const INT32_MAX = 2_147_483_647;
        const toStatBytes = (mb: number) => Math.min(Math.round(mb * 1024 * 1024), INT32_MAX);
        this.prisma.serverStat.create({
          data: {
            serverId: server.id,
            cpuPercent: metricsData.cpuPercent,
            memoryUsed: toStatBytes(metricsData.memoryUsageMb),
            memoryLimit: toStatBytes(server.allocatedMemoryMb),
            diskUsed: metricsData.diskUsageMb ? toStatBytes(metricsData.diskUsageMb) : null,
            netRx: Number(networkRxBytes) || null,
            netTx: Number(networkTxBytes) || null,
            blockRead: Number.isFinite(diskIoMb) ? toStatBytes(diskIoMb) : null,
            blockWrite: null,
          },
        }).catch((err) => {
          this.logger.warn({ err, serverId: server.id }, 'Failed to persist ServerStat');
        });

        const payload = {
          type: "resource_stats",
          serverId: server.id,
          cpuPercent: Number.isFinite(cpuPercent) ? Math.min(Math.max(cpuPercent, 0), 100) : 0,
          memoryUsageMb: Math.round(Number.isFinite(memoryUsageMb) ? Math.max(memoryUsageMb, 0) : 0),
          networkRxBytes: networkRxBytes.toString(),
          networkTxBytes: networkTxBytes.toString(),
          diskIoMb: Math.round(Number.isFinite(diskIoMb) ? Math.max(diskIoMb, 0) : 0),
          diskUsageMb: Math.round(Number.isFinite(diskUsageMb) ? Math.max(diskUsageMb, 0) : 0),
          diskTotalMb: Math.round(Number.isFinite(diskTotalMb) ? Math.max(diskTotalMb, 0) : 0),
          timestamp: Date.now(),
        };
        this.latestResourceStats.set(server.id, payload);
        await this.routeToClients(server.id, payload);
      } else if (message.type === "resource_stats_batch") {
        if (!this.allowAgentMetrics(nodeId, message.metrics.length)) {
          if (this.shouldWarnRateLimit(nodeId, this.agentMetricsLimit.windowMs)) {
            this.logger.warn({ nodeId }, "Agent metrics rate limit exceeded");
          }
          return;
        }
        // message.metrics is expected to be an array of metric objects
        if (!Array.isArray(message.metrics)) {
          this.logger.warn('resource_stats_batch.metrics is not an array');
          return;
        }
        if (message.metrics.length > 500) {
          this.logger.warn({ count: message.metrics.length }, "resource_stats_batch too large");
          return;
        }

        const items: any[] = [];
        for (const m of message.metrics) {
          if (!m.serverUuid || !m.timestamp) continue;
          if (!Number.isFinite(Number(m.timestamp))) continue;
          items.push({
            serverId: m.serverUuid,
            cpuPercent: Number.isFinite(Number(m.cpuPercent)) ? Math.min(Math.max(Number(m.cpuPercent), 0), 100) : 0,
            memoryUsageMb: Math.round(Number.isFinite(Number(m.memoryUsageMb)) ? Math.max(Number(m.memoryUsageMb), 0) : 0),
            networkRxBytes: BigInt(Math.max(0, Number(m.networkRxBytes || 0))),
            networkTxBytes: BigInt(Math.max(0, Number(m.networkTxBytes || 0))),
            diskIoMb: Math.round(Number.isFinite(Number(m.diskIoMb)) ? Math.max(Number(m.diskIoMb), 0) : 0),
            diskUsageMb: Math.round(Number.isFinite(Number(m.diskUsageMb)) ? Math.max(Number(m.diskUsageMb), 0) : 0),
            timestamp: new Date(Number(m.timestamp)),
          });
        }

        if (items.length === 0) return;

        const serverIds = Array.from(new Set(items.map((i) => i.serverId)));
        const servers = await this.prisma.server.findMany({
          where: { id: { in: serverIds }, nodeId },
          select: { id: true },
        });
        const allowed = new Set(servers.map((s) => s.id));
        const filtered = items.filter((item) => {
          if (!allowed.has(item.serverId)) {
            return false;
          }
          return this.allowServerMetrics(item.serverId);
        });
        if (!filtered.length) {
          return;
        }

        // Use an upsert-style INSERT ... ON CONFLICT statement to dedupe and keep peaks
        // We use GREATEST(...) for memory / network to preserve spikes when backfilling
        const tuples: Prisma.Sql[] = [];
        for (const it of filtered) {
          const cpu = Number(it.cpuPercent) || 0;
          const mem = Number(it.memoryUsageMb) || 0;
          const rx = BigInt(it.networkRxBytes || 0);
          const tx = BigInt(it.networkTxBytes || 0);
          const dio = Number(it.diskIoMb) || 0;
          const dusg = Number(it.diskUsageMb) || 0;
          const ts = new Date(it.timestamp);
          tuples.push(
            Prisma.sql`(${crypto.randomUUID()}, ${it.serverId}, ${cpu}, ${mem}, ${rx}, ${tx}, ${dio}, ${dusg}, ${ts})`
          );
        }

        if (tuples.length === 0) return;

        const sql = Prisma.sql`
          INSERT INTO "ServerMetrics" ("id","serverId","cpuPercent","memoryUsageMb","networkRxBytes","networkTxBytes","diskIoMb","diskUsageMb","timestamp")
          VALUES ${Prisma.join(tuples)}
          ON CONFLICT ("serverId","timestamp") DO UPDATE SET
            "cpuPercent" = EXCLUDED."cpuPercent",
            "memoryUsageMb" = GREATEST("ServerMetrics"."memoryUsageMb", EXCLUDED."memoryUsageMb"),
            "networkRxBytes" = GREATEST("ServerMetrics"."networkRxBytes", EXCLUDED."networkRxBytes"),
            "networkTxBytes" = GREATEST("ServerMetrics"."networkTxBytes", EXCLUDED."networkTxBytes"),
            "diskIoMb" = GREATEST("ServerMetrics"."diskIoMb", EXCLUDED."diskIoMb"),
            "diskUsageMb" = GREATEST("ServerMetrics"."diskUsageMb", EXCLUDED."diskUsageMb")
        `;

        try {
          await this.prisma.$executeRaw(sql);
        } catch (err) {
          captureSystemError({
            level: 'error',
            component: 'WebSocketGateway',
            message: err instanceof Error ? err.message : 'Failed to upsert batched metrics, falling back to per-item safe upsert',
            stack: err instanceof Error ? err.stack : undefined,
            metadata: {},
          }).catch(() => {});
          this.logger.error({ err }, 'Failed to upsert batched metrics, falling back to per-item safe upsert');

          // Fallback: upsert each item individually (safe but slower). We attempt
          // to preserve spike semantics by keeping max(memory, disk, network) where applicable.
          const MAX_FALLBACK_ITEMS = 20;
          if (filtered.length > MAX_FALLBACK_ITEMS) {
            this.logger.warn({ count: filtered.length }, 'Batch metrics fallback limited to 20 items');
          }
          for (const it of filtered.slice(0, MAX_FALLBACK_ITEMS)) {
            try {
              const existing = await this.prisma.serverMetrics.findUnique({
                where: {
                  serverId_timestamp: {
                    serverId: it.serverId,
                    timestamp: new Date(it.timestamp),
                  },
                },
              });

              const cpu = Number(it.cpuPercent) || 0;
              const mem = Math.round(Number(it.memoryUsageMb) || 0);
              const rx = BigInt(it.networkRxBytes || 0);
              const tx = BigInt(it.networkTxBytes || 0);
              const dio = Math.round(Number(it.diskIoMb) || 0);
              const dusg = Math.round(Number(it.diskUsageMb) || 0);
              const ts = new Date(it.timestamp);

              if (existing) {
                await this.prisma.serverMetrics.update({
                  where: { id: existing.id },
                  data: {
                    cpuPercent: cpu, // replace cpu with latest sample
                    memoryUsageMb: Math.max(existing.memoryUsageMb, mem),
                    networkRxBytes: (BigInt(existing.networkRxBytes.toString()) < rx) ? rx : BigInt(existing.networkRxBytes.toString()),
                    networkTxBytes: (BigInt(existing.networkTxBytes.toString()) < tx) ? tx : BigInt(existing.networkTxBytes.toString()),
                    diskIoMb: Math.max(existing.diskIoMb ?? 0, dio),
                    diskUsageMb: Math.max(existing.diskUsageMb, dusg),
                  },
                });
              } else {
                await this.prisma.serverMetrics.create({
                  data: {
                    serverId: it.serverId,
                    cpuPercent: cpu,
                    memoryUsageMb: mem,
                    networkRxBytes: rx,
                    networkTxBytes: tx,
                    diskIoMb: dio,
                    diskUsageMb: dusg,
                    timestamp: ts,
                  },
                });
              }
            } catch (e2) {
              captureSystemError({
                level: 'error',
                component: 'WebSocketGateway',
                message: e2 instanceof Error ? e2.message : 'Failed to upsert individual metric',
                stack: e2 instanceof Error ? e2.stack : undefined,
                metadata: { item: it },
              }).catch(() => {});
              this.logger.error({ err: e2, item: it }, 'Failed to upsert individual metric');
            }
          }
        }

        // Broadcast latest metrics for affected servers
        const filteredIds = Array.from(new Set(filtered.map((i) => i.serverId)));
        for (const sid of filteredIds) {
          const latest = await this.prisma.serverMetrics.findFirst({ where: { serverId: sid }, orderBy: { timestamp: 'desc' } });
          if (latest) {
            const payload = {
              type: 'resource_stats',
              serverId: sid,
              cpuPercent: latest.cpuPercent,
              memoryUsageMb: latest.memoryUsageMb,
              networkRxBytes: latest.networkRxBytes.toString(),
              networkTxBytes: latest.networkTxBytes.toString(),
              diskIoMb: latest.diskIoMb ?? 0,
              diskUsageMb: latest.diskUsageMb,
              diskTotalMb: 0,
              timestamp: latest.timestamp.getTime(),
            };
            this.latestResourceStats.set(sid, payload);
            await this.routeToClients(sid, payload);
          }
        }
      } else if (message.type === "console_output") {
        if (typeof message.data === "string") {
          if (!this.allowConsoleOutputBytes(message.serverId, Buffer.byteLength(message.data))) {
            this.logger.warn({ nodeId, serverId: message.serverId }, "console_output exceeded byte limit");
            return;
          }
        }
        // Per-message size limit to prevent DB bloat from a single huge log dump (1MB)
        const MAX_CONSOLE_MESSAGE_BYTES = 1048576;
        if (message.serverId && message.data && Buffer.byteLength(message.data) > MAX_CONSOLE_MESSAGE_BYTES) {
          this.logger.warn(
            { nodeId, serverId: message.serverId, size: Buffer.byteLength(message.data) },
            "console_output single message exceeds 1MB limit, truncating for DB storage",
          );
          message.data = (message.data as string).slice(0, MAX_CONSOLE_MESSAGE_BYTES);
        }
        if (message.serverId && message.data) {
          // Sanitize console output to prevent XSS attacks
          const sanitizedData = sanitizeInput(message.data);
          try {
            await this.prisma.serverLog.create({
              data: {
                serverId: message.serverId,
                stream: message.stream || "stdout",
                data: sanitizedData,
              },
            });
          } catch (err) {
            captureSystemError({
              level: 'error',
              component: 'WebSocketGateway',
              message: err instanceof Error ? err.message : 'WebSocket handler error: failed to persist console log',
              stack: err instanceof Error ? err.stack : undefined,
              metadata: { serverId: message.serverId },
            }).catch(() => {});
            this.logger.error({ err, serverId: message.serverId }, 'WebSocket handler error: failed to persist console log');
          }
        }
        if (!this.allowConsoleOutput(message.serverId)) {
          await this.maybeWarnConsoleThrottle(message.serverId);
          return;
        }
        // Sanitize console output data before sending to clients to prevent XSS
        const sanitizedMessage = {
          ...message,
          data: typeof message.data === 'string' ? sanitizeInput(message.data) : message.data,
        };
        await this.routeConsoleToSubscribers(message.serverId, sanitizedMessage);
      } else if (message.type === "eula_required") {
        // Forward EULA requirement to subscribed browser clients so the
        // frontend can display an acceptance modal.
        if (!message.serverId) {
          this.logger.warn({ nodeId }, "eula_required missing serverId");
          return;
        }
        await this.routeToClients(message.serverId, {
          type: "eula_required",
          serverId: message.serverId,
          serverUuid: message.serverUuid,
          eulaText: message.eulaText,
          timestamp: Date.now(),
        });
      } else if (message.type === "server_state_update") {
        if (!message.serverId || typeof message.state !== "string") {
          return;
        }
        if (process.env.SUSPENSION_ENFORCED !== "false") {
          const current = await this.prisma.server.findUnique({
            where: { id: message.serverId },
            select: { suspendedAt: true },
          });
          if (current?.suspendedAt) {
            return;
          }
        }
        const server = await this.prisma.server.findUnique({
          where: { id: message.serverId },
          include: { node: true, template: true },
        });

        if (!server) {
          return;
        }
        if (server.nodeId !== nodeId) {
          this.logger.warn({ nodeId, serverId: server.id }, "server_state_update from wrong node");
          return;
        }
        if (server.status === message.state) {
          // Idempotent update from agent; no state change required.
          return;
        }
        const transition = ServerStateMachine.validateTransition(
          server.status as ServerState,
          message.state as ServerState
        );
        if (!transition.allowed) {
          this.logger.warn({ serverId: server.id, from: server.status, to: message.state }, "Invalid state transition");
          return;
        }

        const nextData: Record<string, any> = {
          status: message.state,
          ...(message.portBindings && typeof message.portBindings === "object"
            ? { portBindings: message.portBindings }
            : {}),
          ...(typeof message.exitCode === "number" ? { lastExitCode: message.exitCode } : {}),
        };

        const shouldRecordCrash = message.state === ServerState.CRASHED;
        let shouldAutoRestart = false;
        if (shouldRecordCrash) {
          const nextCrashCount = (server.crashCount ?? 0) + 1;
          nextData.crashCount = nextCrashCount;
          nextData.lastCrashAt = new Date();
          const maxCrashCount = server.maxCrashCount ?? 0;
          if (
            server.restartPolicy !== "never" &&
            nextCrashCount <= maxCrashCount
          ) {
            if (server.restartPolicy === "always") {
              shouldAutoRestart = true;
            } else if (server.restartPolicy === "on-failure") {
              const exitCode = typeof message.exitCode === "number" ? message.exitCode : null;
              if (exitCode !== null && exitCode !== 0) {
                shouldAutoRestart = true;
              }
            }
          }

        }

        try {
          await this.prisma.server.update({
            where: { id: message.serverId },
            data: nextData,
          });
          if (message.reason) {
            await this.prisma.serverLog.create({
              data: {
                serverId: message.serverId,
                stream: "system",
                data: `Status changed to ${message.state}: ${message.reason}`,
              },
            });
          }
          if (shouldRecordCrash && typeof message.exitCode === "number") {
            await this.prisma.serverLog.create({
              data: {
                serverId: message.serverId,
                stream: "system",
                data: `Exit code: ${message.exitCode}`,
              },
            });
          }
        } catch (err) {
          captureSystemError({
            level: 'error',
            component: 'WebSocketGateway',
            message: err instanceof Error ? err.message : 'WebSocket handler error: failed to persist state update',
            stack: err instanceof Error ? err.stack : undefined,
            metadata: { serverId: message.serverId },
          }).catch(() => {});
          this.logger.error({ err, serverId: message.serverId }, 'WebSocket handler error: failed to persist state update');
        }

        if (shouldAutoRestart && server.node?.isOnline) {
          this.autoRestartingServers.add(server.id);
          await this.prisma.server.update({
            where: { id: server.id },
            data: { status: ServerState.STARTING },
          });
          const serverDir = process.env.SERVER_DATA_DIR || "/var/lib/catalyst/servers";
          const fullServerDir = `${serverDir}/${server.uuid}`;
          const templateVariables = (server.template.variables as any[]) || [];
          const templateDefaults = templateVariables.reduce((acc, variable) => {
            if (variable?.name && variable?.default !== undefined) {
              acc[variable.name] = String(variable.default);
            }
            return acc;
          }, {} as Record<string, string>);
          const environment = {
            ...templateDefaults,
            ...(server.environment as Record<string, string>),
            SERVER_DIR: fullServerDir,
          };
          if (server.primaryIp && !environment.CATALYST_NETWORK_IP) {
            environment.CATALYST_NETWORK_IP = server.primaryIp;
          }
          if (server.networkMode === "host" && !environment.CATALYST_NETWORK_IP) {
            try {
              environment.CATALYST_NETWORK_IP =
                normalizeHostIp(server.node.publicAddress) ?? undefined;
            } catch (error: any) {
              this.logger.warn(
                { nodeId: server.nodeId, hostIp: server.node.publicAddress, error: error.message },
                "Invalid host network IP"
              );
            }
          }

          // Sync port environment variables with primaryPort
          const portBindings =
            message.portBindings && typeof message.portBindings === "object"
              ? message.portBindings
              : server.portBindings;
          const syncedEnvironment = syncPortEnvironmentVariables(
            environment,
            server.primaryPort,
            portBindings as Record<string, unknown> | undefined
          );

          const restartSent = await this.sendToAgent(server.nodeId, {
            type: "start_server",
            serverId: server.id,
            serverUuid: server.uuid,
            template: server.template,
            environment: syncedEnvironment,
            allocatedMemoryMb: server.allocatedMemoryMb,
            allocatedCpuCores: server.allocatedCpuCores,
            allocatedDiskMb: server.allocatedDiskMb,
            primaryPort: server.primaryPort,
            portBindings,
            networkMode: server.networkMode,
            autoRestart: {
              enabled: true,
              delay: 10,
              maxRestarts: server.maxCrashCount ?? 5,
              windowSecs: 60,
            },
          });
          if (!restartSent) {
            this.autoRestartingServers.delete(server.id);
            await this.prisma.server.update({
              where: { id: server.id },
              data: { status: ServerState.CRASHED },
            });
            this.logger.warn({ serverId: server.id }, "Auto-restart failed to send to agent");
          }
        }

        if (message.state === ServerState.RUNNING && this.autoRestartingServers.has(server.id)) {
          this.autoRestartingServers.delete(server.id);
        }

        // Route to clients
        await this.routeToClients(message.serverId, message);
      } else if (message.type === "server_state_sync") {
        // State reconciliation from agent - updates status to match actual container state
        // Container name is the server ID (CUID), not the UUID field
        this.logger.info(
          { serverId: message.serverUuid, state: message.state, containerId: message.containerId },
          "Received state sync message"
        );

        const server = await this.prisma.server.findUnique({
          where: { id: message.serverUuid },  // Container name is server.id (CUID), not server.uuid
        });

        if (!server) {
          this.logger.warn(`State sync for unknown server ID: ${message.serverUuid}`);
          // Only track running unknown containers for auto-import. Stopped/crashed
          // containers are usually deleted servers or ones that don't exist anymore.
          if (message.state !== 'running') {
            return;
          }
          // Track as unregistered container for auto-import
          const existing = this.discoveredContainers.get(nodeId) ?? [];
          if (!existing.some(c => c.containerId === message.serverUuid)) {
            existing.push({
              containerId: message.serverUuid,
              image: "",
              status: message.state === "running" ? "Up" : "Exited",
              labels: {},
              discoveredAt: Date.now(),
            });
            this.discoveredContainers.set(nodeId, existing);
          }
          return;
        }
        if (server.nodeId !== nodeId) {
          this.logger.warn({ nodeId, serverId: server.id }, "server_state_sync from wrong node");
          return;
        }

        // Check if server is suspended - don't update suspended servers
        if (process.env.SUSPENSION_ENFORCED !== "false" && server.suspendedAt) {
          return;
        }

        // Only update if state is different to avoid unnecessary writes
        if (server.status !== message.state) {
          const transition = ServerStateMachine.validateTransition(
            server.status as ServerState,
            message.state as ServerState
          );
          if (!transition.allowed) {
            // State sync from agent represents actual container state - force update for reconciliation
            this.logger.info(
              { serverId: server.id, from: server.status, to: message.state },
              "State sync forced reconciliation (overriding state machine)"
            );
          }
          this.logger.info(
            { serverId: server.id, oldStatus: server.status, newStatus: message.state },
            "State reconciliation: updating server status"
          );

          const updateData: Record<string, any> = {
            status: message.state,
          };

          if (typeof message.exitCode === "number") {
            updateData.lastExitCode = message.exitCode;
          }

          await this.prisma.server.update({
            where: { id: server.id },
            data: updateData,
          });

          // Log the reconciliation event
          await this.prisma.serverLog.create({
            data: {
              serverId: server.id,
              stream: "system",
              data: `[State Sync] Status reconciled to ${message.state}`,
            },
          });

          // Notify clients of the state change
          await this.routeToClients(server.id, {
            type: "server_state_update",
            serverId: server.id,
            state: message.state,
            timestamp: message.timestamp || Date.now(),
          });
        }
      } else if (message.type === "server_state_sync_complete") {
        // Reconciliation completed - check for servers that should exist but weren't found
        if (!message.nodeId || message.nodeId !== nodeId) {
          this.logger.warn({ nodeId, messageNodeId: message.nodeId }, "server_state_sync_complete node mismatch");
          return;
        }
        const foundContainers = Array.isArray(message.foundContainers) 
          ? new Set(message.foundContainers) 
          : new Set();

        this.logger.debug(
          { nodeId, foundCount: foundContainers.size },
          "Received state sync completion"
        );

        // Find all servers that should be on this node
        const serversOnNode = await this.prisma.server.findMany({
          where: { 
            nodeId,
            // Only check servers that aren't already in terminal states
            status: {
              notIn: [ServerState.STOPPED, ServerState.ERROR, ServerState.CREATING_BACKUP, ServerState.RESTORING]
            }
          },
          select: { id: true, uuid: true, status: true, suspendedAt: true }
        });

        // Check which servers are missing (container not found)
        for (const server of serversOnNode) {
          // Skip suspended servers
          if (process.env.SUSPENSION_ENFORCED !== "false" && server.suspendedAt) {
            continue;
          }

          // Container name is server.id (CUID), not server.uuid
          if (!foundContainers.has(server.id)) {
            // Server should exist but container wasn't found - mark as stopped
            this.logger.info(
              { serverId: server.id, uuid: server.uuid, previousStatus: server.status },
              "Marking missing server as stopped during reconciliation"
            );

            await this.prisma.server.update({
              where: { id: server.id },
              data: { status: ServerState.STOPPED }
            });

            await this.prisma.serverLog.create({
              data: {
                serverId: server.id,
                stream: "system",
                data: `[State Sync] Container not found during reconciliation, marked as stopped`
              }
            });

            // Notify clients
            await this.routeToClients(server.id, {
              type: "server_state_update",
              serverId: server.id,
              state: ServerState.STOPPED,
              timestamp: Date.now(),
            });
          }
        }

        // Prune discovered containers cache to only include containers
        // that the agent actually found during reconciliation. This removes
        // stale entries from deleted servers or outdated event-driven syncs.
        const discovered = this.discoveredContainers.get(nodeId) ?? [];
        const stillPresent = discovered.filter((c) => foundContainers.has(c.containerId));
        if (stillPresent.length !== discovered.length) {
          this.discoveredContainers.set(nodeId, stillPresent);
          this.logger.debug({ nodeId, pruned: discovered.length - stillPresent.length }, 'Pruned stale discovered containers');
        }
      } else if (message.type === "backup_complete") {
        const server = await this.prisma.server.findUnique({
          where: { id: message.serverId },
          include: { node: true },
        });

        // Transition server back to STOPPED after backup completes
        if (server?.status === ServerState.CREATING_BACKUP) {
          await this.prisma.server.update({
            where: { id: message.serverId },
            data: { status: ServerState.STOPPED },
          });
        }

        if (!server) {
          return;
        }
        if (server.nodeId !== nodeId) {
          this.logger.warn({ nodeId, serverId: server.id }, "backup_complete from wrong node");
          return;
        }

        const backupRecord = message.backupId
          ? await this.prisma.backup.findUnique({ where: { id: message.backupId } })
          : await this.prisma.backup.findFirst({
              where: {
                serverId: message.serverId,
                name: message.backupName,
              },
              orderBy: { createdAt: "desc" },
            });

        if (!backupRecord) {
          return;
        }

        const mode = backupRecord.storageMode || "local";
        const agentPath =
          (backupRecord.metadata as any)?.agentPath ?? message.backupPath ?? backupRecord.path;

        const nextSizeMb = Number(message.sizeMb);
        const resolvedSizeMb = Number.isFinite(nextSizeMb) ? nextSizeMb : backupRecord.sizeMb;
        const resolvedChecksum =
          typeof message.checksum === "string" && message.checksum.length <= 256
            ? message.checksum
            : backupRecord.checksum;

        const resolvedEncrypted =
          typeof message.encrypted === "boolean"
            ? message.encrypted
            : (backupRecord.metadata as any)?.encrypted ?? false;

        const updated = await this.prisma.backup.update({
          where: { id: backupRecord.id },
          data: {
            sizeMb: resolvedSizeMb,
            checksum: resolvedChecksum,
            metadata: {
              ...(backupRecord.metadata as any),
              encrypted: resolvedEncrypted,
            },
          },
        });
        this.logger.info(
          { backupId: backupRecord.id, sizeMb: updated.sizeMb },
          "Backup updated from agent",
        );

        await this.routeToClients(message.serverId, {
          ...message,
          sizeMb: updated.sizeMb,
          checksum: updated.checksum,
        });

        if (mode === "s3") {
          try {
            const { streamAgentBackupToS3 } = await import("../services/backup-storage");
            const storageKey = (backupRecord.metadata as any)?.storageKey;
            if (storageKey) {
              await streamAgentBackupToS3(
                this,
                server.nodeId,
                server.id,
                server.uuid,
                agentPath,
                storageKey,
                server as any,
              );
              await this.prisma.backup.update({
                where: { id: backupRecord.id },
                data: { metadata: { ...(backupRecord.metadata as any), remoteUploadStatus: "completed" } },
              });
            }
          } catch (error) {
            captureSystemError({
              level: 'error',
              component: 'WebSocketGateway',
              message: error instanceof Error ? error.message : 'Failed to upload backup to S3',
              stack: error instanceof Error ? error.stack : undefined,
              metadata: { backupId: backupRecord.id },
            }).catch(() => {});
            this.logger.error({ err: error, backupId: backupRecord.id }, "Failed to upload backup to S3");
            await this.prisma.backup.update({
              where: { id: backupRecord.id },
              data: {
                metadata: {
                  ...(backupRecord.metadata as any),
                  remoteUploadStatus: "failed",
                  remoteUploadError: error instanceof Error ? error.message : "S3 upload failed",
                },
              },
            });
            // Clean up agent-local copy so the failed upload doesn't leak disk
            this.sendToAgent(server.nodeId, {
              type: "delete_backup",
              serverId: server.id,
              serverUuid: server.uuid,
              backupPath: agentPath,
            }).catch(() => {});
          }
        } else if (mode === "sftp") {
          try {
            const { streamAgentBackupToSftp } = await import("../services/backup-storage");
            const storageKey = (backupRecord.metadata as any)?.storageKey;
            if (storageKey) {
              await streamAgentBackupToSftp(
                this,
                server.nodeId,
                server.id,
                server.uuid,
                agentPath,
                storageKey,
                server as any,
              );
              await this.prisma.backup.update({
                where: { id: backupRecord.id },
                data: { metadata: { ...(backupRecord.metadata as any), remoteUploadStatus: "completed" } },
              });
            }
          } catch (error) {
            captureSystemError({
              level: 'error',
              component: 'WebSocketGateway',
              message: error instanceof Error ? error.message : 'Failed to upload backup to SFTP',
              stack: error instanceof Error ? error.stack : undefined,
              metadata: { backupId: backupRecord.id },
            }).catch(() => {});
            this.logger.error({ err: error, backupId: backupRecord.id }, "Failed to upload backup to SFTP");
            await this.prisma.backup.update({
              where: { id: backupRecord.id },
              data: {
                metadata: {
                  ...(backupRecord.metadata as any),
                  remoteUploadStatus: "failed",
                  remoteUploadError: error instanceof Error ? error.message : "SFTP upload failed",
                },
              },
            });
            // Clean up agent-local copy so the failed upload doesn't leak disk
            this.sendToAgent(server.nodeId, {
              type: "delete_backup",
              serverId: server.id,
              serverUuid: server.uuid,
              backupPath: agentPath,
            }).catch(() => {});
          }
        } else if (mode === "stream") {
          try {
            const { streamAgentBackupToLocal } = await import("../services/backup-storage");
            await streamAgentBackupToLocal(
              this,
              server.nodeId,
              server.id,
              server.uuid,
              agentPath,
              backupRecord.path,
            );
          } catch (error) {
            captureSystemError({
              level: 'error',
              component: 'WebSocketGateway',
              message: error instanceof Error ? error.message : 'Failed to fetch stream backup',
              stack: error instanceof Error ? error.stack : undefined,
              metadata: { backupId: backupRecord.id },
            }).catch(() => {});
            this.logger.error({ err: error, backupId: backupRecord.id }, "Failed to fetch stream backup");
          }
        }

        const retentionCount = server.backupRetentionCount ?? 0;
        const retentionDays = server.backupRetentionDays ?? 0;
        if (retentionCount > 0 || retentionDays > 0) {
          const cutoff =
            retentionDays > 0
              ? new Date(Date.now() - retentionDays * 24 * 60 * 60 * 1000)
              : null;
          const backups = await this.prisma.backup.findMany({
            where: { serverId: message.serverId },
            orderBy: { createdAt: "desc" },
          });
          const byCount = retentionCount > 0 ? backups.slice(retentionCount) : [];
          const byAge = cutoff ? backups.filter((backup) => backup.createdAt < cutoff) : [];
          const toDelete = new Map(
            [...byCount, ...byAge].map((backup) => [backup.id, backup]),
          );
          if (toDelete.size) {
            for (const backup of toDelete.values()) {
              try {
                const { deleteBackupFromStorage } = await import("../services/backup-storage");
                await deleteBackupFromStorage(this, backup, {
                  id: server.id,
                  uuid: server.uuid,
                  nodeId: server.nodeId,
                  node: { isOnline: server.node?.isOnline ?? false },
                  backupS3Config: (server as any).backupS3Config,
                  backupSftpConfig: (server as any).backupSftpConfig,
                });
                // Use deleteMany to avoid P2025 (RecordNotFound) when periodic
                // retention already deleted this backup between our findMany and here.
                await this.prisma.backup.deleteMany({ where: { id: backup.id } });
              } catch (error) {
                this.logger.warn({ err: error, backupId: backup.id }, "Failed to enforce retention");
              }
            }
          }
        }

      } else if (message.type === "backup_restore_complete") {
        // Transition server back to STOPPED after restore completes
        await this.prisma.server.updateMany({
          where: { id: message.serverId, status: ServerState.RESTORING },
          data: { status: ServerState.STOPPED },
        });

        // Update backup record with restore timestamp only after agent confirms success
        if (message.backupId) {
          await this.prisma.backup.update({
            where: { id: message.backupId },
            data: { restoredAt: new Date() },
          }).catch(() => {}); // Best effort — don't fail the SSE event
        }

        await this.routeToClients(message.serverId, message);
      } else if (message.type === "backup_delete_complete") {
        await this.routeToClients(message.serverId, message);
      } else if (message.type === "storage_resize_complete") {
        await this.routeToClients(message.serverId, message);
      } else if (message.type === "agent_error_report") {
        // Agent (node) is reporting an error — store it as a system error with nodeId
        const level = (typeof message.level === "string" && ["error", "warn", "critical"].includes(message.level))
          ? message.level as "error" | "warn" | "critical"
          : "error";
        const component = typeof message.component === "string" ? message.component : `agent:${nodeId}`;
        const errorMessage = typeof message.message === "string" ? message.message : "Unknown agent error";
        const stack = typeof message.stack === "string" ? message.stack : undefined;
        const metadata = typeof message.metadata === "object" && message.metadata !== null
          ? message.metadata
          : undefined;
        const requestId = typeof message.requestId === "string" ? message.requestId : undefined;

        captureSystemError({
          level,
          component,
          message: errorMessage,
          stack,
          metadata,
          requestId,
          nodeId,
        }).catch(() => {});

        this.logger.info(
          { nodeId, level, component, message: errorMessage.slice(0, 200) },
          "Agent error reported"
        );

        // Revert stuck backup/restore states on agent error
        const errorServerId = metadata?.serverId;
        if (errorServerId && typeof errorServerId === "string") {
          const isBackupError =
            component.includes("backup") ||
            (typeof message.backupId === "string" && message.backupId) ||
            (typeof message.backupPath === "string" && message.backupPath);
          if (isBackupError) {
            const server = await this.prisma.server.findUnique({
              where: { id: errorServerId },
              select: { id: true, status: true },
            });
            if (server && (server.status === ServerState.CREATING_BACKUP || server.status === ServerState.RESTORING)) {
              await this.prisma.server.update({
                where: { id: server.id },
                data: { status: ServerState.ERROR },
              });
              await this.prisma.serverLog.create({
                data: {
                  serverId: server.id,
                  stream: "system",
                  data: `[Agent Error] Backup/restore failed: ${errorMessage}. Transitioned from ${server.status} to ERROR.`,
                },
              });
              await this.routeToClients(server.id, {
                type: "server_state_update",
                serverId: server.id,
                state: ServerState.ERROR,
                reason: `Agent error during ${server.status}: ${errorMessage.slice(0, 200)}`,
                timestamp: Date.now(),
              });
              this.logger.info(
                { serverId: server.id, fromStatus: server.status },
                "Reverted stuck state to ERROR after agent error"
              );
            }
          }
        }
      } else if (message.type === "discovered_servers") {
        if (!message.nodeId || message.nodeId !== nodeId) {
          this.logger.warn({ nodeId, messageNodeId: message.nodeId }, "discovered_servers node mismatch");
          return;
        }
        const containers = Array.isArray(message.containers) ? message.containers : [];

        this.discoveredContainers.set(nodeId, containers.map((c: any) => ({
          containerId: String(c.containerId || ""),
          image: String(c.image || ""),
          status: String(c.status || ""),
          labels: typeof c.labels === "object" && c.labels !== null ? c.labels : {},
          networkMode: typeof c.networkMode === "string" ? c.networkMode : undefined,
          memoryLimitMb: typeof c.memoryLimitMb === "number" ? c.memoryLimitMb : undefined,
          cpuCores: typeof c.cpuCores === "number" ? c.cpuCores : undefined,
          startupCommand: typeof c.startupCommand === "string" ? c.startupCommand : undefined,
          envVarNames: Array.isArray(c.envVarNames) ? c.envVarNames : undefined,
          discoveredAt: Date.now(),
        })));

        this.logger.info(
          { nodeId, count: containers.length },
          `Discovered ${containers.length} containers on node`
        );
      }
    } catch (err) {
      this.logger.error(err, `Error handling agent message from ${nodeId}`);
      captureSystemError({
        level: 'error',
        component: 'WebSocketGateway',
        message: err instanceof Error ? err.message : `Error handling agent message from ${nodeId}`,
        stack: err instanceof Error ? err.stack : undefined,
        metadata: { nodeId },
      }).catch(() => {});
    }
  }

  private async handleClientMessage(clientId: string, data: any) {
    try {
      // Enforce maximum message size limit to prevent memory exhaustion
      const MAX_MESSAGE_BYTES = 1024 * 1024; // 1MB max
      if (data && Buffer.byteLength(data) > MAX_MESSAGE_BYTES) {
        this.logger.warn({ clientId, size: Buffer.byteLength(data) }, "Client message exceeds 1MB limit");
        const client = this.clients.get(clientId);
        if (client?.socket?.readyState === 1) {
          client.socket.close();
        }
        return;
      }

      const message = JSON.parse(data.toString());
      const client = this.clients.get(clientId);

      if (!client) {
        this.logger.warn({ clientId }, "Received message for unknown client");
        return;
      }

      this.logger.info({ clientId, type: message.type, authenticated: client.authenticated }, "Received client message");

      if (message.type === "client_handshake") {
        // If already authenticated via cookies, just acknowledge
        if (client.authenticated) {
          this.logger.info({ clientId, userId: client.userId }, "Client already authenticated via cookie");
          return;
        }
        
        this.logger.info({ clientId, hasToken: Boolean(message.token) }, "Received client_handshake");
        const token = typeof message.token === "string" ? message.token : "";
        if (!token) {
          this.logger.warn({ clientId }, "client_handshake missing token and no cookie auth");
          client.socket.close();
          this.clients.delete(clientId);
          return;
        }
        const session = await auth.api.getSession({
          headers: new Headers({ authorization: `Bearer ${token}` }),
        });
        if (!session) {
          this.logger.warn({ clientId }, "client_handshake invalid session");
          client.socket.close();
          this.clients.delete(clientId);
          return;
        }
        client.userId = session.user.id;
        client.authenticated = true;
        client.lastAuthAt = Date.now();
        this.logger.info({ clientId, userId: session.user.id }, "Client authenticated successfully");
        return;
      }

      if (!client.authenticated) {
        return;
      }

      // ── Plugin WebSocket handler dispatch ─────────────────────────────
      if (typeof message.type === 'string' && message.type.startsWith('plugin:')) {
        const entry = this.pluginWsHandlers.get(message.type);
        if (entry) {
          try {
            await entry.handler(message.data ?? message, clientId, client.userId);
          } catch (err) {
            captureSystemError({
              level: 'error',
              component: 'WebSocketGateway',
              message: err instanceof Error ? err.message : `Plugin WS handler error for ${message.type}`,
              stack: err instanceof Error ? err.stack : undefined,
              metadata: { messageType: message.type },
            }).catch(() => {});
            this.logger.error(err, `Plugin WS handler error for ${message.type}`);
          }
          return;
        }
        // No matching handler — fall through to other message types
      }

      if (message.type === "subscribe") {
        if (!message.serverId) {
          return;
        }
        const server = await this.prisma.server.findUnique({
          where: { id: message.serverId },
        });
        if (!server) {
          return;
        }
        const isAdmin = await this.userHasAdminRead(client.userId);
        const access = await this.prisma.serverAccess.findUnique({
          where: { userId_serverId: { userId: client.userId, serverId: server.id } },
        });
        const nodeAccess = await hasNodeAccess(this.prisma, client.userId, server.nodeId);
        if (!access && server.ownerId !== client.userId && !isAdmin && !nodeAccess) {
          if (client.socket.readyState === 1) {
            client.socket.send(
              JSON.stringify({
                type: "error",
                error: ErrorCodes.PERMISSION_DENIED,
                serverId: server.id,
              })
            );
          }
          return;
        }
        const isOwner = server.ownerId === client.userId;
        const canConsoleRead = isOwner || isAdmin || nodeAccess || access?.permissions?.includes("console.read");
        const canServerRead = isOwner || isAdmin || nodeAccess || access?.permissions?.includes("server.read");
        if (!canConsoleRead && !canServerRead) {
          if (client.socket.readyState === 1) {
            client.socket.send(
              JSON.stringify({
                type: "error",
                error: ErrorCodes.PERMISSION_DENIED,
                serverId: server.id,
              })
            );
          }
          return;
        }
        client.subscriptions.add(server.id);
        if (canConsoleRead) {
          await this.requestConsoleStream(server.id, server.uuid);
        }
        // Request immediate metrics to avoid 30-second wait
        if (server.nodeId) {
          await this.sendToAgent(server.nodeId, {
            type: "request_immediate_stats",
            serverId: server.id,
          });
        }
        return;
      }

      if (message.type === "unsubscribe") {
        if (message.serverId) {
          client.subscriptions.delete(message.serverId);
        }
        return;
      }

        if (message.type === "server_control") {
          const event: WsEvent.ServerControl = message;
          const validActions = new Set(["start", "stop", "kill", "restart", "reboot"]);
          if (!event.serverId || !validActions.has(event.action)) {
            return;
          }

        // Verify permission
        const access = await this.prisma.serverAccess.findUnique({
          where: {
            userId_serverId: { userId: client.userId, serverId: event.serverId },
          },
        });

        const server = await this.prisma.server.findUnique({
          where: { id: event.serverId },
        });

        if (!server) {
          return client.socket.send(
            JSON.stringify({
              type: "error",
              error: ErrorCodes.SERVER_NOT_FOUND,
            })
          );
        }

        // Check if client is owner or has access
        const isOwner = server.ownerId === client.userId;
        const isAdmin = await this.userHasAdminRead(client.userId);
        const nodeAccess = await hasNodeAccess(this.prisma, client.userId, server.nodeId);
        if (!isOwner && !access && !isAdmin && !nodeAccess) {
          return client.socket.send(
            JSON.stringify({
              type: "error",
              error: ErrorCodes.PERMISSION_DENIED,
              serverId: server.id,
            })
          );
        }

        if (process.env.SUSPENSION_ENFORCED !== "false" && server.suspendedAt) {
          return client.socket.send(
            JSON.stringify({
                type: "error",
                error: "SERVER_SUSPENDED",
                serverId: server.id,
              })
            );
        }
        const requiredPermission =
          event.action === "start"
            ? "server.start"
            : event.action === "stop"
              ? "server.stop"
              // kill, restart, and reboot are destructive actions requiring server.stop permission
              : event.action === "kill" || event.action === "restart" || event.action === "reboot"
                ? "server.stop"
                : "server.start";
        if (!isOwner && !isAdmin && !nodeAccess && !access?.permissions?.includes(requiredPermission)) {
          return client.socket.send(
            JSON.stringify({
              type: "error",
              error: ErrorCodes.PERMISSION_DENIED,
              serverId: server.id,
            })
          );
        }

        // Route to agent
        const agent = this.agents.get(server.nodeId);
        if (agent && agent.socket.readyState === 1) {
          agent.socket.send(
            JSON.stringify({
              ...event,
              serverUuid: server.uuid,
              suspended: Boolean(server.suspendedAt),
            })
          );
        } else {
          return client.socket.send(
            JSON.stringify({
              type: "error",
              error: ErrorCodes.NODE_OFFLINE,
              serverId: server.id,
            })
          );
        }
      } else if (message.type === "console_input") {
          const event: WsEvent.ConsoleInput = message;
          if (!event.serverId || typeof event.data !== "string") {
            return;
          }

        const server = await this.prisma.server.findUnique({
          where: { id: event.serverId },
        });

        if (!server) {
          if (client.socket.readyState === 1) {
            client.socket.send(
              JSON.stringify({
                type: "error",
                error: ErrorCodes.SERVER_NOT_FOUND,
                serverId: event.serverId,
              })
            );
          }
          return;
        }

        const isAdmin = await this.userHasAdminRead(client.userId);
        const access = await this.prisma.serverAccess.findUnique({
          where: { userId_serverId: { userId: client.userId, serverId: server.id } },
        });
        const consoleNodeAccess = await hasNodeAccess(this.prisma, client.userId, server.nodeId);
        if (!access && server.ownerId !== client.userId && !isAdmin && !consoleNodeAccess) {
          if (client.socket.readyState === 1) {
            client.socket.send(
              JSON.stringify({
                type: "error",
                error: ErrorCodes.PERMISSION_DENIED,
                serverId: server.id,
              })
            );
          }
          return;
        }
        if (
          !access?.permissions?.includes("console.write") &&
          server.ownerId !== client.userId &&
          !isAdmin &&
          !consoleNodeAccess
        ) {
          if (client.socket.readyState === 1) {
            client.socket.send(
              JSON.stringify({
                type: "error",
                error: ErrorCodes.PERMISSION_DENIED,
                serverId: server.id,
              })
            );
          }
          return;
        }
        if (process.env.SUSPENSION_ENFORCED !== "false" && server.suspendedAt) {
          if (client.socket.readyState === 1) {
            client.socket.send(
              JSON.stringify({
                type: "error",
                error: "SERVER_SUSPENDED",
                serverId: server.id,
              })
            );
          }
          return;
        }
        if (
          !this.allowConsoleCommand(clientId) ||
          !this.allowServerCommand(server.id) ||
          event.data.length > 4096
        ) {
          if (client.socket.readyState === 1) {
            client.socket.send(
              JSON.stringify({
                type: "console_output",
                serverId: server.id,
                stream: "system",
                data: "[Catalyst] Console input rate limit exceeded.\n",
                timestamp: Date.now(),
              })
            );
          }
          return;
        }

        // Route to agent
        const agent = this.agents.get(server.nodeId);
        this.logger.info({ 
          serverId: server.id, 
          nodeId: server.nodeId, 
          hasAgent: !!agent, 
          agentState: agent?.socket?.readyState 
        }, "Routing console_input to agent");
        if (agent && agent.socket.readyState === 1) {
          agent.socket.send(
            JSON.stringify({ ...event, serverUuid: server.uuid })
          );
          this.logger.info({ nodeId: server.nodeId }, "Console input sent to agent");
        } else if (client.socket.readyState === 1) {
          this.logger.warn({ nodeId: server.nodeId, hasAgent: !!agent }, "Agent not available for console_input");
          client.socket.send(
            JSON.stringify({
              type: "error",
              error: ErrorCodes.NODE_OFFLINE,
              serverId: server.id,
            })
          );
        }
      }
    } catch (err) {
      this.logger.error(err, `Error handling client message from ${clientId}`);
      captureSystemError({
        level: 'error',
        component: 'WebSocketGateway',
        message: err instanceof Error ? err.message : `Error handling client message from ${clientId}`,
        stack: err instanceof Error ? err.stack : undefined,
        metadata: { clientId },
      }).catch(() => {});
    }
  }

  /**
   * Route a message to all subscribed clients (WebSocket + SSE).
   * Used for server-scoped events (state changes, backups, alerts).
   */
  async routeToClients(serverId: string, message: any): Promise<void> {
    // Use cached server access list
    const now = Date.now();
    const cached = this.serverAccessCache.get(serverId);
    let allowedUsers: Set<string>;

    if (cached && cached.expiresAt > now) {
      allowedUsers = cached.allowedUsers;
    } else {
      const server = await this.prisma.server.findUnique({
        where: { id: serverId },
        include: { access: { select: { userId: true } } },
      });
      if (!server) return;
      allowedUsers = new Set([
        server.ownerId,
        ...server.access.map((a) => a.userId),
      ]);
      this.serverAccessCache.set(serverId, { allowedUsers, expiresAt: now + WebSocketGateway.SERVER_ACCESS_TTL_MS });
    }


    // Sanitize console data before relaying to prevent XSS
    let messageToSend = message;
    if (message.type === 'console_output' && typeof message.data === 'string') {
      messageToSend = {
        ...message,
        data: sanitizeInput(message.data),
      };
    }

    for (const [, client] of this.clients) {
      if (!client.subscriptions.has(serverId)) continue;
      if (allowedUsers.has(client.userId)) {
        if (client.socket.readyState === 1) {
          client.socket.send(JSON.stringify(messageToSend));
        }
      }
    }

    const eventType = messageToSend.type;
    const sseEventSubs = this.sseEventSubscribers.get(serverId);
    if (sseEventSubs) {
      const eventData = JSON.stringify(messageToSend);
      for (const [, sub] of sseEventSubs) {
        if (sub.eventTypes.includes(eventType)) {
          sub.lastActivity = Date.now();
          try { sub.push(eventType, eventData); } catch { /* ignore */ }
        }
      }
    }

    // Also push to global SSE subscribers (serverIds filter applies)
    const eventData = JSON.stringify(messageToSend);
    for (const [, sub] of this.globalSseSubscribers) {
      if (sub.serverIds && !sub.serverIds.has(serverId)) continue;
      if (sub.eventTypes.includes(eventType)) {
        sub.lastActivity = Date.now();
        try { sub.push(eventType, eventData); } catch { /* ignore */ }
      }
    }
  }

  /**
   * Push an event to all global SSE subscribers listening for that event type.
   * Used for user-level events (user_created, user_deleted) that don't belong to a server.
   *
   * @param eventType - The event type (e.g. 'user_created')
   * @param data - Event payload
   */
  pushToGlobalSubscribers(eventType: string, data: unknown): void {
    const eventData = JSON.stringify(data);
    for (const [, sub] of this.globalSseSubscribers) {
      if (sub.eventTypes.includes(eventType)) {
        sub.lastActivity = Date.now();
        try {
          sub.push(eventType, eventData);
        } catch {
          // subscriber connection closed — will be cleaned up
        }
      }
    }
  }


  /**
   * Push an event to all admin SSE subscribers listening for that event type.
   * Used for entity-level events (users, nodes, templates, alerts) in admin context.
   */
  pushToAdminSubscribers(eventType: string, data: unknown): void {
    const eventData = JSON.stringify(data);
    for (const [, sub] of this.adminEventSubscribers) {
      if (sub.eventTypes.includes(eventType)) {
        sub.lastActivity = Date.now();
        try {
          sub.push(eventType, eventData);
        } catch {
          // subscriber connection closed — will be cleaned up
        }
      }
    }
  }

  /**
   * Register an SSE subscriber for admin entity events.
   * Returns an unsubscribe function.
   */
  addAdminEventSubscriber(
    eventTypes: string[],
    push: (event: string, data: any) => void,
  ): () => void {
    const subscriberId = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    this.adminEventSubscribers.set(subscriberId, { eventTypes, push, lastActivity: Date.now() });
    this.logger.debug({ subscriberId, eventTypes }, 'Admin SSE subscriber added');
    return () => {
      this.adminEventSubscribers.delete(subscriberId);
      this.logger.debug({ subscriberId }, 'Admin SSE subscriber removed');
    };
  }

  private async routeConsoleToSubscribers(serverId: string, message: any) {
    const server = await this.prisma.server.findUnique({
      where: { id: serverId },
      include: {
        access: {
          select: { userId: true },
        },
      },
    });

    if (!server) {
      return;
    }

    const allowedUsers = [
      server.ownerId,
      ...server.access.map((a) => a.userId),
    ];

    // Sanitize console data before relaying to clients to prevent XSS
    const sanitizedMessage = {
      ...message,
      data: typeof message.data === 'string' ? sanitizeInput(message.data) : message.data,
    };

    for (const [, client] of this.clients) {
      if (!client.subscriptions.has(serverId)) {
        continue;
      }
      if (allowedUsers.includes(client.userId)) {
        try {
          if (client.socket.readyState === 1) {
            client.socket.send(JSON.stringify(sanitizedMessage));
          }
        } catch {
          // Stale socket — ignore
        }
      }
    }

    // Also push to SSE subscribers (HTTP/2 streaming)
    const sseSubs = this.sseSubscribers.get(serverId);
    if (sseSubs) {
      const msgType = message.type;

      // Console SSE subscribers only need console_output, eula_required, error, and connected.
      // Skip high-frequency non-console events (resource_stats, server_state_update, etc.)
      // to avoid flooding the SSE connection with irrelevant data.
      if (
        msgType !== 'console_output' &&
        msgType !== 'eula_required' &&
        msgType !== 'error' &&
        msgType !== 'connected'
      ) {
        return;
      }

      const event = msgType === 'console_output'
        ? 'console_output'
        : msgType === 'error'
          ? 'error'
          : msgType === 'eula_required'
            ? 'eula_required'
            : 'message';

      const eventData = event === 'message'
        ? JSON.stringify(message)
        : JSON.stringify({
          serverId: message.serverId,
          stream: message.stream ?? 'stdout',
          data: message.data ?? '',
          timestamp: message.timestamp ?? new Date().toISOString(),
          type: message.type,
          eulaText: message.eulaText,
          eulaServerUuid: message.serverUuid,
          error: message.error,
        });

      for (const [, sub] of sseSubs) {
        sub.lastActivity = Date.now();
        try {
          sub.push(event, eventData);
        } catch {
          // Stale subscriber — ignore
        }
      }
    }
  }

  // ── SSE Subscriber Management ────────────────────────────────────────────────

  /**
   * Register an SSE subscriber for a server's console output.
   * Returns an unsubscribe function to call when the SSE connection closes.
   */
  addSseSubscriber(
    serverId: string,
    push: (event: string, data: string) => void,
  ): { unsubscribe: () => void; touch: () => void } {
    if (!this.sseSubscribers.has(serverId)) {
      this.sseSubscribers.set(serverId, new Map());
    }
    const sseSubs = this.sseSubscribers.get(serverId);
    if (sseSubs && sseSubs.size >= this.MAX_SSE_CONSOLE_PER_SERVER) {
      throw new Error(`SSE console subscriber cap reached for server ${serverId}`);
    }
    const subscriberId = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    if (sseSubs) {
      sseSubs.set(subscriberId, { push, lastActivity: Date.now() });
    }
    this.logger.debug({ serverId, subscriberId }, 'SSE subscriber added');

    const unsubscribe = () => {
      const subs = this.sseSubscribers.get(serverId);
      if (subs) {
        subs.delete(subscriberId);
        if (subs.size === 0) {
          this.sseSubscribers.delete(serverId);
        }
        this.logger.debug({ serverId, subscriberId }, 'SSE subscriber removed');
      }
    };

    const touch = () => {
      const subs = this.sseSubscribers.get(serverId);
      if (subs) {
        const sub = subs.get(subscriberId);
        if (sub) {
          sub.lastActivity = Date.now();
        }
      }
    };

    return { unsubscribe, touch };
  }

  /**
   * Check how many SSE subscribers are active for a server.
   */
  getSseSubscriberCount(serverId: string): number {
    return this.sseSubscribers.get(serverId)?.size ?? 0;
  }

  /**
   * Register an SSE subscriber for specific event types on a server.
   * Returns an unsubscribe function.
   *
   * @param serverId - The server to subscribe to
   * @param eventTypes - Array of event types to receive (e.g. ['server_state_update', 'backup_complete'])
   * @param push - Function called with (eventType, eventData) when matching messages arrive
   */
  addSseEventSubscriber(
    serverId: string,
    eventTypes: string[],
    push: (event: string, data: any) => void,
  ): () => void {
    if (!this.sseEventSubscribers.has(serverId)) {
      this.sseEventSubscribers.set(serverId, new Map());
    }
    const sseEventSubs = this.sseEventSubscribers.get(serverId);
    if (sseEventSubs && sseEventSubs.size >= this.MAX_SSE_EVENTS_PER_SERVER) {
      throw new Error(`SSE event subscriber cap reached for server ${serverId}`);
    }
    const subscriberId = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    if (sseEventSubs) {
      sseEventSubs.set(subscriberId, { eventTypes, push, lastActivity: Date.now() });
    }
    this.logger.debug({ serverId, subscriberId, eventTypes }, 'SSE event subscriber added');

    return () => {
      const subs = this.sseEventSubscribers.get(serverId);
      if (subs) {
        subs.delete(subscriberId);
        if (subs.size === 0) {
          this.sseEventSubscribers.delete(serverId);
        }
        this.logger.debug({ serverId, subscriberId }, 'SSE event subscriber removed');
      }
    };
  }

  /**
   * Get count of SSE event subscribers for a server.
   */
  getSseEventSubscriberCount(serverId: string): number {
    return this.sseEventSubscribers.get(serverId)?.size ?? 0;
  }

  /**
   * Register a global SSE subscriber that receives events for specific servers.
   * Used by SSE endpoints (events stream, metrics stream) to avoid per-WS subscriptions.
   *
   * @param eventTypes - Array of event types to receive (e.g. ['server_state_update', 'resource_stats'])
   * @param push - Function called with (eventType, eventData) when matching messages arrive
   * @param serverIds - Optional list of server IDs to filter events to (if non-empty, events from other servers are ignored)
   */
  getLatestResourceStats(serverId: string): Record<string, unknown> | undefined {
    return this.latestResourceStats.get(serverId);
  }

  addGlobalSseSubscriber(
    eventTypes: string[],
    push: (event: string, data: any) => void,
    serverIds?: string[],
  ): () => void {
    const subscriberId = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    this.globalSseSubscribers.set(subscriberId, {
      eventTypes,
      push,
      serverIds: serverIds?.length ? new Set(serverIds) : undefined,
      lastActivity: Date.now(),
    });
    this.logger.debug({ subscriberId, eventTypes, serverIds }, 'Global SSE subscriber added');


    return () => {
      this.globalSseSubscribers.delete(subscriberId);
      this.logger.debug({ subscriberId }, 'Global SSE subscriber removed');
    };
  }

  private allowConsoleCommand(clientId: string) {
    const now = Date.now();
    const windowMs = this.consoleInputLimit.windowMs;
    const limit = this.consoleInputLimit.max;
    this.maybeRefreshConsoleLimits(now);
    const existing = this.clientCommandCounters.get(clientId);
    if (!existing || now >= existing.resetAt) {
      this.clientCommandCounters.set(clientId, { count: 1, resetAt: now + windowMs });
      return true;
    }
    if (existing.count >= limit) {
      return false;
    }
    existing.count += 1;
    return true;
  }

  private maybeRefreshConsoleLimits(now = Date.now()) {
    if (now - this.lastConsoleLimitRefreshAt < this.consoleLimitRefreshIntervalMs) {
      return;
    }
    this.lastConsoleLimitRefreshAt = now;
    this.refreshConsoleLimits().catch((err) =>
      this.logger.warn({ err }, "Failed to refresh console rate limits")
    );
  }

  private allowConsoleOutput(serverId: string) {
    const now = Date.now();
    const windowMs = this.consoleOutputLimit.windowMs;
    const limit = this.consoleOutputLimit.max;
    const existing = this.consoleOutputCounters.get(serverId);
    if (!existing || now >= existing.resetAt) {
      this.consoleOutputCounters.set(serverId, { count: 1, resetAt: now + windowMs, warned: false });
      return true;
    }
    existing.count += 1;
    return existing.count <= limit;
  }

  private async maybeWarnConsoleThrottle(serverId: string) {
    const now = Date.now();
    const entry = this.consoleOutputCounters.get(serverId);
    if (!entry || entry.warned || now >= entry.resetAt) {
      return;
    }
    entry.warned = true;
    await this.routeConsoleToSubscribers(serverId, {
      type: "console_output",
      serverId,
      stream: "system",
      data: "[Catalyst] Console output throttled.\n",
      timestamp: now,
    });
  }

  private async requestConsoleStream(serverId: string, serverUuid: string) {
    const server = await this.prisma.server.findUnique({
      where: { id: serverId },
    });
    if (!server) {
      return;
    }
    const resumeKey = `${server.nodeId}:${serverId}`;
    const now = Date.now();
    const last = this.consoleResumeTimestamps.get(resumeKey) ?? 0;
    if (now - last < 1000) {
      return;
    }
    this.consoleResumeTimestamps.set(resumeKey, now);
    const agent = this.agents.get(server.nodeId);
    if (agent && agent.socket.readyState === 1) {
      agent.socket.send(
        JSON.stringify({
          type: "resume_console",
          serverId,
          serverUuid,
        })
      );
    }
  }

  private startHeartbeatCheck() {
    this.heartbeatInterval = setInterval(() => {
      const now = Date.now();
      const timeout = 60000; // 60 seconds - agent sends every 15s

      for (const [nodeId, agent] of this.agents) {
        if (now - agent.lastHeartbeat > timeout) {
          this.logger.warn(`Agent heartbeat timeout: ${nodeId}`);
          agent.socket.close();
          this.agents.delete(nodeId);
        this.agentUpdateSent.delete(nodeId);
          this.prisma.node.update({
            where: { id: nodeId },
            data: { isOnline: false },
          }).catch(err => {
            this.logger.error({ err, nodeId }, 'Failed to update node status on heartbeat timeout');
            captureSystemError({
              level: 'error',
              component: 'WebSocketGateway',
              message: `Failed to update node status on heartbeat timeout: ${nodeId}`,
              stack: err instanceof Error ? err.stack : undefined,
              metadata: { nodeId },
            }).catch(() => {});
          });
          this.pushToAdminSubscribers('node_updated', {
            type: 'node_updated',
            nodeId,
            isOnline: false,
            timestamp: Date.now(),
          });
        }
      }
    }, 10000); // Check every 10 seconds
  }

  private sweepCounters() {
    const now = Date.now();
    for (const [key, val] of this.consoleOutputCounters) {
      if (now >= val.resetAt) this.consoleOutputCounters.delete(key);
    }
    for (const [key, val] of this.clientCommandCounters) {
      if (now >= val.resetAt) this.clientCommandCounters.delete(key);
    }
    for (const [key, val] of this.agentMessageCounters) {
      if (now >= val.resetAt) this.agentMessageCounters.delete(key);
    }
    for (const [key, val] of this.agentMetricsCounters) {
      if (now >= val.resetAt) this.agentMetricsCounters.delete(key);
    }
    for (const [key, val] of this.serverMetricsCounters) {
      if (now >= val.resetAt) this.serverMetricsCounters.delete(key);
    }
    for (const [key, val] of this.consoleResumeTimestamps) {
      // Resume timestamps are single-use; expire after 60 seconds
      if (now - val > 60_000) this.consoleResumeTimestamps.delete(key);
    }
  }

  private startMaintenanceSweep() {
    this.subscriberSweepInterval = setInterval(() => {
      this.sweepSseSubscribers();
      this.sweepSseEventSubscribers();
      this.sweepGlobalSubscribers();
      this.sweepAdminSubscribers();
      this.sweepCounters();
    }, 60000);
  }

  private sweepSseSubscribers() {
    const now = Date.now();
    // Console SSE connections are long-lived by design (agents may be offline for
    // extended periods while browsers stay connected). Use a 5-minute sweep to
    // avoid deleting active subscribers during agent reconnections.
    const SWEEP_MS = 300_000;
    for (const [serverId, subs] of this.sseSubscribers) {
      for (const [subId, sub] of subs) {
        if (now - sub.lastActivity > SWEEP_MS) {
          subs.delete(subId);
        }
      }
      if (subs.size === 0) {
        this.sseSubscribers.delete(serverId);
      }
    }
  }

  private sweepSseEventSubscribers() {
    const now = Date.now();
    for (const [serverId, subs] of this.sseEventSubscribers) {
      for (const [subId, sub] of subs) {
        if (now - sub.lastActivity > 300_000) {
          subs.delete(subId);
        }
      }
      if (subs.size === 0) {
        this.sseEventSubscribers.delete(serverId);
      }
    }
  }

  private sweepGlobalSubscribers() {
    const now = Date.now();
    for (const [subId, sub] of this.globalSseSubscribers) {
      if (now - sub.lastActivity > 300_000) {
        this.globalSseSubscribers.delete(subId);
      }
    }
  }

  private sweepAdminSubscribers() {
    const now = Date.now();
    for (const [subId, sub] of this.adminEventSubscribers) {
      if (now - sub.lastActivity > 300_000) {
        this.adminEventSubscribers.delete(subId);
      }
    }
  }

  // Send message to agent (for API endpoints)
  async sendToAgent(nodeId: string, message: any): Promise<boolean> {
    const agent = this.agents.get(nodeId);
    if (!agent || !agent.authenticated || agent.socket.readyState !== 1) {
      this.logger.warn(
        { nodeId, type: typeof message?.type === "string" ? message.type : undefined },
        "Cannot send to agent: not connected",
      );
      return false;
    }

    try {
      agent.socket.send(JSON.stringify(message));
      return true;
    } catch (err) {
      captureSystemError({
        level: 'error',
        component: 'WebSocketGateway',
        message: err instanceof Error ? err.message : `Error sending message to agent ${nodeId}`,
        stack: err instanceof Error ? err.stack : undefined,
        metadata: { nodeId },
      }).catch(() => {});
      this.logger.error(err, `Error sending message to agent ${nodeId}`);
      return false;
    }
  }

  /** Send a raw binary payload to an agent (used for efficient backup streaming). */
  sendBinaryToAgent(nodeId: string, data: Buffer): boolean {
    const agent = this.agents.get(nodeId);
    if (!agent || !agent.authenticated || agent.socket.readyState !== 1) {
      return false;
    }
    try {
      agent.socket.send(data);
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Set up a transparent binary relay between two agents for backup streaming.
   * Binary frames from sourceNodeId are forwarded directly to targetNodeId.
   * Returns a promise that resolves when the source sends backup_stream_complete.
   */
  async relayBackupStream(
    sourceNodeId: string,
    targetNodeId: string,
  ): Promise<void> {
    return new Promise((resolve, reject) => {
      const sourceAgent = this.agents.get(sourceNodeId);
      const targetAgent = this.agents.get(targetNodeId);

      if (!sourceAgent || sourceAgent.socket.readyState !== 1) {
        return reject(new Error(`Source agent ${sourceNodeId} not connected`));
      }
      if (!targetAgent || targetAgent.socket.readyState !== 1) {
        return reject(new Error(`Target agent ${targetNodeId} not connected`));
      }

      if (this.activeBackupRelay) {
        return reject(new Error("A backup relay is already active"));
      }

      const timeout = setTimeout(() => {
        this.activeBackupRelay = null;
        reject(new Error("Backup stream relay timed out (5 min)"));
      }, 5 * 60 * 1000);

      this.activeBackupRelay = { sourceNodeId, targetNodeId, resolve, reject };

      // The handleAgentMessage method will forward binary frames while this relay is active.
      // The source agent sends a text frame "backup_stream_complete" when done,
      // which is handled by the normal message path below.

      // Store timeout reference for cleanup
      (this.activeBackupRelay as any)._timeout = timeout;
    });
  }

  /** Resolve an active backup relay (called when backup_stream_complete is received). */
  resolveBackupRelay(sourceNodeId: string): void {
    if (this.activeBackupRelay && this.activeBackupRelay.sourceNodeId === sourceNodeId) {
      clearTimeout((this.activeBackupRelay as any)._timeout);
      const { resolve } = this.activeBackupRelay;
      this.activeBackupRelay = null;
      resolve();
    }
  }

  /** Reject and clean up an active backup relay. */
  rejectBackupRelay(sourceNodeId: string, err: Error): void {
    if (this.activeBackupRelay && this.activeBackupRelay.sourceNodeId === sourceNodeId) {
      clearTimeout((this.activeBackupRelay as any)._timeout);
      const { reject } = this.activeBackupRelay;
      this.activeBackupRelay = null;
      reject(err);
    }
  }

  async requestFromAgent(nodeId: string, message: any, timeoutMs = 15000): Promise<any> {
    const agent = this.agents.get(nodeId);
    if (!agent || !agent.authenticated || agent.socket.readyState !== 1) {
      throw new Error(`Agent ${nodeId} not connected`);
    }

    if (this.pendingAgentRequests.size >= this.pendingAgentRequestLimit) {
      return Promise.reject(new Error('Pending agent request limit exceeded'));
    }
    const requestId = message.requestId || crypto.randomUUID();
    const payload = { ...message, requestId };

    const response = new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.pendingAgentRequests.delete(requestId);
        reject(new Error("Agent request timed out"));
      }, timeoutMs);
      this.pendingAgentRequests.set(requestId, { resolve, reject, timeout, kind: "json" });
    });

    agent.socket.send(JSON.stringify(payload));
    return response;
  }

  async requestBinaryFromAgent(nodeId: string, message: any, timeoutMs = 60000): Promise<Buffer> {
    const agent = this.agents.get(nodeId);
    if (!agent || !agent.authenticated || agent.socket.readyState !== 1) {
      throw new Error(`Agent ${nodeId} not connected`);
    }

    if (this.pendingAgentRequests.size >= this.pendingAgentRequestLimit) {
      return Promise.reject(new Error('Pending agent request limit exceeded'));
    }
    const requestId = message.requestId || crypto.randomUUID();
    const payload = { ...message, requestId };

    const response = new Promise<Buffer>((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.pendingAgentRequests.delete(requestId);
        reject(new Error("Agent request timed out"));
      }, timeoutMs);
      this.pendingAgentRequests.set(requestId, {
        resolve,
        reject,
        timeout,
        kind: "binary",
        chunks: [],
      });
    });

    agent.socket.send(JSON.stringify(payload));
    return response;
  }

  async streamBinaryFromAgent(
    nodeId: string,
    message: any,
    onChunk: (chunk: Buffer) => void,
    timeoutMs = 60000,
  ): Promise<void> {
    const agent = this.agents.get(nodeId);
    if (!agent || !agent.authenticated || agent.socket.readyState !== 1) {
      throw new Error(`Agent ${nodeId} not connected`);
    }

    if (this.pendingAgentRequests.size >= this.pendingAgentRequestLimit) {
      return Promise.reject(new Error('Pending agent request limit exceeded'));
    }
    const requestId = message.requestId || crypto.randomUUID();
    const payload = { ...message, requestId };

    const response = new Promise<void>((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.pendingAgentRequests.delete(requestId);
        reject(new Error("Agent request timed out"));
      }, timeoutMs);
      this.pendingAgentRequests.set(requestId, {
        resolve,
        reject,
        timeout,
        kind: "binary",
        onChunk,
      });
    });

    agent.socket.send(JSON.stringify(payload));
    await response;
  }

  /**
   * Disconnect all active WebSocket client connections for a specific user.
   * Used when a user is deleted or banned to immediately revoke their real-time access.
   * Returns the number of connections closed.
   */
  disconnectUser(userId: string): number {
    let closed = 0;
    for (const [clientId, client] of this.clients) {
      if (client.userId === userId) {
        try {
          if (client.socket.readyState === 1) {
            client.socket.close(4001, "User account terminated");
          }
        } catch {
          // Socket may already be closing
        }
        this.clients.delete(clientId);
        closed++;
      }
    }
    if (closed > 0) {
      this.logger.info({ userId, closed }, "Disconnected user WebSocket sessions");
    }
    return closed;
  }

  /**
   * Send a console command from an HTTP request (via SSE console route).
   * This is the HTTP-path equivalent of the WebSocket console_input handler.
   * Validates permissions and rate limits, then forwards to the agent.
   */
  async sendConsoleCommand(serverId: string, userId: string, command: string): Promise<void> {
    const server = await this.prisma.server.findUnique({
      where: { id: serverId },
    });

    if (!server) {
      throw new Error('Server not found');
    }

    // Permission check
    const access = await this.prisma.serverAccess.findUnique({
      where: { userId_serverId: { userId, serverId } },
    });
    const isAdmin = await this.userHasAdminRead(userId);
    const consoleNodeAccess = await hasNodeAccess(this.prisma, userId, server.nodeId);

    if (!access && server.ownerId !== userId && !isAdmin && !consoleNodeAccess) {
      throw Object.assign(new Error('Permission denied'), { code: 403 });
    }
    if (!access?.permissions?.includes('console.write') && server.ownerId !== userId && !isAdmin && !consoleNodeAccess) {
      throw Object.assign(new Error('Permission denied'), { code: 403 });
    }

    // Suspension check
    if (process.env.SUSPENSION_ENFORCED !== 'false' && server.suspendedAt) {
      throw new Error('Server is suspended');
    }

    // Rate limit — check client-side rate limit (we don't have clientId in HTTP context,
    // so we use userId as the key for per-user rate limiting)
    const userCommandCount = this.userCommandCounters.get(userId);
    const now = Date.now();
    if (!userCommandCount || now >= userCommandCount.resetAt) {
      this.userCommandCounters.set(userId, { count: 1, resetAt: now + this.consoleInputLimit.windowMs });
    } else {
      if (userCommandCount.count >= this.consoleInputLimit.max) {
        throw new Error('Rate limit exceeded — too many commands. Please wait before sending more.');
      }
      userCommandCount.count += 1;
    }

    // Also apply server-side rate limit
    if (!this.allowServerCommand(serverId)) {
      throw new Error('Server rate limit exceeded — please wait.');
    }

    // Get the agent for this server's node
    const agent = this.agents.get(server.nodeId);
    if (!agent) {
      throw new Error('Node agent is not connected');
    }

    // Forward to agent
    const agentMessage = JSON.stringify({
      type: 'console_input',
      serverId,
      serverUuid: server.uuid,
      data: command,
    });

    try {
      agent.socket.send(agentMessage);
    } catch (err) {
      this.logger.error({ err, serverId, userId }, 'Failed to forward console command to agent');
      captureSystemError({
        level: 'error',
        component: 'WebSocketGateway',
        message: 'Failed to forward console command to agent',
        stack: err instanceof Error ? err.stack : undefined,
        metadata: { serverId, userId },
      }).catch(() => {});
      throw new Error('Failed to communicate with node agent');
    }

    this.logger.debug({ serverId, userId, commandLength: command.length }, 'Console command forwarded via HTTP/SSE route');
  }

  private userCommandCounters = new Map<string, { count: number; resetAt: number }>();

  // ── Plugin WebSocket Handler Management ──────────────────────────────────

  /**
   * Register a plugin WebSocket message handler.
   * @param type  Prefixed type string, e.g. "plugin:ticketing-plugin:subscribe"
   * @param handler  Async handler receiving (data, clientId, userId)
   * @param pluginName  Name of the registering plugin (for cleanup on unload)
   */
  registerPluginWsHandler(
    type: string,
    handler: (data: any, clientId?: string, userId?: string) => Promise<void> | void,
    pluginName: string,
  ): void {
    this.pluginWsHandlers.set(type, { handler, pluginName });
    this.logger.debug({ type, pluginName }, 'Plugin WS handler registered');
  }

  /**
   * Unregister all WebSocket handlers for a plugin (called on disable/unload).
   */
  unregisterPluginWsHandlers(pluginName: string): void {
    for (const [type, entry] of this.pluginWsHandlers) {
      if (entry.pluginName === pluginName) {
        this.pluginWsHandlers.delete(type);
      }
    }
    this.logger.debug({ pluginName }, 'Plugin WS handlers unregistered');
  }

  /**
   * Broadcast a message to all authenticated WebSocket clients.
   * Used by plugins to push real-time events.
   */
  broadcastToAuthenticated(message: any): void {
    const data = typeof message === 'string' ? message : JSON.stringify(message);
 for (const [, client] of this.clients) {
      if (client.authenticated && client.socket.readyState === 1) {
        try {
          client.socket.send(data);
        } catch {
          // ignore send errors on stale connections
        }
      }
    }
  }

  // ── Discovered container accessors (for auto-import) ───────────────────

  getDiscoveredContainers(nodeId: string) {
    return this.discoveredContainers.get(nodeId) ?? [];
  }

  clearDiscoveredContainers(nodeId: string) {
    this.discoveredContainers.delete(nodeId);
  }

  removeDiscoveredContainer(nodeId: string, containerId: string): boolean {
    const discovered = this.discoveredContainers.get(nodeId) ?? [];
    const filtered = discovered.filter((c) => c.containerId !== containerId);
    if (filtered.length !== discovered.length) {
      this.discoveredContainers.set(nodeId, filtered);
      return true;
    }
    return false;
  }

  /**
   * Destroy the gateway: close all connections and clean up resources.
   */
  destroy(): void {
    this.logger.info('Destroying WebSocket gateway');
    if (this.heartbeatInterval) clearInterval(this.heartbeatInterval);
    if (this.subscriberSweepInterval) clearInterval(this.subscriberSweepInterval);
    for (const [nodeId, agent] of this.agents) {
      try {
        agent.socket.close();
      } catch {
        // ignore
      }
      this.agents.delete(nodeId);
        this.agentUpdateSent.delete(nodeId);
    }
    for (const [clientId, client] of this.clients) {
      try {
        client.socket.close();
      } catch {
        // ignore
      }
      this.clients.delete(clientId);
    }
    this.pendingAgentRequests.clear();
    this.sseSubscribers.clear();
    this.sseEventSubscribers.clear();
    this.globalSseSubscribers.clear();
    this.adminEventSubscribers.clear();
    this.pluginWsHandlers.clear();
    this.discoveredContainers.clear();
    this.logger.info('WebSocket gateway destroyed');
  }

  /**
   * Check if an agent needs to be updated to match the panel version.
   * Sends update_agent command with targetVersion if the agent is behind.
   * Tracks the last-sent version per node to avoid spamming on every health_report.
   */
  private async checkAgentUpdate(nodeId: string, agentVersion: unknown): Promise<void> {
    if (!agentVersion || typeof agentVersion !== 'string') return;

    const panelVersion = (await import('../services/auto-updater')).getCurrentVersion();
    if (!panelVersion || panelVersion === 'unknown') return;

    const agentParts = agentVersion.replace(/^v/, '').split('.').map(Number);
    const panelParts = panelVersion.replace(/^v/, '').split('.').map(Number);
    const maxLen = Math.max(agentParts.length, panelParts.length);

    let agentBehind = false;
    for (let i = 0; i < maxLen; i++) {
      const cur = agentParts[i] || 0;
      const lat = panelParts[i] || 0;
      if (lat > cur) { agentBehind = true; break; }
      if (lat < cur) { break; }
    }

    if (!agentBehind) {
      // Agent is up to date — clear any stale tracking entry.
      this.agentUpdateSent.delete(nodeId);
      return;
    }

    // Only send update if we haven't already requested this exact target version.
    const lastSent = this.agentUpdateSent.get(nodeId);
    if (lastSent === panelVersion) return;

    this.logger.info(
      { nodeId, agentVersion, panelVersion },
      'Agent version behind panel — sending update_agent command',
    );

    const sent = await this.sendToAgent(nodeId, {
      type: 'update_agent',
      targetVersion: panelVersion,
    });

    if (sent) {
      this.agentUpdateSent.set(nodeId, panelVersion);
    }
  }
}

// ── Module-level singleton getter for services that don't have access to the Fastify app ──
let _wsGatewayInstance: WebSocketGateway | null = null;

/** Return the gateway singleton. Returns null before the app calls `setWsGateway()`. */
export function getWsGateway(): WebSocketGateway | null {
  return _wsGatewayInstance;
}

/** Called once from index.ts after the gateway is constructed. */
export function setWsGateway(gw: WebSocketGateway): void {
  _wsGatewayInstance = gw;
}
