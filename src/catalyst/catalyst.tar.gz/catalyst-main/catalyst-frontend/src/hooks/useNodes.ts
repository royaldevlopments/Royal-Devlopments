import { useQuery } from '@tanstack/react-query';
import { qk } from '../lib/queryKeys';
import { nodesApi } from '../services/api/nodes';
import { reportSystemError } from '../services/api/systemErrors';

export function useNodes() {
  return useQuery({
    queryKey: qk.nodes(),
    queryFn: nodesApi.list,
    staleTime: 5 * 60 * 1000,
  });
}

export function useAccessibleNodes() {
  return useQuery({
    queryKey: qk.accessibleNodes(),
    queryFn: nodesApi.getAccessibleNodes,
    staleTime: 5 * 60 * 1000,
  });
}

export function useNode(nodeId?: string) {
  return useQuery({
    queryKey: qk.node(nodeId!),
    queryFn: () => {
      if (nodeId) return nodesApi.get(nodeId);
      reportSystemError({ level: 'error', component: 'useNodes', message: 'missing node id', metadata: { context: 'useNode query' } });
      return Promise.reject(new Error('missing node id'));
    },
    enabled: Boolean(nodeId),
    staleTime: 5 * 60 * 1000,
    placeholderData: (prev) => prev,
  });
}

export function useNodeStats(nodeId?: string) {
  return useQuery({
    queryKey: qk.nodeStats(nodeId!),
    queryFn: () => {
      if (nodeId) return nodesApi.stats(nodeId);
      reportSystemError({ level: 'error', component: 'useNodes', message: 'missing node id', metadata: { context: 'useNodeStats query' } });
      return Promise.reject(new Error('missing node id'));
    },
    enabled: Boolean(nodeId),
    staleTime: 15_000,
    refetchInterval: 10_000,
    refetchIntervalInBackground: false,
  });
}

export function useNodeMetrics(nodeId?: string) {
  return useQuery({
    queryKey: qk.nodeMetrics(nodeId!),
    queryFn: () => {
      if (nodeId) return nodesApi.metrics(nodeId, { hours: 1, limit: 60 });
      reportSystemError({ level: 'error', component: 'useNodes', message: 'missing node id', metadata: { context: 'useNodeMetrics query' } });
      return Promise.reject(new Error('missing node id'));
    },
    enabled: Boolean(nodeId),
    staleTime: 15_000,
    refetchInterval: 15_000,
    refetchIntervalInBackground: false,
  });
}
