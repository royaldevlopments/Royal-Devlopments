export interface TemplateVariable {
  name: string;
  description?: string;
  default: string;
  required: boolean;
  userViewable?: boolean;
  userEditable?: boolean;
  input?: 'text' | 'number' | 'password' | 'checkbox' | 'select' | 'textarea';
  options?: string[];  // Parsed from "in:" rule for select fields
  rules?: string[];
}

export interface TemplateImageOption {
  name: string;
  label?: string;
  image: string;
}

type ModManagerTarget = 'mods' | 'plugins' | 'datapacks' | 'modpacks' | 'addons';

type ModManagerProvider =
  | string
  | {
      id: string;
      label?: string;
      game?: string;
      targets?: ModManagerTarget[];
      curseforge?: {
        gameId?: string | number;
        gameSlug?: string;
        classSlugs?: Partial<Record<ModManagerTarget, string>>;
      };
    };

export interface TemplateFeatures {
  restartOnExit?: boolean;
  maxInstances?: number;
  configFile?: string;
  configFiles?: string[];
  fileDenylist?: string[];
  installEntrypoint?: string;
  pterodactylFeatures?: string[];
  pterodactylSpecVersion?: string;
  pterodactylConfigFiles?: Record<string, any>;
  startupDetection?: Record<string, any>;
  startupDonePattern?: string | string[];
  logDetection?: Record<string, any>;
  updateUrl?: string;
  exportedAt?: string;
  modManager?: {
    targets?: ModManagerTarget[];
    providers: ModManagerProvider[];
    paths?: Record<string, string>;
  };
  pluginManager?: {
    providers: string[];
    paths?: Record<string, string>;
  };
  backupPaths?: string[];
  fileEditor?: {
    enabled?: boolean;
    restrictedPaths?: string[];
  };
  iconUrl?: string;
  tags?: string[];
  exportFiles?: string[];
  [key: string]: any;
}

export interface Nest {
  id: string;
  name: string;
  description?: string;
  icon?: string;
  author?: string;
  templateCount?: number;
}

export interface Template {
  id: string;
  name: string;
  description?: string;
  author: string;
  version: string;
  image: string;
  nestId?: string | null;
  nest?: Nest | null;
  images?: TemplateImageOption[];
  defaultImage?: string;
  installImage?: string;
  installEntrypoint?: string;
  startup: string;
  stopCommand: string;
  sendSignalTo: 'SIGTERM' | 'SIGINT' | 'SIGKILL';
  variables: TemplateVariable[];
  installScript?: string;
  supportedPorts: number[];
  allocatedMemoryMb: number;
  allocatedCpuCores: number;
  features?: TemplateFeatures;
  srvService?: string | null;
  srvProtocol?: string;
}
