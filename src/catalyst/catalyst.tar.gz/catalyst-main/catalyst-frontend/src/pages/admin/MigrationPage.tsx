import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { qk } from '@/lib/queryKeys';
import { queryClient } from '@/lib/queryClient';
import { cn } from '@/lib/utils';
import {
 ArrowRightLeft,
 Play,
 Pause,
 RotateCcw,
 X,
 CheckCircle2,
 XCircle,
 Clock,
 Loader2,
 ChevronRight,
 ChevronDown,
 RefreshCw,
 Eye,
 AlertTriangle,
 ExternalLink,
 Server,
 MapPin,
 Users,
 Database,
 HardDrive,
 Shield,
 ArrowRight,
 Wifi,
 WifiOff,
} from 'lucide-react';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Badge } from '../../components/ui/badge';

import {
 Select,
 SelectContent,
 SelectItem,
 SelectTrigger,
 SelectValue,
} from '../../components/ui/select';
import TabHeader from '../../components/servers/tabs/TabHeader';
import ServerTabCard from '../../components/servers/tabs/ServerTabCard';
import StatGrid from '../../components/servers/tabs/StatGrid';
import TabLoadingState from '../../components/servers/tabs/TabLoadingState';
import TabEmptyState from '../../components/servers/tabs/TabEmptyState';
import TabErrorState from '../../components/servers/tabs/TabErrorState';
import { migrationApi } from '../../services/api/migration';
import { notifySuccess, notifyError, notifyInfo } from '../../utils/notify';
import type {
 MigrationJob,
 MigrationStep,
 PterodactylTestResult,
 MigrationPhaseId,
 MigrationScope,
 CatalystNodeOption,
 PterodactylServerInfo,
} from '../../types/migration';
import { MIGRATION_PHASES } from '../../types/migration';

// ── Status helpers ──
const statusConfig: Record<string, { label: string; variant: 'default' | 'success' | 'destructive' | 'secondary' | 'outline'; icon: any }> = {
 pending: { label: 'Pending', variant: 'secondary', icon: Clock },
 validating: { label: 'Validating', variant: 'outline', icon: Loader2 },
 running: { label: 'Running', variant: 'default', icon: Loader2 },
 paused: { label: 'Paused', variant: 'outline', icon: Pause },
 completed: { label: 'Completed', variant: 'success', icon: CheckCircle2 },
 failed: { label: 'Failed', variant: 'destructive', icon: XCircle },
 cancelled: { label: 'Cancelled', variant: 'secondary', icon: X },
};

function StatusBadge({ status }: { status: string }) {
 const config = statusConfig[status] || statusConfig.pending;
 const Icon = config.icon;
 return (
 <Badge variant={config.variant} className="gap-1.5">
 {status === 'running' || status === 'validating' ? (
 <Icon className="h-3 w-3 animate-spin" />
 ) : (
 <Icon className="h-3 w-3" />
 )}
 {config.label}
 </Badge>
 );
}

const stepStatusConfig: Record<string, { label: string; color: string; icon: any; bg: string }> = {
 pending: { label: 'Pending', color: 'text-muted-foreground', icon: Clock, bg: '' },
 running: { label: 'Running', color: 'text-primary', icon: Loader2, bg: 'bg-primary/10' },
 completed: { label: 'Done', color: 'text-success', icon: CheckCircle2, bg: '' },
 failed: { label: 'Failed', color: 'text-destructive', icon: XCircle, bg: 'bg-destructive/10' },
 skipped: { label: 'Skipped', color: 'text-muted-foreground', icon: Clock, bg: '' },
};

// Human-readable step labels
function stepLabel(action: string, metadata?: Record<string, unknown>): string {
 const labels: Record<string, string> = {
 validate_connection: 'Test connection',
 import_location: 'Import location',
 import_nest: 'Import nest',
 import_template: 'Import template',
 import_user: 'Import user',
 import_server: 'Import server',
 import_database_host: 'Import database host',
 import_database: 'Import database',
 import_schedule: 'Import schedule',
 import_backup: 'Import backup',
 download_files: 'Download files',
 };
 const base = labels[action] || action.replace(/_/g, ' ');
 if (metadata?.name) return `${base}: ${metadata.name as string}`;
 return base;
}

// Derive a human-readable skip reason from step metadata
function skipReason(status: string, metadata?: Record<string, unknown> | null): string | null {
 if (status !== 'skipped' && status !== 'completed') return null;
 if (!metadata?.skipped && !metadata?.reason) return null;
 const reason = (metadata.reason as string) || '';
 if (reason.includes('already exists') || reason.includes('already done')) return 'Already existing';
 if (reason.includes('not migrated') || reason.includes('User not migrated')) return 'Not applicable';
 if (reason.includes('server owner') || reason.includes('is server owner')) return 'Not applicable';
 if (reason.includes('No client API key')) return 'No client API key';
 if (reason.includes('backup limit') || reason.includes('backup slot')) return 'No backup slots';
 if (reason.includes('No schedules') || reason.includes('no schedules')) return 'No schedules';
 if (reason.includes('not accessible') || reason.includes('404')) return 'Not available';
 return reason || 'Skipped';
}

// ── Phase icon mapping ──
function PhaseIcon({ phaseId }: { phaseId: string }) {
 const iconMap: Record<string, any> = {
 validate: CheckCircle2,
 locations: MapPin,
 nodes: Server,
 templates: Shield,
 users: Users,
 servers: Server,
 databases: Database,
 schedules: Clock,
 backups: HardDrive,
 files: HardDrive,
 };
 const Icon = iconMap[phaseId] || CheckCircle2;
 return <Icon className="h-4 w-4" />;
}

// ── Duration formatter ──
function formatDuration(ms?: number | null) {
 if (!ms) return '—';
 if (ms < 1000) return `${ms}ms`;
 if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
 return `${Math.floor(ms / 60000)}m ${Math.round((ms % 60000) / 1000)}s`;
}

// ── Progress Bar ──
function ProgressBar({ progress }: { progress: { total: number; completed: number; failed: number; skipped: number } }) {
 const pct = progress.total > 0 ? Math.round(((progress.completed + progress.failed + progress.skipped) / progress.total) * 100) : 0;
 const completedPct = progress.total > 0 ? (progress.completed / progress.total) * 100 : 0;
 const failedPct = progress.total > 0 ? (progress.failed / progress.total) * 100 : 0;

 return (
 <div className="space-y-1">
 <div className="flex justify-between text-xs text-muted-foreground">
 <span>{progress.completed} completed</span>
 <span>{progress.failed} failed</span>
 <span>{pct}%</span>
 </div>
 <div className="h-2 w-full rounded-full bg-surface-2 overflow-hidden">
 <div className="flex h-full">
 <div
 className="h-full bg-success/50 transition-all duration-500"
 style={{ width: `${completedPct}%` }}
 />
 <div
 className="h-full bg-destructive/50 transition-all duration-500"
 style={{ width: `${failedPct}%` }}
 />
 </div>
 </div>
 </div>
 );
}

// ── Phase Step List ──
function PhaseSteps({ steps, onRetry }: { steps: MigrationStep[]; onRetry: (stepId: string) => void }) {
 const [expanded, setExpanded] = useState(false);
 const [errorStepId, setErrorStepId] = useState<string | null>(null);

 if (steps.length === 0) return null;

 const failedSteps = steps.filter(s => s.status === 'failed');
 // Auto-expand if there are failures
 const showExpanded = expanded || failedSteps.length > 0;

 return (
 <div className="mt-2 ml-6 border-l border-border/50 pl-3 space-y-0.5">
 {(showExpanded ? steps : steps.slice(0, 5)).map((step) => {
 const sc = stepStatusConfig[step.status] || stepStatusConfig.pending;
 const StepIcon = sc.icon;
 const showError = step.status === 'failed' && errorStepId === step.id;
 return (
 <div
 key={step.id}
 className={`${sc.bg} rounded px-2 py-1 -mx-2`}
 >
 <div className="flex items-center gap-2">
 <StepIcon className={`h-3 w-3 flex-shrink-0 ${sc.color} ${step.status === 'running' ? 'animate-spin' : ''}`} />
 <span className="text-xs text-foreground flex-1 truncate">
 {stepLabel(step.action, step.metadata as Record<string, unknown>)}
 {step.sourceId && (
 <span className="text-muted-foreground"> #{step.sourceId}</span>
 )}
 {skipReason(step.status, step.metadata as Record<string, unknown>) && (
 <span className="text-muted-foreground ml-1.5">
 — {skipReason(step.status, step.metadata as Record<string, unknown>)}
 </span>
 )}
 </span>
 <span className="text-xs text-muted-foreground flex-shrink-0">{formatDuration(step.durationMs)}</span>
 {step.status === 'failed' && (
 <div className="flex items-center gap-1.5 flex-shrink-0">
 <button
 onClick={() => setErrorStepId(showError ? null : step.id)}
 className="text-xs text-muted-foreground hover:text-foreground"
 title="Toggle error details"
 >
 {showError ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
 </button>
 <button
 onClick={() => onRetry(step.id)}
 className="text-xs text-primary hover:text-primary/80"
 title="Retry"
 >
 <RefreshCw className="h-3 w-3" />
 </button>
 </div>
 )}
 {step.status === 'completed' && step.metadata && (
 <CheckCircle2 className="h-3 w-3 text-success/50 flex-shrink-0" />
 )}
 </div>
 {showError && step.error && (
 <div className="mt-1 pl-5">
 <p className="text-xs text-destructive bg-danger/5 border border-danger/20 rounded px-2 py-1.5 break-all">
 {step.error}
 </p>
 </div>
 )}
 </div>
 );
 })}
 {steps.length > 5 && failedSteps.length === 0 && (
 <button
 onClick={() => setExpanded(!expanded)}
 className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground mt-0.5"
 >
 {expanded ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
 {expanded ? 'Show less' : `${steps.length - 5} more...`}
 </button>
 )}
 </div>
 );
}

// ── What Gets Migrated Card ──
function WhatGetsMigratedCard() {
 const sections = [
 {
 title: 'Server Configuration',
 items: [
 'Name, description, and container name (identifier)',
 'All egg variable values (environment)',
 'Startup command override',
 'Docker image override',
 'Memory, CPU, disk, swap, and IO weight limits',
 'Port allocations from Catalyst node',
 'Suspension status',
 ],
 },
 {
 title: 'Users & Permissions',
 items: [
 'User accounts (email, name, admin status)',
 'Subusers with permission mapping',
 'Server ownership (owner gets full access)',
 'Passwords reset (cannot import bcrypt hashes)',
 ],
 },
 {
 title: 'Templates & Config',
 'items': [
 'Nests and eggs (auto-converted to Catalyst templates)',
 'Config file editor support (from egg definition)',
 'Install image and scripts',
 ],
 },
 {
 title: 'Data & Files',
 items: [
 'Server files (via Pterodactyl backup system)',
 'SHA1 checksum validation on file transfer',
 'Databases and database hosts (preserves passwords)',
 ],
 },
 {
 title: 'Schedules & Tasks',
 items: [
 'Scheduled tasks (cron jobs) with time offsets',
 'Power actions and command sequences',
 ],
 },
 {
 title: 'Not Migrated',
 items: [
 'API keys (users create fresh ones)',
 'User passwords (must be reset after migration)',
 'Activity logs and audit history',
 'Node allocations (uses Catalyst\'s allocation system)',
 ],
 dim: true,
 },
 ];

 return (
 <ServerTabCard>
 <h3 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
 <ArrowRightLeft className="h-4 w-4 text-primary" />
 What Gets Migrated
 </h3>
 <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
 {sections.map(section => (
 <div key={section.title}>
 <div className={`text-xs font-semibold uppercase tracking-wider mb-1.5 ${section.dim ? 'text-muted-foreground' : 'text-muted-foreground'}`}>
 {section.title}
 </div>
 <ul className="space-y-1">
 {section.items.map(item => (
 <li key={item} className="flex items-start gap-1.5 text-xs">
 {section.dim ? (
 <XCircle className="h-3 w-3 text-muted-foreground mt-0.5 flex-shrink-0" />
 ) : (
 <CheckCircle2 className="h-3 w-3 text-success/50 mt-0.5 flex-shrink-0" />
 )}
 <span className={section.dim ? 'text-muted-foreground' : 'text-muted-foreground'}>{item}</span>
 </li>
 ))}
 </ul>
 </div>
 ))}
 </div>
 </ServerTabCard>
 );
}

// ── Server Import Summary ──
function ServerImportSummary({ server }: { server: PterodactylServerInfo }) {
 const items: Array<{ label: string; value: number | string | boolean; icon: any }> = [
 { label: 'Memory', value: `${server.memory} MB`, icon: HardDrive },
 { label: 'Disk', value: `${server.disk} MB`, icon: HardDrive },
 { label: 'CPU', value: `${server.cpu}%`, icon: Server },
 ];

 const imports: Array<{ label: string; count: number; icon: any; zeroLabel?: string }> = [
 { label: 'Schedules', count: server.schedules, icon: Clock },
 { label: 'Subusers', count: server.subusers, icon: Users },
 { label: 'Databases', count: server.databases, icon: Database },
 { label: 'Server Files', count: server.backupSlots > 0 ? 1 : 0, icon: HardDrive, zeroLabel: 'No backup slots' },
 ];

 return (
 <div className="mt-2 ml-1 space-y-2">
 {/* Server resources */}
 <div className="flex flex-wrap gap-x-4 gap-y-1">
 {items.map(item => (
 <span key={item.label} className="flex items-center gap-1.5 text-xs text-muted-foreground">
 <item.icon className="h-3 w-3 text-muted-foreground" />
 <span className="text-muted-foreground">{item.label}:</span>
 <span className="text-foreground font-medium">{item.value}</span>
 </span>
 ))}
 {server.suspended && (
 <span className="flex items-center gap-1.5 text-xs text-warning">
 <Pause className="h-3 w-3" />
 Suspended
 </span>
 )}
 </div>

 {/* What gets imported */}
 <div className="text-[11px] text-muted-foreground uppercase tracking-wider font-medium">Imports</div>
 <div className="grid grid-cols-2 gap-x-4 gap-y-1">
 {/* Always imported */}
 <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
 <CheckCircle2 className="h-3 w-3 text-success/60" />
 Server config &amp; env vars
 </span>
 <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
 <CheckCircle2 className="h-3 w-3 text-success/60" />
 Port allocations
 </span>
 <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
 <CheckCircle2 className="h-3 w-3 text-success/60" />
 Startup command
 </span>
 <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
 <CheckCircle2 className="h-3 w-3 text-success/60" />
 Docker image override
 </span>
 <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
 <CheckCircle2 className="h-3 w-3 text-success/60" />
 Config file editor
 </span>
 <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
 <CheckCircle2 className="h-3 w-3 text-success/60" />
 Swap &amp; IO weight
 </span>
 {/* Conditional imports */}
 {imports.map(item => (
 <span
 key={item.label}
 className={`flex items-center gap-1.5 text-xs ${
 item.count > 0
 ? 'text-muted-foreground'
 : 'text-muted-foreground'
 }`}
 >
 {item.count > 0 ? (
 <CheckCircle2 className="h-3 w-3 text-success/60" />
 ) : (
 <XCircle className="h-3 w-3 text-muted-foreground" />
 )}
 {item.label}
 {item.count > 0 && (
 <span className="text-muted-foreground font-medium">({item.count})</span>
 )}
 {item.count === 0 && item.zeroLabel && (
 <span className="text-muted-foreground text-[10px]">
 — {item.zeroLabel}
 </span>
 )}
 </span>
 ))}
 </div>
 </div>
 );
}

// ── Node Mapping Section (full / node scope) ──
function NodeMappingSection({
 nodes,
 servers,
 nodeMappings,
 setNodeMappings,
 onlineNodes,
 scope,
}: {
 nodes: Array<{ id: number; name: string; fqdn: string; memory: number; serverCount: number }>;
 servers: PterodactylServerInfo[];
 nodeMappings: Record<string, string>;
 setNodeMappings: React.Dispatch<React.SetStateAction<Record<string, string>>>;
 onlineNodes: CatalystNodeOption[];
 scope: MigrationScope;
}) {
 const [expandedNodeId, setExpandedNodeId] = useState<number | null>(null);

 const serversByNode = useMemo(() => {
 const map = new Map<number, PterodactylServerInfo[]>();
 for (const s of servers) {
 const list = map.get(s.nodeId) || [];
 list.push(s);
 map.set(s.nodeId, list);
 }
 return map;
 }, [servers]);

 return (
 <div className="space-y-2">
 <label className="text-sm font-medium text-foreground">
 Map Pterodactyl Nodes to Catalyst Nodes
 </label>
 <p className="text-xs text-muted-foreground">
 {scope === 'full'
 ? 'All Pterodactyl nodes must be mapped. Click a node to see what gets imported.'
 : 'Select which Pterodactyl nodes to map. Click to see server import details.'}
 </p>
 <div className="max-h-80 overflow-y-auto rounded-lg border border-border bg-surface-1 divide-y divide-border">
 {nodes.map(node => {
 const expanded = expandedNodeId === node.id;
 const nodeServers = serversByNode.get(node.id) || [];
 return (
 <div key={node.id}>
 <div
 className="flex items-center gap-3 px-3 py-2.5 cursor-pointer hover:bg-surface-2/50 transition-colors"
 onClick={() => setExpandedNodeId(expanded ? null : node.id)}
 >
 <div className="flex-1 min-w-0">
 <div className="text-sm text-foreground truncate flex items-center gap-2">
 {expanded ? <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" /> : <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" />}
 {node.name}
 <span className="text-xs text-muted-foreground font-normal">{node.serverCount} servers</span>
 </div>
 <div className="text-xs text-muted-foreground">{node.fqdn} · {node.memory} MB</div>
 </div>
 <ArrowRight className="h-4 w-4 text-muted-foreground flex-shrink-0" />
 <div onClick={e => e.stopPropagation()}>
 <Select
 value={nodeMappings[String(node.id)] || ''}
 onValueChange={(v) =>
 setNodeMappings(prev => ({ ...prev, [String(node.id)]: v }))
 }
 >
 <SelectTrigger className="w-48 bg-card border-border/40 text-foreground text-xs h-8">
 <SelectValue placeholder="Select target node" />
 </SelectTrigger>
 <SelectContent>
 {onlineNodes.map(cn => (
 <SelectItem key={cn.id} value={cn.id}>
 <span className="flex items-center gap-1.5">
 <Wifi className="h-3 w-3 text-success" />
 {cn.name}
 <span className="text-muted-foreground">({cn.locationName})</span>
 </span>
 </SelectItem>
 ))}
 </SelectContent>
 </Select>
 </div>
 </div>
 {expanded && nodeServers.length > 0 && (
 <div className="border-t border-border/50 bg-surface-1/50">
 <div className="px-4 py-2">
 <div className="text-[11px] text-muted-foreground uppercase tracking-wider font-medium mb-2">
 Servers on this node ({nodeServers.length})
 </div>
 <div className="space-y-3">
 {nodeServers.map(s => (
 <div key={s.id} className="rounded-md border border-border/50 bg-surface-1 px-3 py-2">
 <div className="text-xs text-foreground font-medium">{s.name}</div>
 <div className="text-[11px] text-muted-foreground">
 {s.nestName}/{s.eggName}
 {s.suspended && (
 <span className="text-warning ml-2">(suspended)</span>
 )}
 </div>
 <ServerImportSummary server={s} />
 </div>
 ))}
 </div>
 </div>
 </div>
 )}
 </div>
 );
 })}
 </div>
 </div>
 );
}

// ── Server Mapping List (server scope) ──
function ServerMappingList({
 servers,
 serverMappings,
 setServerMappings,
 onlineNodes,
}: {
 servers: PterodactylServerInfo[];
 serverMappings: Record<string, string>;
 setServerMappings: React.Dispatch<React.SetStateAction<Record<string, string>>>;
 onlineNodes: CatalystNodeOption[];
}) {
 const [expandedId, setExpandedId] = useState<number | null>(null);

 return (
 <div className="space-y-2">
 <label className="text-sm font-medium text-foreground">
 Map Pterodactyl Servers to Catalyst Nodes
 </label>
 <p className="text-xs text-muted-foreground">
 Click a server to see what gets imported automatically.
 </p>
 <div className="max-h-96 overflow-y-auto rounded-lg border border-border bg-surface-1 divide-y divide-border">
 {servers.map(server => {
 const expanded = expandedId === server.id;
 return (
 <div key={server.id}>
 <div
 className="flex items-center gap-3 px-3 py-2.5 cursor-pointer hover:bg-surface-2/50 transition-colors"
 onClick={() => setExpandedId(expanded ? null : server.id)}
 >
 <div className="flex-1 min-w-0">
 <div className="text-sm text-foreground truncate flex items-center gap-2">
 {expanded ? <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" /> : <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" />}
 {server.name}
 {server.backupSlots === 0 && (
 <span className="inline-flex items-center gap-1 text-[10px] text-warning bg-warning/50 border border-warning/30 rounded px-1.5 py-0">
 <AlertTriangle className="h-2.5 w-2.5" />
 no backups
 </span>
 )}
 {server.backupSlots > 0 && server.currentBackups >= server.backupSlots && (
 <span className="inline-flex items-center gap-1 text-[10px] text-warning/80 bg-warning/30 border border-warning/20 rounded px-1.5 py-0">
 <AlertTriangle className="h-2.5 w-2.5" />
 slots full
 </span>
 )}
 {server.suspended && (
 <span className="inline-flex items-center gap-1 text-[10px] text-warning bg-warning/30 border border-warning/20 rounded px-1.5 py-0">
 Suspended
 </span>
 )}
 </div>
 <div className="text-xs text-muted-foreground">
 {server.nestName}/{server.eggName} · {server.nodeName}
 <span className="text-muted-foreground ml-2">
 {server.memory} MB · {server.disk} MB · {server.cpu}% CPU
 </span>
 </div>
 </div>
 <ArrowRight className="h-4 w-4 text-muted-foreground flex-shrink-0" />
 <div onClick={e => e.stopPropagation()}>
 <Select
 value={serverMappings[String(server.id)] || ''}
 onValueChange={(v) =>
 setServerMappings(prev => ({ ...prev, [String(server.id)]: v }))
 }
 >
 <SelectTrigger className="w-48 bg-card border-border/40 text-foreground text-xs h-8">
 <SelectValue placeholder="Select target node" />
 </SelectTrigger>
 <SelectContent>
 {onlineNodes.map(cn => (
 <SelectItem key={cn.id} value={cn.id}>
 <span className="flex items-center gap-1.5">
 <Wifi className="h-3 w-3 text-success" />
 {cn.name}
 <span className="text-muted-foreground">({cn.locationName})</span>
 </span>
 </SelectItem>
 ))}
 </SelectContent>
 </Select>
 </div>
 </div>
 {expanded && (
 <div className="px-4 pb-3 border-t border-border/50 bg-surface-1/50">
 <ServerImportSummary server={server} />
 </div>
 )}
 </div>
 );
 })}
 </div>
 </div>
 );
}

// ── Backup Slot Warnings ──
function BackupSlotWarnings({ serversList }: { serversList?: Array<{ id: number; name: string; backupSlots: number; currentBackups: number }> }) {
 if (!serversList) return null;
 const noSlotServers = serversList.filter(s => s.backupSlots === 0);
 const fullSlotServers = serversList.filter(s => s.backupSlots > 0 && s.currentBackups >= s.backupSlots);
 if (noSlotServers.length === 0 && fullSlotServers.length === 0) return null;

 return (
 <div className="space-y-2">
 {noSlotServers.length > 0 && (
 <div className="rounded-lg border border-warning/50 bg-warning/30 p-3">
 <div className="flex items-center gap-2 text-warning">
 <AlertTriangle className="h-4 w-4" />
 <span className="text-sm font-medium">{noSlotServers.length} server{noSlotServers.length > 1 ? 's have' : ' has'} 0 backup slots</span>
 </div>
 <p className="text-sm text-warning/80 mt-1">
 The migration will automatically set the backup limit to 1 on these servers to create a migration backup.
 </p>
 <ul className="text-xs text-warning/70 mt-1 space-y-0.5 ml-4 list-disc">
 {noSlotServers.slice(0, 5).map(s => (
 <li key={s.id}>{s.name}</li>
 ))}
 {noSlotServers.length > 5 && (
 <li className="text-muted-foreground">+{noSlotServers.length - 5} more</li>
 )}
 </ul>
 </div>
 )}
 {fullSlotServers.length > 0 && (
 <div className="rounded-lg border border-warning/50 bg-warning/20 p-3">
 <div className="flex items-center gap-2 text-warning/80">
 <AlertTriangle className="h-4 w-4" />
 <span className="text-sm font-medium">{fullSlotServers.length} server{fullSlotServers.length > 1 ? 's have' : ' has'} all backup slots in use</span>
 </div>
 <p className="text-xs text-warning/60 mt-1">
 The migration will automatically increase the backup limit by 1 to make room for a migration backup.
 </p>
 </div>
 )}
 </div>
 );
}

// ── Main Component ──
export default function MigrationPage() {

 // State
 const [activeTab, setActiveTab] = useState<'new' | 'progress' | 'history'>('new');
 const [panelUrl, setPanelUrl] = useState('');
 const [apiKey, setApiKey] = useState('');
 const [showKey, setShowKey] = useState(false);
 const [clientApiKey, setClientApiKey] = useState('');
 const [showClientKey, setShowClientKey] = useState(false);
 const [migrationScope, setMigrationScope] = useState<MigrationScope>('full');
 const [nodeMappings, setNodeMappings] = useState<Record<string, string>>({});
 const [serverMappings, setServerMappings] = useState<Record<string, string>>({});
 const [testResult, setTestResult] = useState<PterodactylTestResult | null>(null);
 const [testing, setTesting] = useState(false);
 const [activeJobId, setActiveJobId] = useState<string | null>(null);

 // Fetch Catalyst nodes (migration targets)
 const { data: catalystNodes = [] } = useQuery<CatalystNodeOption[]>({
 queryKey: qk.catalystNodes(),
 queryFn: migrationApi.getCatalystNodes,
 staleTime: 5 * 60 * 1000,
 });

 const onlineNodes = catalystNodes.filter(n => n.isOnline);

 // Fetch migration jobs
 const { data: jobs, isLoading: loadingJobs } = useQuery<MigrationJob[]>({
 queryKey: qk.migrationJobs(),
 queryFn: migrationApi.listJobs,
 staleTime: 30_000,
 refetchInterval: (query) => {
 const data = query.state.data;
 if (!Array.isArray(data)) return false;
 const hasActive = data.some(j => j.status === 'running' || j.status === 'validating');
 return hasActive ? 2000 : false;
 },
 });

 // Ensure jobs is always an array for safe usage
 const safeJobs = Array.isArray(jobs) ? jobs : [];

 // Fetch active job
 const { data: activeJob } = useQuery({
 queryKey: qk.migrationJob(activeJobId!),
 queryFn: () => migrationApi.getStatus(activeJobId!),
 enabled: !!activeJobId,
 staleTime: 30_000,
 refetchInterval: (query) => {
 const job = query.state.data;
 if (!job) return false;
 return (job.status === 'running' || job.status === 'validating') ? 2000 : false;
 },
 });

 // Fetch steps for active job
 const { data: activeSteps, isLoading: loadingSteps } = useQuery({
 queryKey: qk.migrationSteps(activeJobId!),
 queryFn: () => migrationApi.getSteps(activeJobId!, { limit: 500 }),
 enabled: !!activeJobId,
 staleTime: 30_000,
 refetchInterval: (_query) => {
 const job = activeJob;
 if (!job) return 2000;
 return ['running', 'validating', 'paused'].includes(job.status) ? 2000 : false;
 },
 });

 // Notify on job completion/failure
 const prevJobStatusRef = useRef<string | null>(null);
 const jobStatus = activeJob?.status;
 const jobError = activeJob?.error;
 useEffect(() => {
 if (!jobStatus) return;
 const prev = prevJobStatusRef.current;
 if (prev && prev === 'running' && jobStatus === 'completed') {
 notifySuccess('Migration completed successfully!');
 }
 if (prev && prev === 'running' && jobStatus === 'failed') {
 notifyError(`Migration failed: ${jobError || 'Unknown error'}`);
 }
 prevJobStatusRef.current = jobStatus;
 }, [jobStatus, jobError]);

 // Auto-detect active job via state sync during render
 const [prevSafeJobs, setPrevSafeJobs] = useState(safeJobs);
 if (safeJobs !== prevSafeJobs) {
 setPrevSafeJobs(safeJobs);
 if (safeJobs) {
 const active = safeJobs.find(j => j.status === 'running' || j.status === 'validating' || j.status === 'paused');
 if (active && active.id !== activeJobId) {
 setActiveJobId(active.id);
 setActiveTab('progress');
 }
 }
 }

 // Mutations
 const testMutation = useMutation({
 mutationFn: () => migrationApi.testConnection(panelUrl, apiKey, clientApiKey || undefined),
 onMutate: () => { setTesting(true); setTestResult(null); },
 onSettled: () => { setTesting(false); },
 onSuccess: (data) => {
 setTestResult(data);
 if (data.success) {
 notifySuccess('Connected to Pterodactyl panel');
 } else {
 notifyError(data.error || 'Connection failed');
 }
 },
 onError: (err: any) => {
 setTestResult({ success: false, error: err.response?.data?.error || err.message });
 notifyError('Connection test failed');
 },
 });

 const startMutation = useMutation({
 mutationFn: () => migrationApi.start({
 url: panelUrl,
 key: apiKey,
 clientApiKey: clientApiKey || undefined,
 scope: migrationScope,
 nodeMappings,
 serverMappings,
 }),
 onSuccess: (data) => {
 setActiveJobId(data.jobId);
 setActiveTab('progress');
 notifySuccess('Migration started');
 },
 onSettled: () => {
 queryClient.invalidateQueries({ queryKey: qk.migrationJobs() });
 },
 onError: (err: any) => {
 notifyError(err.response?.data?.error || 'Failed to start migration');
 },
 });

 const pauseMutation = useMutation({
 mutationFn: () => migrationApi.pause(activeJobId!),
 onSuccess: () => {
 notifyInfo('Migration paused');
 },
 onSettled: () => {
 queryClient.invalidateQueries({ queryKey: qk.migrationJob(activeJobId!) });
 queryClient.invalidateQueries({ queryKey: qk.migrationJobs() });
 },
 onError: (err: any) => notifyError(err.response?.data?.error || 'Failed to pause'),
 });

 const resumeMutation = useMutation({
 mutationFn: () => migrationApi.resume(activeJobId!),
 onSuccess: () => {
 notifySuccess('Migration resumed');
 },
 onSettled: () => {
 queryClient.invalidateQueries({ queryKey: qk.migrationJob(activeJobId!) });
 queryClient.invalidateQueries({ queryKey: qk.migrationJobs() });
 },
 onError: (err: any) => notifyError(err.response?.data?.error || 'Failed to resume'),
 });

 const cancelMutation = useMutation({
 mutationFn: () => migrationApi.cancel(activeJobId!),
 onSuccess: () => {
 notifyInfo('Migration cancelled');
 },
 onSettled: () => {
 queryClient.invalidateQueries({ queryKey: qk.migrationJob(activeJobId!) });
 queryClient.invalidateQueries({ queryKey: qk.migrationJobs() });
 },
 onError: (err: any) => notifyError(err.response?.data?.error || 'Failed to cancel'),
 });

 const retryMutation = useMutation({
 mutationFn: (stepId: string) => migrationApi.retryStep(activeJobId!, stepId),
 onSuccess: () => {
 notifySuccess('Step queued for retry');
 },
 onSettled: () => {
 queryClient.invalidateQueries({ queryKey: qk.migrationJob(activeJobId!) });
 queryClient.invalidateQueries({ queryKey: qk.migrationSteps(activeJobId!) });
 },
 onError: (err: any) => notifyError(err.response?.data?.error || 'Retry failed'),
 });

 const handleRetryStep = useCallback((stepId: string) => {
 retryMutation.mutate(stepId);
 }, [retryMutation]);

 // Group steps by phase
 const stepsByPhase = useMemo(() => {
 if (!activeSteps?.steps) return {};
 const grouped: Record<string, MigrationStep[]> = {};
 for (const step of activeSteps.steps) {
 if (!grouped[step.phase]) grouped[step.phase] = [];
 grouped[step.phase].push(step);
 }
 return grouped;
 }, [activeSteps]);

 // Calculate phase statuses from steps
 const phaseStatuses = useMemo(() => {
 const statuses: Record<string, 'pending' | 'running' | 'completed' | 'failed' | 'skipped'> = {};
 for (const phase of MIGRATION_PHASES) {
 const steps = stepsByPhase[phase.id] || [];
 if (steps.length === 0) {
 statuses[phase.id] = 'pending';
 } else if (steps.some(s => s.status === 'running')) {
 statuses[phase.id] = 'running';
 } else if (steps.every(s => s.status === 'completed' || s.status === 'skipped')) {
 statuses[phase.id] = 'completed';
 } else if (steps.some(s => s.status === 'failed')) {
 statuses[phase.id] = 'failed';
 } else if (steps.every(s => s.status === 'skipped')) {
 statuses[phase.id] = 'skipped';
 } else {
 statuses[phase.id] = 'pending';
 }
 }
 return statuses;
 }, [stepsByPhase]);

 // Ref to scroll active phase into view
 const activePhaseRef = useRef<HTMLDivElement>(null);
 useEffect(() => {
 if (activePhaseRef.current) {
 activePhaseRef.current.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
 }
 }, [activeJob?.currentPhase]);

 // Elapsed time counter for running jobs
 const startedAt = activeJob?.startedAt;
 const status = activeJob?.status;
 const shouldRun = Boolean(startedAt) && ['running', 'validating'].includes(status);
 const [elapsed, setElapsed] = useState(() => {
 if (!shouldRun || !startedAt) return 0;
 return Date.now() - new Date(startedAt).getTime();
 });
 const [prevShouldRun, setPrevShouldRun] = useState(shouldRun);
 if (shouldRun !== prevShouldRun) {
 setPrevShouldRun(shouldRun);
 if (!shouldRun) setElapsed(0);
 }
 useEffect(() => {
 if (!shouldRun || !startedAt) return;
 const startTime = new Date(startedAt).getTime();
 const timer = setInterval(() => setElapsed(Date.now() - startTime), 1000);
 return () => clearInterval(timer);
 }, [shouldRun, startedAt]);

 const tabs = [
 { id: 'new' as const, label: 'New Migration' },
 { id: 'progress' as const, label: 'Active Migration', show: !!activeJobId },
 { id: 'history' as const, label: 'History' },
 ].filter(t => t.show !== false);

 return (
 <div className="space-y-5">
 {/* Page Header */}
 <TabHeader
 icon={ArrowRightLeft}
 title="Migration"
 description="Migrate servers from Pterodactyl to Catalyst"
 />

 {/* Tab Bar */}
 <div className="inline-flex gap-1 rounded-xl border border-border/40 bg-surface-2/40 p-1.5 ">
 {tabs.map(tab => (
 <button
 key={tab.id}
 onClick={() => setActiveTab(tab.id)}
 className={cn(
 'px-3 py-1.5 text-sm font-medium rounded-lg transition-all',
 activeTab === tab.id
 ? 'bg-primary text-primary-foreground '
 : 'text-muted-foreground hover:text-foreground'
 )}
 >
 {tab.label}
 </button>
 ))}
 </div>

 {/* TAB: New Migration */}
 {activeTab === 'new' && (
 <div>
 <WhatGetsMigratedCard />
 <ServerTabCard className="mt-5">
 <h2 className="text-lg font-semibold text-foreground mb-1">Connect to Pterodactyl</h2>
 <p className="text-sm text-muted-foreground mb-6">
 Enter your Pterodactyl panel URL and Application API key. After connecting,
 you will map Pterodactyl nodes or servers to <strong>existing online Catalyst nodes</strong>.
 </p>

 <div className="space-y-4">
 {/* Panel URL */}
 <div className="space-y-1.5">
 <label className="text-sm font-medium text-foreground">Panel URL</label>
 <Input
 value={panelUrl}
 onChange={(e) => setPanelUrl(e.target.value)}
 placeholder="http://panel.example.com"
 className="border-border/40 bg-card"
 />
 </div>

 {/* API Key */}
 <div className="space-y-1.5">
 <label className="text-sm font-medium text-foreground">Application API Key</label>
 <div className="relative">
 <Input
 value={apiKey}
 onChange={(e) => setApiKey(e.target.value)}
 type={showKey ? 'text' : 'password'}
 placeholder="ptla_..."
 className="border-border/40 bg-card pr-10"
 />
 <button
 onClick={() => setShowKey(!showKey)}
 className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
 >
 <Eye className="h-4 w-4" />
 </button>
 </div>
 </div>

 {/* Client API Key */}
 <div className="space-y-1.5">
 <label className="text-sm font-medium text-foreground">
 Client API Key{" "}
 <span className="text-muted-foreground font-normal">(for file migration)</span>
 </label>
 <div className="relative">
 <Input
 value={clientApiKey}
 onChange={(e) => setClientApiKey(e.target.value)}
 type={showClientKey ? 'text' : 'password'}
 placeholder="ptlc_..."
 className="border-border/40 bg-card pr-10"
 />
 <button
 onClick={() => setShowClientKey(!showClientKey)}
 className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
 >
 <Eye className="h-4 w-4" />
 </button>
 </div>
 <p className="text-xs text-muted-foreground">
 Required for backup creation and file migration. Create in Pterodactyl → API Credentials → Client API.
 </p>
 </div>

 {/* Test Result */}
 {testResult && (
 <div className={`rounded-lg border p-4 ${
 testResult.success
 ? 'border-success/30 bg-success/5'
 : 'border-danger/30 bg-danger/5'
 }`}>
 <div className="flex items-center gap-2 mb-2">
 {testResult.success ? (
 <CheckCircle2 className="h-4 w-4 text-success" />
 ) : (
 <XCircle className="h-4 w-4 text-destructive" />
 )}
 <span className={`text-sm font-medium ${testResult.success ? 'text-success' : 'text-destructive'}`}>
 {testResult.success ? `Connected (v${testResult.version || '1.x'})` : 'Connection Failed'}
 </span>
 </div>
 {!testResult.success ? (
 <p className="text-sm text-destructive">{testResult.error}</p>
 ) : testResult.stats ? (
 <StatGrid
 items={[
 { label: 'Locations', value: testResult.stats.locations },
 { label: 'Nodes', value: testResult.stats.nodes },
 { label: 'Nests', value: testResult.stats.nests },
 { label: 'Users', value: testResult.stats.users },
 { label: 'Servers', value: testResult.stats.servers },
 ]}
 columns={3}
 className="mt-2"
 />
 ) : null}
 </div>
 )}

 {/* Backup slot warnings */}
 <BackupSlotWarnings serversList={testResult?.serversList} />

 {/* Migration Scope (only shown after successful test) */}
 {testResult?.success && (
 <div className="space-y-3">
 <label className="text-sm font-medium text-foreground">Migration Scope</label>
 <div className="grid grid-cols-3 gap-2">
 {([
 { value: 'full' as const, label: 'Full Migration', desc: 'Map all Ptero nodes to Catalyst nodes' },
 { value: 'node' as const, label: 'Node by Node', desc: 'Select which Ptero nodes to migrate' },
 { value: 'server' as const, label: 'Server by Server', desc: 'Map individual servers to Catalyst nodes' },
 ]).map(opt => (
 <button
 key={opt.value}
 onClick={() => {
 setMigrationScope(opt.value);
 setNodeMappings({});
 setServerMappings({});
 }}
 className={`rounded-lg border p-3 text-left transition-colors ${
 migrationScope === opt.value
 ? 'border-primary bg-primary/10'
 : 'border-border bg-surface-1 hover:border-border'
 }`}
 >
 <div className="text-sm font-medium text-foreground">
 {opt.label}
 </div>
 <div className="text-xs text-muted-foreground mt-0.5">{opt.desc}</div>
 </button>
 ))}
 </div>
 </div>
 )}

 {/* Online nodes warning */}
 {testResult?.success && onlineNodes.length === 0 && (
 <TabErrorState
 message="No online Catalyst nodes detected. Migration requires at least one Catalyst node to be online. Start the agent on your nodes first."
 />
 )}

 {/* Node Mapping (full / node scope) */}
 {testResult?.success && (migrationScope === 'full' || migrationScope === 'node')
 && testResult.nodesList && testResult.nodesList.length > 0 && onlineNodes.length > 0 && (
 <NodeMappingSection
 nodes={testResult.nodesList}
 servers={testResult.serversList || []}
 nodeMappings={nodeMappings}
 setNodeMappings={setNodeMappings}
 onlineNodes={onlineNodes}
 scope={migrationScope}
 />
 )}

 {/* Server Mapping (server scope) */}
 {testResult?.success && migrationScope === 'server'
 && testResult.serversList && testResult.serversList.length > 0 && onlineNodes.length > 0 && (
 <ServerMappingList
 servers={testResult.serversList}
 serverMappings={serverMappings}
 setServerMappings={setServerMappings}
 onlineNodes={onlineNodes}
 />
 )}

 {/* Mapping summary */}
 {testResult?.success && onlineNodes.length > 0 && (
 <div className="text-xs text-muted-foreground space-y-1">
 {migrationScope === 'server' && (
 <p>{Object.keys(serverMappings).length} of {testResult.serversList?.length || 0} servers mapped</p>
 )}
 {(migrationScope === 'full' || migrationScope === 'node') && (
 <p>{Object.keys(nodeMappings).length} of {
 migrationScope === 'full' ? testResult.nodesList?.length || 0 : 'selected'
 } nodes mapped</p>
 )}
 </div>
 )}

 {/* Actions */}
 <div className="flex gap-3 pt-2">
 <Button
 onClick={() => testMutation.mutate()}
 disabled={!panelUrl || !apiKey || testing}
 variant="outline"
 className="gap-2"
 >
 {testing ? (
 <Loader2 className="h-4 w-4 animate-spin" />
 ) : (
 <ExternalLink className="h-4 w-4" />
 )}
 Test Connection
 </Button>
 <Button
 onClick={() => startMutation.mutate()}
 disabled={
 !testResult?.success ||
 startMutation.isPending ||
 onlineNodes.length === 0 ||
 (migrationScope === 'server' && Object.keys(serverMappings).length === 0) ||
 ((migrationScope === 'full') && Object.keys(nodeMappings).length !== (testResult.nodesList?.length || 0)) ||
 (migrationScope === 'node' && Object.keys(nodeMappings).length === 0)
 }
 className="gap-2"
 >
 {startMutation.isPending ? (
 <Loader2 className="h-4 w-4 animate-spin" />
 ) : (
 <Play className="h-4 w-4" />
 )}
 Start Migration
 </Button>
 </div>
 </div>
 </ServerTabCard>
 </div>
 )}

 {/* TAB: Active Migration Progress */}
 {activeTab === 'progress' && activeJob && (
 <div className="space-y-5">
 {/* Status Header */}
 <ServerTabCard>
 <div className="flex items-center justify-between mb-4">
 <div className="flex items-center gap-3">
 <StatusBadge status={activeJob.status} />
 <div>
 <h2 className="text-lg font-semibold text-foreground">Migration Progress</h2>
 <p className="text-sm text-muted-foreground">
 {activeJob.sourceUrl}
 {activeJob.currentPhase && (
 <span className="text-muted-foreground">
 {' '}— Phase: <span className="text-foreground">{activeJob.currentPhase}</span>
 </span>
 )}
 </p>
 </div>
 </div>
 <div className="flex gap-2">
 {activeJob.status === 'running' && (
 <Button
 onClick={() => pauseMutation.mutate()}
 disabled={pauseMutation.isPending}
 variant="outline"
 size="sm"
 className="gap-1.5"
 >
 <Pause className="h-3.5 w-3.5" />
 Pause
 </Button>
 )}
 {activeJob.status === 'paused' && (
 <Button
 onClick={() => resumeMutation.mutate()}
 disabled={resumeMutation.isPending}
 size="sm"
 className="gap-1.5"
 >
 <Play className="h-3.5 w-3.5" />
 Resume
 </Button>
 )}
 {(activeJob.status === 'running' || activeJob.status === 'paused') && (
 <Button
 onClick={() => cancelMutation.mutate()}
 disabled={cancelMutation.isPending}
 variant="destructive"
 size="sm"
 className="gap-1.5"
 >
 <X className="h-3.5 w-3.5" />
 Cancel
 </Button>
 )}
 </div>
 </div>

 {/* Progress Bar */}
 <ProgressBar progress={activeJob.progress} />

 {/* Current step detail */}
 {['running', 'validating'].includes(activeJob.status) && activeJob.currentPhase && (() => {
 const phaseSteps = stepsByPhase[activeJob.currentPhase] || [];
 const runningStep = phaseSteps.find(s => s.status === 'running');
 if (!runningStep) return null;
 return (
 <div className="mt-3 flex items-center gap-2 text-xs text-primary">
 <Loader2 className="h-3 w-3 animate-spin" />
 <span>
 {stepLabel(runningStep.action, runningStep.metadata as Record<string, unknown>)}
 {runningStep.sourceId && <span className="text-primary/60"> #{runningStep.sourceId}</span>}
 </span>
 </div>
 );
 })()}
 {activeJob.error && (
 <div className="mt-4 rounded-lg border border-danger/25 bg-danger/5 p-3">
 <div className="flex items-center gap-2 text-destructive">
 <AlertTriangle className="h-4 w-4" />
 <span className="text-sm font-medium">Error</span>
 </div>
 <p className="text-sm text-destructive/80 mt-1">{activeJob.error}</p>
 </div>
 )}

 {/* Timing & Stats */}
 <div className="flex gap-6 mt-4 text-xs text-muted-foreground">
 <span>Started: {activeJob.startedAt ? new Date(activeJob.startedAt).toLocaleString() : '—'}</span>
 {['running', 'validating'].includes(activeJob.status) && elapsed > 0 && (
 <span className="text-muted-foreground font-medium">Elapsed: {formatDuration(elapsed)}</span>
 )}
 {activeJob.completedAt && activeJob.startedAt && (
 <span className="text-muted-foreground">
 Duration: {formatDuration(new Date(activeJob.completedAt).getTime() - new Date(activeJob.startedAt).getTime())}
 </span>
 )}
 </div>
 </ServerTabCard>

 {/* Phase List */}
 <ServerTabCard className="overflow-hidden">
 <div className="pb-3">
 <h3 className="text-sm font-semibold text-foreground">Migration Phases</h3>
 </div>
 <div>
 {MIGRATION_PHASES.map((phase) => {
 const status = phaseStatuses[phase.id] || 'pending';
 const steps = stepsByPhase[phase.id] || [];
 const sc = stepStatusConfig[status];
 const PhaseIconComp = PhaseIcon;
 const isCurrentPhase = activeJob.currentPhase === phase.id;

 const failedInPhase = steps.filter(s => s.status === 'failed').length;

 return (
 <div
 key={phase.id}
 ref={isCurrentPhase ? activePhaseRef : undefined}
 className={`border-b border-border/50 last:border-0 ${
 isCurrentPhase ? 'bg-surface-2/30' : ''
 }`}
 >
 <div className="flex items-center gap-3 px-4 py-3">
 <div className={`flex-shrink-0 ${sc.color}`}>
 {status === 'running' ? (
 <Loader2 className="h-4 w-4 animate-spin" />
 ) : (
 <PhaseIconComp phaseId={phase.id} />
 )}
 </div>
 <div className="flex-1 min-w-0">
 <div className="flex items-center gap-2">
 <span className="text-sm font-medium text-foreground">{phase.label}</span>
 {isCurrentPhase && (
 <Badge variant="default" className="text-[10px] px-1.5 py-0">CURRENT</Badge>
 )}
 </div>
 <div className="text-xs text-muted-foreground mt-0.5">
 {(() => {
 if (steps.length === 0) {
 return 'Waiting...';
 }
 const skippedInPhase = steps.filter(s => s.status === 'skipped' || (s.status === 'completed' && skipReason(s.status, s.metadata as Record<string, unknown>)));
 const realCompleted = steps.filter(s => s.status === 'completed' && !skipReason(s.status, s.metadata as Record<string, unknown>));
 const parts: string[] = [];
 if (realCompleted.length > 0) parts.push(`${realCompleted.length} completed`);
 if (skippedInPhase.length > 0) parts.push(`${skippedInPhase.length} skipped`);
 if (failedInPhase > 0) parts.push(`${failedInPhase} failed`);
 return parts.join(' · ') || `${steps.length} steps`;
 })()}
 </div>
 {/* Inline error preview for phase with failures */}
 {failedInPhase > 0 && status !== 'running' && (
 <div className="mt-1.5">
 {steps.filter(s => s.status === 'failed').slice(0, 2).map(s => (
 <div key={s.id} className="text-[11px] text-destructive/80 truncate max-w-md">
 {stepLabel(s.action, s.metadata as Record<string, unknown>)}: {s.error}
 </div>
 ))}
 {failedInPhase > 2 && (
 <div className="text-[11px] text-muted-foreground">
 +{failedInPhase - 2} more errors
 </div>
 )}
 </div>
 )}
 </div>
 <span className={`text-xs font-medium ${sc.color}`}>
 {sc.label}
 </span>
 </div>
 {steps.length > 0 && (
 <PhaseSteps steps={steps} onRetry={handleRetryStep} />
 )}
 </div>
 );
 })}
 </div>
 </ServerTabCard>
 </div>
 )}

 {/* TAB: Active Migration - No Job */}
 {activeTab === 'progress' && !activeJob && (
 <TabEmptyState
 title="No active migration"
 description="Start a new migration to see progress here."
 />
 )}

 {/* TAB: History */}
 {activeTab === 'history' && (
 <ServerTabCard className="overflow-hidden">
 <div className="flex items-center justify-between pb-3">
 <h3 className="text-sm font-semibold text-foreground">Migration History</h3>
 <button
 onClick={() => queryClient.invalidateQueries({ queryKey: qk.migrationJobs() })}
 className="text-muted-foreground hover:text-foreground"
 >
 <RefreshCw className="h-4 w-4" />
 </button>
 </div>
 {loadingJobs ? (
 <TabLoadingState rows={4} />
 ) : safeJobs.length === 0 ? (
 <TabEmptyState
 title="No migration jobs yet"
 description="Start a new migration to see it here."
 />
 ) : (
 <div className="divide-y divide-border/50">
 {safeJobs.map(job => (
 <button
 key={job.id}
 onClick={() => {
 setActiveJobId(job.id);
 setActiveTab('progress');
 }}
 className="w-full flex items-center gap-4 px-4 py-3 hover:bg-surface-2/30 transition-colors text-left"
 >
 <StatusBadge status={job.status} />
 <div className="flex-1 min-w-0">
 <div className="text-sm text-foreground truncate">{job.sourceUrl}</div>
 <div className="text-xs text-muted-foreground">
 {job.progress?.completed || 0}/{job.progress?.total || 0} steps
 {' · '}
 {new Date(job.createdAt).toLocaleDateString()}
 </div>
 </div>
 {job.error && (
 <AlertTriangle className="h-4 w-4 text-destructive flex-shrink-0" />
 )}
 <ChevronRight className="h-4 w-4 text-muted-foreground flex-shrink-0" />
 </button>
 ))}
 </div>
 )}
 </ServerTabCard>
 )}
 </div>
 );
}
