import { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { qk } from '@/lib/queryKeys';
import { queryClient } from '@/lib/queryClient';
import { nodesApi } from '../../services/api/nodes';
import { notifyError, notifySuccess } from '../../utils/notify';
import { getErrorMessage } from '../../utils/errors';
import { reportSystemError } from '../../services/api/systemErrors';
import { ModalPortal } from '@/components/ui/modal-portal';

export type NodeAssignmentWithExpiration = {
 nodeId: string | null; // null for wildcard (*)
 nodeName: string;
 expiresAt?: string;
 source?: 'user' | 'role'; // For users - shows inherited vs direct
 roleName?: string;
 isWildcard?: boolean; // true if this is a wildcard assignment
};

type Props = {
 roleId?: string; // If editing a role
 userId?: string; // If editing a user
 selectedNodes: NodeAssignmentWithExpiration[];
 onSelectionChange: (nodes: NodeAssignmentWithExpiration[]) => void;
 disabled?: boolean;
 label?: string;
};

export function NodeAssignmentsSelector({
 roleId,
 userId,
 selectedNodes,
 onSelectionChange,
 disabled = false,
 label = 'Node Access',
}: Props) {
 const [search, setSearch] = useState('');
 const [expirationNodeId, setExpirationNodeId] = useState<string | null>(null);
 const [expirationDate, setExpirationDate] = useState('');

 // hasWildcard is derived from the current selection. Computing it during
 // render avoids a setState-in-effect and keeps the UI source-of-truth
 // consistent with the parent's selectedNodes prop.
 const hasWildcard = selectedNodes.some(n => n.isWildcard || n.nodeId === null);

 // Fetch available nodes
 const { data: nodes = [], isLoading: nodesLoading } = useQuery({
 queryKey: qk.nodes(),
 queryFn: () => nodesApi.list(),
 staleTime: 60_000,
 });

 // Fetch current assignments for roles
 const { data: roleAssignmentsData, isLoading: roleAssignmentsLoading } = useQuery({
 queryKey: qk.roleNodes(roleId!),
 queryFn: async () => {
 if (!roleId) return { data: [], hasWildcard: false };
 const response = await fetch(`/api/roles/${roleId}/nodes`, {
 headers: { 'Content-Type': 'application/json' },
 });
 const data = await response.json();
 return { data: data.data || [], hasWildcard: data.hasWildcard || false };
 },
 enabled: !!roleId,
 staleTime: 60_000,
 });

 // Fetch current assignments for users
 const { data: userAssignmentsData, isLoading: userAssignmentsLoading } = useQuery({
 queryKey: qk.userNodes(userId!),
 queryFn: async () => {
 if (!userId) return { data: [], hasWildcard: false };
 const response = await fetch(`/api/roles/users/${userId}/nodes`, {
 headers: { 'Content-Type': 'application/json' },
 });
 const data = await response.json();
 return { data: data.data || [], hasWildcard: data.hasWildcard || false };
 },
 enabled: !!userId,
 staleTime: 60_000,
 });

 // Initialize selections from fetched data
 const assignmentsData = userId ? userAssignmentsData : roleAssignmentsData;
 const hasWildcardFromApi = assignmentsData?.hasWildcard || false;

 // Sync wildcard from API data into the parent's selection. The
 // setState-in-effect anti-pattern is avoided by performing the
 // comparison and propagation in the render phase itself: when the
 // derived API state disagrees with the current selection, we
 // invoke onSelectionChange during render, which causes React to
 // restart the render with the new selection. hasWildcard is now
 // derived from selectedNodes rather than stored.
 const [prevWildcardFromApi, setPrevWildcardFromApi] = useState<boolean | null>(null);
 if (hasWildcardFromApi && !hasWildcard && prevWildcardFromApi !== hasWildcardFromApi) {
 setPrevWildcardFromApi(hasWildcardFromApi);
 const wildcardNode: NodeAssignmentWithExpiration = {
 nodeId: null,
 nodeName: 'All Nodes (*)',
 isWildcard: true,
 source: userId ? 'user' : undefined,
 };
 onSelectionChange([wildcardNode]);
 } else if (!hasWildcardFromApi && hasWildcard && prevWildcardFromApi !== hasWildcardFromApi) {
 setPrevWildcardFromApi(hasWildcardFromApi);
 onSelectionChange(selectedNodes.filter(n => !n.isWildcard && n.nodeId !== null));
 } else if (prevWildcardFromApi !== hasWildcardFromApi) {
 setPrevWildcardFromApi(hasWildcardFromApi);
 }

 // Whether the component is in "create" mode (no target ID yet — selections are local-only)
 const isCreateMode = !userId && !roleId;

 // Toggle wildcard (all nodes)
 const toggleWildcard = async () => {
 if (disabled) return;

 // Optimistic UI update - update state immediately
 if (hasWildcard) {
 // Remove wildcard from local state immediately
 const newSelection = selectedNodes.filter(n => !n.isWildcard && n.nodeId !== null);
 onSelectionChange(newSelection);
 } else {
 // Clear all specific nodes and add wildcard immediately
 const wildcardNode: NodeAssignmentWithExpiration = {
 nodeId: null,
 nodeName: 'All Nodes (*)',
 isWildcard: true,
 source: userId ? 'user' : undefined,
 };
 onSelectionChange([wildcardNode]);
 }

 if (isCreateMode) return; // No API call in create mode

 const targetType = userId ? 'user' : 'role';
 const targetId = userId || roleId;

 try {
 if (hasWildcard) {
 // Remove wildcard assignment
 await nodesApi.removeWildcard(targetType, targetId!);
 notifySuccess('Wildcard assignment removed');
 } else {
 // Add wildcard assignment - this will remove all specific node assignments
 await nodesApi.assignWildcard({
 targetType,
 targetId: targetId!,
 });
 notifySuccess('All nodes assigned (wildcard)');
 }
 // Invalidate queries after successful API call
 Promise.all([
 queryClient.invalidateQueries({ queryKey: qk.roleNodes(roleId!) }),
 queryClient.invalidateQueries({ queryKey: qk.userNodes(userId!) }),
 queryClient.invalidateQueries({ queryKey: qk.nodes() }),
 ]);
 } catch (error: unknown) {
 reportSystemError({
 level: 'error',
 component: 'NodeAssignmentsSelector',
 message: error instanceof Error ? error.message : String(error),
 stack: error instanceof Error ? error.stack : undefined,
 metadata: { context: 'update wildcard assignment' },
 });
 // Revert on error
 notifyError(getErrorMessage(error, 'Failed to update wildcard assignment'));
 // Revert the optimistic update
 if (hasWildcard) {
 // We tried to remove but failed - add it back
 const wildcardNode: NodeAssignmentWithExpiration = {
 nodeId: null,
 nodeName: 'All Nodes (*)',
 isWildcard: true,
 source: userId ? 'user' : undefined,
 };
 onSelectionChange([...selectedNodes, wildcardNode]);
 } else {
 // We tried to add but failed - restore previous selection
 queryClient.invalidateQueries({ queryKey: qk.roleNodes(roleId!) });
 queryClient.invalidateQueries({ queryKey: qk.userNodes(userId!) });
 }
 }
 };

 // Toggle node selection
 const toggleNode = async (nodeId: string, nodeName: string) => {
 if (disabled || hasWildcard) return; // Don't allow individual node selection when wildcard is active

 const existingIndex = selectedNodes.findIndex(n => n.nodeId === nodeId);
 const previousSelection = [...selectedNodes];

 // Optimistic UI update
 const newSelection = [...selectedNodes];
 if (existingIndex >= 0) {
 // Remove node
 newSelection.splice(existingIndex, 1);
 } else {
 // Add node (without expiration initially, user can set it)
 newSelection.push({ nodeId, nodeName, source: userId ? 'user' : undefined });
 }
 onSelectionChange(newSelection);

 try {
 if (existingIndex >= 0) {
 // Remove from server
 await removeNodeAssignment(nodeId);
 } else {
 // Add to server
 await addNodeAssignment(nodeId);
 }
 } catch (_error: unknown) {
 reportSystemError({
 level: 'error',
 component: 'NodeAssignmentsSelector',
 message: _error instanceof Error ? _error.message : String(_error),
 stack: _error instanceof Error ? _error.stack : undefined,
 metadata: { context: 'toggle node' },
 });
 // Revert on error
 onSelectionChange(previousSelection);
 }
 };

 // Add node assignment to server
 const addNodeAssignment = async (nodeId: string) => {
 if (isCreateMode) return true;
 try {
 const targetType = userId ? 'user' : 'role';
 const targetId = userId || roleId;

 await nodesApi.assignNode(nodeId, {
 targetType,
 targetId: targetId!,
 });

 notifySuccess('Node assigned');
 Promise.all([
 queryClient.invalidateQueries({ queryKey: qk.roleNodes(roleId!) }),
 queryClient.invalidateQueries({ queryKey: qk.userNodes(userId!) }),
 queryClient.invalidateQueries({ queryKey: qk.nodes() }),
 ]);
 return true;
 } catch (error: unknown) {
 reportSystemError({
 level: 'error',
 component: 'NodeAssignmentsSelector',
 message: error instanceof Error ? error.message : String(error),
 stack: error instanceof Error ? error.stack : undefined,
 metadata: { context: 'assign node' },
 });
 notifyError(getErrorMessage(error, 'Failed to assign node'));
 return false;
 }
 };

 // Remove node assignment from server
 const removeNodeAssignment = async (nodeId: string) => {
 if (isCreateMode) return true;
 try {
 const nodeAssignments = await nodesApi.getAssignments(nodeId);
 const targetId = userId || roleId;
 const targetType = userId ? 'user' : 'role';

 const assignment = nodeAssignments.find(a =>
 targetType === 'user' ? a.userId === targetId : a.roleId === targetId
 );

 if (assignment) {
 await nodesApi.removeAssignment(nodeId, assignment.id);
 notifySuccess('Node unassigned');
 Promise.all([
 queryClient.invalidateQueries({ queryKey: qk.roleNodes(roleId!) }),
 queryClient.invalidateQueries({ queryKey: qk.userNodes(userId!) }),
 queryClient.invalidateQueries({ queryKey: qk.nodes() }),
 ]);
 return true;
 }
 return false;
 } catch (error: unknown) {
 reportSystemError({
 level: 'error',
 component: 'NodeAssignmentsSelector',
 message: error instanceof Error ? error.message : String(error),
 stack: error instanceof Error ? error.stack : undefined,
 metadata: { context: 'unassign node' },
 });
 notifyError(getErrorMessage(error, 'Failed to unassign node'));
 return false;
 }
 };

 // Update expiration date for a node
 const updateExpiration = async (nodeId: string, expiresAt: string) => {
 if (disabled || isCreateMode) return;

 // Remove old assignment and create new one with expiration
 const targetId = userId || roleId;
 const targetType = userId ? 'user' : 'role';

 try {
 // First remove old assignment
 const nodeAssignments = await nodesApi.getAssignments(nodeId);
 const assignment = nodeAssignments.find(a =>
 targetType === 'user' ? a.userId === targetId : a.roleId === targetId
 );

 if (assignment) {
 await nodesApi.removeAssignment(nodeId, assignment.id);
 }

 // Create new assignment with expiration
 await nodesApi.assignNode(nodeId, {
 targetType,
 targetId: targetId!,
 expiresAt: expiresAt || undefined,
 });

 // Update local state
 const newSelection = selectedNodes.map(n =>
 n.nodeId === nodeId ? { ...n, expiresAt: expiresAt || undefined } : n
 );
 onSelectionChange(newSelection);

 setExpirationNodeId(null);
 setExpirationDate('');
 notifySuccess('Expiration updated');
 Promise.all([
 queryClient.invalidateQueries({ queryKey: qk.roleNodes(roleId!) }),
 queryClient.invalidateQueries({ queryKey: qk.userNodes(userId!) }),
 queryClient.invalidateQueries({ queryKey: qk.nodes() }),
 ]);
 } catch (error: unknown) {
 reportSystemError({
 level: 'error',
 component: 'NodeAssignmentsSelector',
 message: error instanceof Error ? error.message : String(error),
 stack: error instanceof Error ? error.stack : undefined,
 metadata: { context: 'update expiration' },
 });
 notifyError(getErrorMessage(error, 'Failed to update expiration'));
 }
 };

 // Filter nodes by search (memoized for performance)
 const filteredNodes = useMemo(() =>
 nodes.filter(node =>
 node.name.toLowerCase().includes(search.toLowerCase()) ||
 node.location?.name.toLowerCase().includes(search.toLowerCase())
 ), [nodes, search]
 );

 // Separate inherited (for users) and direct assignments (memoized)
 const directAssignments = useMemo(() =>
 selectedNodes.filter(n => n.source === 'user' || !n.source),
 [selectedNodes]
 );
 const inheritedAssignments = useMemo(() =>
 selectedNodes.filter(n => n.source === 'role'),
 [selectedNodes]
 );

 const isLoading = nodesLoading || roleAssignmentsLoading || userAssignmentsLoading;

 return (
 <div className="rounded-xl border border-border bg-surface-2 p-4 dark:border-border dark:bg-surface-1/60">
 <div className="flex items-center justify-between mb-3">
 <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground dark:text-muted-foreground">
 {label} ({selectedNodes.length})
 </div>
 <input
 type="text"
 value={search}
 onChange={(e) => setSearch(e.target.value)}
 placeholder="Search nodes..."
 className="w-48 rounded-lg border border-border bg-card px-2 py-1 text-xs text-foreground transition-all duration-300 focus:border-primary focus:outline-none hover:border-primary dark:border-border dark:bg-surface-1 dark:text-foreground"
 />
 </div>

 {isLoading ? (
 <div className="py-4 text-center text-sm text-muted-foreground dark:text-muted-foreground">
 Loading nodes...
 </div>
 ) : (
 <>
 {/* Selected nodes */}
 {selectedNodes.length > 0 && (
 <div className="mb-3 space-y-2">
 {inheritedAssignments.length > 0 && (
 <div className="text-xs text-muted-foreground dark:text-muted-foreground mb-1">
 Inherited from roles
 </div>
 )}
 {inheritedAssignments.map(node => (
 <div
 key={node.nodeId || 'wildcard'}
 className="flex items-center justify-between rounded-md border border-purple-200 bg-purple-50 px-2 py-1.5 dark:border-purple-500/30 dark:bg-purple-500/10"
 >
 <div className="flex items-center gap-2">
 <svg className="h-4 w-4 text-purple-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
 </svg>
 <span className="text-xs font-medium text-foreground">{node.nodeName}</span>
 {node.roleName && (
 <span className="text-[10px] text-purple-600 dark:text-purple-400">
 via {node.roleName}
 </span>
 )}
 </div>
 <span className="text-[10px] text-muted-foreground dark:text-muted-foreground">
 {node.expiresAt ? `Expires: ${new Date(node.expiresAt).toLocaleDateString()}` : 'No expiration'}
 </span>
 </div>
 ))}
 {directAssignments.filter(n => !n.isWildcard).map(node => (
 <div
 key={node.nodeId}
 className="flex items-center justify-between rounded-md border border-border bg-card px-2 py-1.5 dark:border-border dark:bg-surface-0"
 >
 <div className="flex items-center gap-2">
 <span className="text-xs font-medium text-foreground">{node.nodeName}</span>
 {node.expiresAt && (
 <span className="text-[10px] text-muted-foreground dark:text-muted-foreground">
 Expires: {new Date(node.expiresAt).toLocaleDateString()}
 </span>
 )}
 </div>
 {!disabled && (
 <div className="flex items-center gap-1">
 <button
 onClick={() => {
 setExpirationNodeId(node.nodeId!);
 setExpirationDate(node.expiresAt || '');
 }}
 className="rounded px-1.5 py-0.5 text-[10px] text-muted-foreground transition-colors hover:bg-surface-2 hover:text-foreground dark:hover:bg-surface-2 dark:hover:text-foreground"
 >
 Set Expiration
 </button>
 <button
 onClick={() => toggleNode(node.nodeId!, node.nodeName)}
 className="rounded p-0.5 text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive dark:hover:bg-destructive/20 dark:hover:text-destructive"
 >
 <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
 </svg>
 </button>
 </div>
 )}
 </div>
 ))}
 {/* Wildcard assignment badge */}
 {directAssignments.some(n => n.isWildcard) && (
 <div className="flex items-center justify-between rounded-md border border-warning/20 bg-warning/5 px-3 py-2 dark:border-warning/30 dark:bg-warning/50/10">
 <div className="flex items-center gap-2">
 <svg className="h-4 w-4 text-warning" fill="none" viewBox="0 0 24 24" stroke="currentColor">
 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
 </svg>
 <div className="flex flex-col">
 <span className="text-xs font-semibold text-warning dark:text-warning">All Nodes (*)</span>
 <span className="text-[10px] text-warning dark:text-warning">Access to all current and future nodes</span>
 </div>
 </div>
 {!disabled && (
 <button
 onClick={() => toggleWildcard()}
 className="rounded px-2 py-1 text-[10px] text-warning transition-colors hover:bg-warning/10 hover:text-warning dark:text-warning dark:hover:bg-warning/20"
 >
 Remove
 </button>
 )}
 </div>
 )}
 </div>
 )}

 {/* Wildcard option at the top of available nodes */}
 <div className="mb-2">
 <label
 className={`flex items-center gap-2 rounded-md border px-2 py-2 text-xs transition-all cursor-pointer ${
 hasWildcard
 ? 'border-warning/20 bg-warning/5 dark:border-warning/30 dark:bg-warning/50/10'
 : 'border-border bg-card hover:border-warning hover:bg-warning/5/50 dark:border-border dark:bg-surface-0 dark:hover:border-warning/30 dark:hover:bg-warning/50/5'
 }`}
 >
 <input
 type="checkbox"
 checked={hasWildcard}
 disabled={disabled}
 onChange={() => toggleWildcard()}
 className="h-4 w-4 rounded border-border bg-card text-warning focus:ring-2 focus:ring-warning dark:border-border dark:bg-surface-1 dark:text-warning disabled:opacity-50"
 />
 <div className="flex flex-col">
 <span className="font-semibold text-foreground">All Nodes (*)</span>
 <span className="text-[10px] text-muted-foreground dark:text-muted-foreground">Access to all current and future nodes</span>
 </div>
 </label>
 {hasWildcard && (
 <div className="mt-1 text-[10px] text-warning dark:text-warning px-2">
 Individual node selection is disabled when wildcard is active
 </div>
 )}
 </div>

 {/* Available nodes header */}
 {!hasWildcard && (
 <div className="text-xs text-muted-foreground dark:text-muted-foreground mb-1 px-1">
 Select individual nodes
 </div>
 )}

 {/* Available nodes */}
 <div className={`max-h-36 overflow-y-auto pr-1 ${hasWildcard ? 'opacity-50 pointer-events-none' : ''}`}>
 {filteredNodes.length === 0 ? (
 <div className="py-2 text-center text-xs text-muted-foreground dark:text-muted-foreground">
 No nodes found
 </div>
 ) : (
 filteredNodes.map((node) => {
 const isSelected = selectedNodes.some(n => n.nodeId === node.id);
 const isInherited = inheritedAssignments.some(n => n.nodeId === node.id);

 return (
 <label
 key={node.id}
 className={`flex items-center gap-2 rounded-md border px-2 py-1.5 text-xs transition-all ${
 isSelected && isInherited
 ? 'border-purple-200 bg-purple-50 dark:border-purple-500/30 dark:bg-purple-500/10 cursor-default'
 : isSelected
 ? 'border-primary-200 bg-primary-50 dark:border-primary/30 dark:bg-primary-500/10 cursor-pointer'
 : 'border-border bg-card hover:border-primary hover:bg-surface-2 dark:border-border dark:bg-surface-0 dark:hover:border-primary/30 dark:hover:bg-surface-1 cursor-pointer'
 }`}
 >
 {isInherited ? (
 <svg className="h-4 w-4 text-purple-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
 </svg>
 ) : (
 <input
 type="checkbox"
 checked={isSelected}
 disabled={disabled || isInherited}
 onChange={() => toggleNode(node.id, node.name)}
 className="h-4 w-4 rounded border-border bg-card text-primary-600 focus:ring-2 focus:ring-primary dark:border-border dark:bg-surface-1 dark:text-primary-400 disabled:opacity-50"
 />
 )}
 <span className="flex-1 font-medium text-foreground">{node.name}</span>
 <span className="text-[10px] text-muted-foreground dark:text-muted-foreground">{node.location?.name}</span>
 </label>
 );
 })
 )}
 </div>

 {/* Expiration date modal */}
 {expirationNodeId && (
 <ModalPortal>
 <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/60 px-4 backdrop-blur-sm">
 <div className="w-full max-w-sm rounded-xl border border-border bg-card p-4 shadow-surface-light dark:shadow-surface-dark dark:border-border dark:bg-surface-1">
 <h3 className="text-sm font-semibold text-foreground mb-3">
 Set Expiration for {nodes.find(n => n.id === expirationNodeId)?.name}
 </h3>
 <input
 type="datetime-local"
 value={expirationDate}
 onChange={(e) => setExpirationDate(e.target.value)}
 min={new Date().toISOString().slice(0, 16)}
 className="w-full rounded-lg border border-border bg-card px-3 py-2 text-sm text-foreground transition-all duration-300 focus:border-primary focus:outline-none hover:border-primary dark:border-border dark:bg-surface-1 dark:text-foreground dark:hover:border-primary/30"
 />
 <div className="mt-4 flex justify-end gap-2">
 <button
 onClick={() => updateExpiration(expirationNodeId, expirationDate)}
 className="rounded-md bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground transition-all duration-300 hover:bg-primary/90"
 >
 Save
 </button>
 <button
 onClick={() => {
 setExpirationNodeId(null);
 setExpirationDate('');
 }}
 className="rounded-md border border-border px-3 py-1.5 text-xs font-semibold text-muted-foreground transition-all duration-300 hover:border-primary hover:text-foreground dark:border-border dark:text-foreground dark:hover:border-primary/30"
 >
 Cancel
 </button>
 </div>
 </div>
 </div>
 </ModalPortal>
 )}
 </>
 )}
 </div>
 );
}
