import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Download, Loader2, Server, X } from 'lucide-react';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { nodesApi } from '../../services/api/nodes';
import { templatesApi } from '../../services/api/templates';
import { adminApi } from '../../services/api/admin';
import { qk } from '../../lib/queryKeys';
import { notifyError, notifySuccess } from '../../utils/notify';
import { ModalPortal } from '@/components/ui/modal-portal';
import Combobox from '@/components/ui/combobox';

export interface UnregisteredContainer {
 containerId: string;
 image: string;
 status: string;
 labels: Record<string, string>;
 networkMode?: string;
 memoryLimitMb?: number;
 cpuCores?: number;
 startupCommand?: string;
 envVarNames?: string[];
 discoveredAt: number;
}

interface ServerImportModalProps {
 open: boolean;
 onClose: () => void;
 nodeId: string;
 containers: UnregisteredContainer[];
}

export default function ServerImportModal({
 open,
 onClose,
 nodeId,
 containers,
}: ServerImportModalProps) {
 const queryClient = useQueryClient();
 const [importingId, setImportingId] = useState<string | null>(null);
 const [formState, setFormState] = useState<Record<string, {
 name: string;
 templateId: string;
 ownerId: string;
 allocatedMemoryMb: string;
 allocatedCpuCores: string;
 allocatedDiskMb: string;
 primaryPort: string;
 }>>({});

 // Template suggestions fetched from backend matching
 const [suggestions, setSuggestions] = useState<Record<string, Array<{
 templateId: string;
 templateName: string;
 score: number;
 matchReasons: string[];
 }>>>({});

 // Fetch templates for dropdown
 const { data: templates = [] } = useQuery({
 queryKey: qk.templates(),
 queryFn: () => templatesApi.list(),
 enabled: open,
 staleTime: 5 * 60 * 1000,
 });

 // Fetch users for owner dropdown
 const { data: usersData } = useQuery({
 queryKey: qk.adminUsers(),
 queryFn: () => adminApi.listUsers(),
 enabled: open,
 staleTime: 5 * 60 * 1000,
 });
 const users = usersData?.users ?? [];

 const templateOptions = templates.map((t: any) => ({
 value: t.id,
 label: t.name,
 }));

 const userOptions = users.map((u: any) => ({
 value: u.id,
 label: u.email || u.name || u.id,
 }));

 const importMutation = useMutation({
 mutationFn: async (containerId: string) => {
 const form = formState[containerId];
 if (!form?.name || !form?.templateId || !form?.ownerId) {
 throw new Error('Name, template, and owner are required');
 }
 return nodesApi.importServer(nodeId, {
 containerId,
 name: form.name,
 templateId: form.templateId,
 ownerId: form.ownerId,
 allocatedMemoryMb: form.allocatedMemoryMb ? Number(form.allocatedMemoryMb) : undefined,
 allocatedCpuCores: form.allocatedCpuCores ? Number(form.allocatedCpuCores) : undefined,
 allocatedDiskMb: form.allocatedDiskMb ? Number(form.allocatedDiskMb) : undefined,
 primaryPort: form.primaryPort ? Number(form.primaryPort) : undefined,
 });
 },
 onSuccess: () => {
 notifySuccess('Server imported successfully');
 setImportingId(null);
 setFormState((prev) => {
 const next = { ...prev };
 delete next[importingId!];
 return next;
 });
 },
 onSettled: () => {
 queryClient.invalidateQueries({ queryKey: qk.node(nodeId) });
 queryClient.invalidateQueries({ queryKey: qk.nodeStats(nodeId) });
 queryClient.invalidateQueries({ queryKey: qk.unregisteredContainers(nodeId) });
 queryClient.invalidateQueries({ queryKey: qk.servers() });
 queryClient.invalidateQueries({ queryKey: qk.adminServers() });
 },
 onError: (error: any) => {
 const message = error?.response?.data?.error || error?.message || 'Failed to import server';
 notifyError(message);
 setImportingId(null);
 },
 });

 if (!open) return null;

 const fetchSuggestions = async (containerId: string) => {
 try {
 const results = await nodesApi.suggestTemplate(nodeId, containerId);
 setSuggestions((prev) => ({ ...prev, [containerId]: results }));
 // Auto-select top suggestion if no template selected yet
 const form = getForm(containerId);
 if (!form.templateId && results.length > 0) {
 updateForm(containerId, { templateId: results[0].templateId });
 }
 } catch {
 // Silently fail — suggestions are optional
 }
 };

 const getForm = (containerId: string) => {
 const container = containers.find((c) => c.containerId === containerId);
 return (
 formState[containerId] ?? {
 name: '',
 templateId: '',
 ownerId: '',
 allocatedMemoryMb: container?.memoryLimitMb?.toString() ?? '',
 allocatedCpuCores: container?.cpuCores?.toString() ?? '',
 allocatedDiskMb: '10240',
 primaryPort: '25565',
 }
 );
 };

 const updateForm = (containerId: string, updates: Record<string, string>) => {
 setFormState((prev) => ({
 ...prev,
 [containerId]: { ...getForm(containerId), ...updates },
 }));
 };

 return (
 <ModalPortal>
 <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/60 px-4 backdrop-blur-sm">
 <div className="w-full max-w-3xl rounded-xl border border-warning/30 bg-card shadow-xl">
 <div className="flex items-center justify-between border-b border-warning/30 bg-warning/5 px-6 py-4">
 <div className="flex items-center gap-2">
 <Download className="h-5 w-5 text-warning" />
 <h2 className="text-lg font-semibold text-foreground">
 Import Discovered Servers
 </h2>
 </div>
 <button
 className="rounded-md border border-border/40 px-2 py-1 text-xs text-muted-foreground transition-colors hover:border-primary/50 hover:text-foreground"
 onClick={onClose}
 >
 Close
 </button>
 </div>

 <div className="max-h-[70vh] overflow-y-auto px-6 py-4">
 <div className="mb-4 text-sm text-muted-foreground">
 {containers.length} container(s) found on this node that are not registered as servers.
 Select a container and fill in the required details to import it.
 </div>

 {containers.length === 0 ? (
 <div className="py-8 text-center text-sm text-muted-foreground">
 No unregistered containers found.
 </div>
 ) : (
 <div className="space-y-3">
 {containers.map((container) => {
 const isExpanded = importingId === container.containerId;
 const form = getForm(container.containerId);

 return (
 <div
 key={container.containerId}
 className="rounded-lg border border-border/30 bg-surface-2/30 p-4"
 >
 <div className="flex items-center justify-between">
 <div className="flex min-w-0 flex-1 items-center gap-3">
 <Server className="h-4 w-4 shrink-0 text-muted-foreground" />
 <div className="min-w-0 overflow-hidden">
 <div className="text-sm font-mono font-medium text-foreground">
 {container.containerId}
 </div>
 <div className="flex items-center gap-2 text-xs text-muted-foreground">
 <span>{container.image || 'Unknown image'}</span>
 <Badge
 variant={
 container.status.includes('Up')
 ? 'success'
 : 'secondary'
 }
 className="text-[10px]"
 >
 {container.status.includes('Up') ? 'Running' : 'Stopped'}
 </Badge>
 {container.networkMode && (
 <Badge
 variant={container.networkMode === 'host' ? 'warning' : 'outline'}
 className="text-[10px]"
 >
 {container.networkMode === 'host' ? 'Host Network' : 'Bridge'}
 </Badge>
 )}
 </div>
 {container.startupCommand && (
 <div className="mt-1 truncate font-mono text-[10px] text-muted-foreground/60" title={container.startupCommand}>
 {container.startupCommand.length > 120 ? container.startupCommand.slice(0, 120) + '…' : container.startupCommand}
 </div>
 )}
 {container.envVarNames && container.envVarNames.length > 0 && (
 <div className="mt-1 flex flex-wrap gap-1">
 {container.envVarNames.slice(0, 8).map((name) => (
 <span key={name} className="rounded bg-surface-2/50 px-1 py-0.5 text-[9px] text-muted-foreground">
 {name}
 </span>
 ))}
 {container.envVarNames.length > 8 && (
 <span className="text-[9px] text-muted-foreground">+{container.envVarNames.length - 8} more</span>
 )}
 </div>
 )}
 </div>
 </div>
 <Button
 size="sm"
 variant={isExpanded ? 'outline' : 'default'}
 onClick={() => {
 if (isExpanded) {
 setImportingId(null);
 } else {
 setImportingId(container.containerId);
 fetchSuggestions(container.containerId);
 }
 }}
 className="gap-1.5"
 >
 {isExpanded ? (
 <>
 <X className="h-3 w-3" />
 Cancel
 </>
 ) : (
 <>
 <Download className="h-3 w-3" />
 Import
 </>
 )}
 </Button>
 </div>

 {isExpanded && (
 <div className="mt-4 space-y-3 border-t border-border/30 pt-4">
 <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
 <div>
 <label className="mb-1 block text-xs font-medium text-muted-foreground">
 Server Name *
 </label>
 <input
 type="text"
 value={form.name}
 onChange={(e) =>
 updateForm(container.containerId, { name: e.target.value })
 }
 placeholder="My Server"
 className="w-full rounded-md border border-border/40 bg-card px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none"
 />
 </div>
 <div>
 <label className="mb-1 block text-xs font-medium text-muted-foreground">
 Template *
 </label>
 <Combobox
 options={templateOptions}
 value={form.templateId}
 onChange={(val: string) =>
 updateForm(container.containerId, { templateId: val })
 }
 placeholder="Select template..."
 />
 {suggestions[container.containerId] && suggestions[container.containerId].length > 0 && (
 <div className="mt-1 flex flex-wrap items-center gap-1">
 <span className="text-[10px] text-muted-foreground">Suggested:</span>
 {suggestions[container.containerId].slice(0, 3).map((s) => (
 <button
 key={s.templateId}
 type="button"
 onClick={() => updateForm(container.containerId, { templateId: s.templateId })}
 className={`rounded px-1.5 py-0.5 text-[10px] transition-colors ${
 form.templateId === s.templateId
 ? 'bg-primary/20 text-primary font-medium'
 : 'bg-surface-2/50 text-muted-foreground hover:bg-primary/10'
 }`}
 title={s.matchReasons.join('; ')}
 >
 {s.templateName} ({s.score})
 </button>
 ))}
 </div>
 )}
 </div>
 <div>
 <label className="mb-1 block text-xs font-medium text-muted-foreground">
 Owner *
 </label>
 <Combobox
 options={userOptions}
 value={form.ownerId}
 onChange={(val: string) =>
 updateForm(container.containerId, { ownerId: val })
 }
 placeholder="Select owner..."
 />
 </div>
 <div>
 <label className="mb-1 block text-xs font-medium text-muted-foreground">
 Primary Port
 </label>
 <input
 type="number"
 value={form.primaryPort}
 onChange={(e) =>
 updateForm(container.containerId, { primaryPort: e.target.value })
 }
 className="w-full rounded-md border border-border/40 bg-card px-3 py-2 text-sm text-foreground focus:border-primary focus:outline-none"
 />
 </div>
 <div>
 <label className="mb-1 block text-xs font-medium text-muted-foreground">
 Memory (MB)
 </label>
 <input
 type="number"
 value={form.allocatedMemoryMb}
 onChange={(e) =>
 updateForm(container.containerId, {
 allocatedMemoryMb: e.target.value,
 })
 }
 placeholder="1024"
 className="w-full rounded-md border border-border/40 bg-card px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none"
 />
 </div>
 <div>
 <label className="mb-1 block text-xs font-medium text-muted-foreground">
 CPU Cores
 </label>
 <input
 type="number"
 value={form.allocatedCpuCores}
 onChange={(e) =>
 updateForm(container.containerId, {
 allocatedCpuCores: e.target.value,
 })
 }
 placeholder="1"
 className="w-full rounded-md border border-border/40 bg-card px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none"
 />
 </div>
 </div>

 <div className="flex justify-end gap-2 pt-2">
 <Button
 size="sm"
 variant="outline"
 onClick={() => setImportingId(null)}
 >
 Cancel
 </Button>
 <Button
 size="sm"
 onClick={() => importMutation.mutate(container.containerId)}
 disabled={
 !form.name || !form.templateId || !form.ownerId || importMutation.isPending
 }
 className="gap-1.5"
 >
 {importMutation.isPending ? (
 <Loader2 className="h-3 w-3 animate-spin" />
 ) : (
 <Download className="h-3 w-3" />
 )}
 Import Server
 </Button>
 </div>
 </div>
 )}
 </div>
 );
 })}
 </div>
 )}
 </div>
 </div>
 </div>
 </ModalPortal>
 );
}
