import { useMemo, useRef, useState } from 'react';
import type { ChangeEvent } from 'react';
import { Link } from 'react-router-dom';
import { useMutation, useQuery } from '@tanstack/react-query';
import {
 Select,
 SelectContent,
 SelectItem,
 SelectTrigger,
 SelectValue,
} from '../../components/ui/select';
import { qk } from '@/lib/queryKeys';
import { queryClient } from '@/lib/queryClient';
import type { Template, TemplateImageOption, TemplateVariable } from '../../types/template';
import { templatesApi } from '../../services/api/templates';
import { nestsApi } from '../../services/api/nests';
import { notifyError, notifySuccess } from '../../utils/notify';
import { normalizeTemplateImport, parseEggContent } from '../../utils/pterodactylImport';
import TemplateProviderEditor, { extractProviderIds } from './TemplateProviderEditor';
import { ModalPortal } from '@/components/ui/modal-portal';
import { reportSystemError } from '../../services/api/systemErrors';

type VariableDraft = {
 name: string;
 description: string;
 defaultValue: string;
 required: boolean;
 input: TemplateVariable['input'];
 rules: string;
};

const createVariableDraft = (variable?: TemplateVariable): VariableDraft => ({
 name: variable?.name ?? '',
 description: variable?.description ?? '',
 defaultValue: variable?.default ?? '',
 required: Boolean(variable?.required),
 input: variable?.input ?? 'text',
 rules: variable?.rules?.join('; ') ?? '',
});

type EditProps = {
 template: Template;
 open?: boolean;
 onOpenChange?: (open: boolean) => void;
 /** ID of a newly-created nest to auto-select (passed from parent after return-from-nests flow) */
 createdNestId?: string | null;
};

function TemplateEditModal({ template, open: controlledOpen, onOpenChange, createdNestId }: EditProps) {
 const [internalOpen, setInternalOpen] = useState(false);
 const open = controlledOpen !== undefined ? controlledOpen : internalOpen;
 const setOpen = (value: boolean) => {
 setInternalOpen(value);
 onOpenChange?.(value);
 };
 const importFileRef = useRef<HTMLInputElement | null>(null);
 const [name, setName] = useState(template.name);
 const [description, setDescription] = useState(template.description ?? '');
 const [author, setAuthor] = useState(template.author);
 const [version, setVersion] = useState(template.version);
 const [image, setImage] = useState(template.image);
 const [installImage, setInstallImage] = useState(template.installImage ?? '');
 const [imageOptions, setImageOptions] = useState<TemplateImageOption[]>(template.images ?? []);
 const [defaultImage, setDefaultImage] = useState(template.defaultImage ?? '');
 const [startup, setStartup] = useState(template.startup);
 const [stopCommand, setStopCommand] = useState(template.stopCommand);
 const [sendSignalTo, setSendSignalTo] = useState<'SIGTERM' | 'SIGINT' | 'SIGKILL'>(
 template.sendSignalTo === 'SIGKILL'
 ? 'SIGKILL'
 : template.sendSignalTo === 'SIGINT'
 ? 'SIGINT'
 : 'SIGTERM',
 );
 const [installScript, setInstallScript] = useState(template.installScript ?? '');
 const [configFile, setConfigFile] = useState(template.features?.configFile ?? '');
 const [configFiles, setConfigFiles] = useState<string[]>(template.features?.configFiles ?? []);
 const [supportedPorts, setSupportedPorts] = useState(
 template.supportedPorts?.length ? template.supportedPorts.join(', ') : '25565',
 );
 const [allocatedMemoryMb, setAllocatedMemoryMb] = useState(String(template.allocatedMemoryMb));
 const [allocatedCpuCores, setAllocatedCpuCores] = useState(String(template.allocatedCpuCores));
 const [iconUrl, setIconUrl] = useState(template.features?.iconUrl ?? '');
 const [restartOnExit, setRestartOnExit] = useState(template.features?.restartOnExit ?? false);
 const [maxInstances, setMaxInstances] = useState(String(template.features?.maxInstances ?? ''));
 const [backupPaths, setBackupPaths] = useState(template.features?.backupPaths?.join(', ') ?? '');
 const [fileEditorEnabled, setFileEditorEnabled] = useState(
 template.features?.fileEditor?.enabled ?? true,
 );
 const [fileEditorRestrictedPaths, setFileEditorRestrictedPaths] = useState(
 template.features?.fileEditor?.restrictedPaths?.join(', ') ?? '',
 );
 const [templateFeatures, setTemplateFeatures] = useState<Record<string, any>>(
 template.features ?? {},
 );
 const [variables, setVariables] = useState<VariableDraft[]>(
 template.variables?.length
 ? template.variables.map((variable) => createVariableDraft(variable))
 : [createVariableDraft()],
 );
 const [importError, setImportError] = useState('');
 const [modManagerEnabled, setModManagerEnabled] = useState(!!template.features?.modManager);
 const [modProviders, setModProviders] = useState<string[]>(
 extractProviderIds(template.features?.modManager?.providers),
 );
 const [pluginManagerEnabled, setPluginManagerEnabled] = useState(
 !!template.features?.pluginManager,
 );
 const [pluginProviders, setPluginProviders] = useState<string[]>(
 extractProviderIds(template.features?.pluginManager?.providers),
 );
 const [nestId, setNestId] = useState(template.nestId || '');
 // Auto-select a newly created nest when returning from the nests manager.
 // Use the"previous prop" pattern to sync state without an effect.
 const [prevCreatedNestId, setPrevCreatedNestId] = useState<string | null | undefined>(undefined);
 if (createdNestId !== prevCreatedNestId && createdNestId) {
 setPrevCreatedNestId(createdNestId);
 setNestId(createdNestId);
 } else if (createdNestId !== prevCreatedNestId) {
 setPrevCreatedNestId(createdNestId);
 }

 const { data: nests = [] } = useQuery({
 queryKey: qk.nests(),
 queryFn: nestsApi.list,
 staleTime: 5 * 60 * 1000,
 });

 const parsedPorts = useMemo(
 () =>
 supportedPorts
 .split(',')
 .map((entry) => Number(entry.trim()))
 .filter((value) => Number.isFinite(value) && value > 0),
 [supportedPorts],
 );

 const buildVariables = () =>
 variables
 .filter((variable) => variable.name.trim())
 .map((variable) => ({
 name: variable.name.trim(),
 description: variable.description.trim() || undefined,
 default: variable.defaultValue,
 required: variable.required,
 input: variable.input,
 rules: variable.rules
 .split(';')
 .map((rule) => rule.trim())
 .filter(Boolean),
 }));

 const resetFromTemplate = () => {
 setImportError('');
 setName(template.name);
 setDescription(template.description ?? '');
 setAuthor(template.author);
 setVersion(template.version);
 setImage(template.image);
 setInstallImage(template.installImage ?? '');
 setImageOptions(template.images ?? []);
 setDefaultImage(template.defaultImage ?? '');
 setStartup(template.startup);
 setStopCommand(template.stopCommand);
 setSendSignalTo(
 template.sendSignalTo === 'SIGKILL'
 ? 'SIGKILL'
 : template.sendSignalTo === 'SIGINT'
 ? 'SIGINT'
 : 'SIGTERM',
 );
 setInstallScript(template.installScript ?? '');
 setConfigFile(template.features?.configFile ?? '');
 setConfigFiles(
 template.features?.configFiles ??
 (template.features?.configFile ? [template.features.configFile] : []),
 );
 setSupportedPorts(
 template.supportedPorts?.length ? template.supportedPorts.join(', ') : '25565',
 );
 setAllocatedMemoryMb(String(template.allocatedMemoryMb));
 setAllocatedCpuCores(String(template.allocatedCpuCores));
 setIconUrl(template.features?.iconUrl ?? '');
 setRestartOnExit(template.features?.restartOnExit ?? false);
 setMaxInstances(String(template.features?.maxInstances ?? ''));
 setBackupPaths(template.features?.backupPaths?.join(', ') ?? '');
 setFileEditorEnabled(template.features?.fileEditor?.enabled ?? true);
 setFileEditorRestrictedPaths(template.features?.fileEditor?.restrictedPaths?.join(', ') ?? '');
 setTemplateFeatures(template.features ?? {});
 setModManagerEnabled(!!template.features?.modManager);
 setModProviders(extractProviderIds(template.features?.modManager?.providers));
 setPluginManagerEnabled(!!template.features?.pluginManager);
 setPluginProviders(extractProviderIds(template.features?.pluginManager?.providers));
 setNestId(template.nestId || '');
 setVariables(
 template.variables?.length
 ? template.variables.map((variable) => createVariableDraft(variable))
 : [createVariableDraft()],
 );
 };

 const applyTemplateImport = (raw: any) => {
 if (!raw || typeof raw !== 'object') {
 setImportError('Invalid template JSON');
 return;
 }
 const payload: any = normalizeTemplateImport(raw);
 setImportError('');
 setName(String(payload.name ?? ''));
 setDescription(String(payload.description ?? ''));
 setAuthor(String(payload.author ?? ''));
 setVersion(String(payload.version ?? ''));
 setImage(String(payload.image ?? ''));
 setImageOptions(
 Array.isArray(payload.images)
 ? payload.images.map((option: any) => ({
 name: String(option?.name ?? ''),
 label: option?.label ? String(option.label) : undefined,
 image: String(option?.image ?? ''),
 }))
 : [],
 );
 setDefaultImage(String(payload.defaultImage ?? ''));
 setInstallImage(String(payload.installImage ?? ''));
 setStartup(String(payload.startup ?? ''));
 setStopCommand(String(payload.stopCommand ?? ''));
 setSendSignalTo(
 payload.sendSignalTo === 'SIGKILL'
 ? 'SIGKILL'
 : payload.sendSignalTo === 'SIGINT'
 ? 'SIGINT'
 : 'SIGTERM',
 );
 setInstallScript(String(payload.installScript ?? ''));
 setConfigFile(String(payload.features?.configFile ?? ''));
 setConfigFiles(
 Array.isArray(payload.features?.configFiles)
 ? payload.features.configFiles
 : payload.features?.configFile
 ? [String(payload.features.configFile)]
 : [],
 );
 setSupportedPorts(
 Array.isArray(payload.supportedPorts) ? payload.supportedPorts.join(', ') : '25565',
 );
 setAllocatedMemoryMb(payload.allocatedMemoryMb ? String(payload.allocatedMemoryMb) : '1024');
 setAllocatedCpuCores(payload.allocatedCpuCores ? String(payload.allocatedCpuCores) : '2');
 setIconUrl(String(payload.features?.iconUrl ?? ''));
 setRestartOnExit(Boolean(payload.features?.restartOnExit));
 setMaxInstances(String(payload.features?.maxInstances ?? ''));
 setBackupPaths(
 Array.isArray(payload.features?.backupPaths) ? payload.features.backupPaths.join(', ') : '',
 );
 setFileEditorEnabled(payload.features?.fileEditor?.enabled !== false);
 setFileEditorRestrictedPaths(
 Array.isArray(payload.features?.fileEditor?.restrictedPaths)
 ? payload.features.fileEditor.restrictedPaths.join(', ')
 : '',
 );
 setTemplateFeatures(payload.features ?? {});
 setModManagerEnabled(!!payload.features?.modManager);
 setModProviders(extractProviderIds((payload.features?.modManager as any)?.providers));
 setPluginManagerEnabled(!!payload.features?.pluginManager);
 setPluginProviders(extractProviderIds((payload.features?.pluginManager as any)?.providers));
 const importedVariables = Array.isArray(payload.variables)
 ? payload.variables.map((variable: any) => ({
 name: String(variable?.name ?? ''),
 description: String(variable?.description ?? ''),
 defaultValue: String(variable?.default ?? ''),
 required: Boolean(variable?.required),
 input: variable?.input ?? 'text',
 rules: Array.isArray(variable?.rules) ? variable.rules.join('; ') : '',
 }))
 : [];
 setVariables(importedVariables.length ? importedVariables : [createVariableDraft()]);
 };

 const handleImportFile = (event: ChangeEvent<HTMLInputElement>) => {
 const file = event.target.files?.[0];
 if (!file) return;
 setImportError('');
 const reader = new FileReader();
 reader.onload = () => {
 try {
 const content = String(reader.result || '');
 const parsed = parseEggContent(content);
 if (!parsed) {
 setImportError('Failed to parse file (must be JSON or YAML)');
 return;
 }
 applyTemplateImport(parsed);
 } catch (error) {
 reportSystemError({
 level: 'error',
 component: 'TemplateEditModal',
 message: error instanceof Error ? error.message : String(error),
 stack: error instanceof Error ? error.stack : undefined,
 metadata: { context: 'parse import file' },
 });
 setImportError('Failed to parse file (must be JSON or YAML)');
 }
 };
 reader.onerror = () => {
 setImportError('Unable to read file');
 };
 reader.readAsText(file);
 event.target.value = '';
 };

 const mutation = useMutation({
 mutationFn: () =>
 templatesApi.update(template.id, {
 name,
 description: description || undefined,
 author,
 version,
 image,
 images: imageOptions.filter((option) => option.name && option.image),
 defaultImage: defaultImage || undefined,
 installImage: installImage || undefined,
 startup,
 stopCommand,
 sendSignalTo,
 variables: buildVariables(),
 installScript: installScript || undefined,
 features: {
 ...templateFeatures,
 iconUrl: iconUrl || undefined,
 ...(configFile ? { configFile } : {}),
 ...(configFiles.length ? { configFiles } : {}),
 ...(restartOnExit ? { restartOnExit } : {}),
 ...(maxInstances ? { maxInstances: Number(maxInstances) } : {}),
 ...(backupPaths
 ? {
 backupPaths: backupPaths
 .split(',')
 .map((p) => p.trim())
 .filter(Boolean),
 }
 : {}),
 ...(fileEditorEnabled
 ? {
 fileEditor: {
 enabled: fileEditorEnabled,
 ...(fileEditorRestrictedPaths
 ? {
 restrictedPaths: fileEditorRestrictedPaths
 .split(',')
 .map((p) => p.trim())
 .filter(Boolean),
 }
 : {}),
 },
 }
 : { fileEditor: { enabled: false } }),
 ...(modManagerEnabled && modProviders.length
 ? {
 modManager: {
 ...((templateFeatures?.modManager as any)?.targets
 ? { targets: (templateFeatures.modManager as any).targets }
 : {}),
 ...((templateFeatures?.modManager as any)?.paths
 ? { paths: (templateFeatures.modManager as any).paths }
 : {}),
 providers: modProviders,
 },
 }
 : {}),
 ...(pluginManagerEnabled && pluginProviders.length
 ? {
 pluginManager: {
 ...((templateFeatures?.pluginManager as any)?.paths
 ? { paths: (templateFeatures.pluginManager as any).paths }
 : {}),
 providers: pluginProviders,
 },
 }
 : {}),
 },
 nestId: nestId || null,
 }),
 onSuccess: () => {
 notifySuccess('Template updated');
 setOpen(false);
 },
 onError: (error: any) => {
 const message = error?.response?.data?.error || 'Failed to update template';
 notifyError(message);
 },
 onSettled: () => {
 queryClient.invalidateQueries({ queryKey: qk.templates() });
 queryClient.invalidateQueries({ queryKey: qk.template(template.id) });
 },
 });

 // Signal-based stops don't require a stop command
 const usingSignalStop = sendSignalTo === 'SIGINT' || sendSignalTo === 'SIGKILL';

 const disableSubmit =
 !name ||
 !author ||
 !version ||
 !image ||
 !startup ||
 (!stopCommand.trim() && !usingSignalStop) ||
 !parsedPorts.length ||
 !Number(allocatedMemoryMb) ||
 !Number(allocatedCpuCores) ||
 mutation.isPending;

 // Compute missing required fields for display
 const missingFields: string[] = useMemo(() => {
 const isSignalStop = sendSignalTo === 'SIGINT' || sendSignalTo === 'SIGKILL';
 const missing: string[] = [];
 if (!name) missing.push('Name');
 if (!author) missing.push('Author');
 if (!version) missing.push('Version');
 if (!image) missing.push('Container image');
 if (!startup) missing.push('Startup command');
 // Stop command is only required when NOT using signal-based stop
 if (!stopCommand.trim() && !isSignalStop) missing.push('Stop command');
 if (!parsedPorts.length) missing.push('Valid ports');
 if (!Number(allocatedMemoryMb)) missing.push('Allocated memory');
 if (!Number(allocatedCpuCores)) missing.push('Allocated CPU cores');
 return missing;
 }, [
 name,
 author,
 version,
 image,
 startup,
 stopCommand,
 sendSignalTo,
 parsedPorts.length,
 allocatedMemoryMb,
 allocatedCpuCores,
 ]);

 return (
 <>
 {controlledOpen === undefined && (
 <button
 className="rounded-md border border-border/40 bg-card px-3 py-1 text-xs font-semibold text-muted-foreground transition-colors hover:border-primary hover:text-foreground"
 onClick={() => {
 resetFromTemplate();
 setOpen(true);
 }}
 >
 Edit
 </button>
 )}
 {open ? (
 <ModalPortal>
 <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/60 px-4 py-10">
 <div className="flex w-full max-w-4xl max-h-[90vh] flex-col overflow-hidden rounded-2xl border border-border/40 bg-card shadow-sm transition-colors">
 <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-6 py-5">
 <div>
 <h2 className="text-lg font-semibold text-foreground">
 Edit template
 </h2>
 <p className="text-xs text-muted-foreground">
 Update images, resources, and startup configuration.
 </p>
 </div>
 <div className="flex flex-wrap items-center gap-2">
 <button
 className="rounded-full border border-border/40 px-3 py-1 text-xs font-semibold text-muted-foreground transition-colors hover:border-primary hover:text-foreground"
 onClick={() => importFileRef.current?.click()}
 >
 Import
 </button>
 <button
 className="rounded-full border border-border/40 px-3 py-1 text-xs font-semibold text-muted-foreground transition-colors hover:border-primary"
 onClick={() => setOpen(false)}
 >
 Close
 </button>
 <input
 ref={importFileRef}
 type="file"
 accept="application/json,.json,application/x-yaml,.yaml,.yml"
 onChange={handleImportFile}
 className="hidden"
 />
 </div>
 </div>
 <div className="space-y-6 overflow-y-auto px-6 py-5 text-sm text-muted-foreground">
 {importError ? (
 <p className="rounded-lg border border-destructive/20 bg-destructive/5 px-3 py-2 text-xs text-destructive">
 {importError}
 </p>
 ) : null}
 <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
 <label className="block space-y-1">
 <span className="text-muted-foreground">Name</span>
 <input
 className="w-full rounded-lg border border-border/40 bg-card px-3 py-2 text-foreground transition-colors focus:border-primary focus:outline-none hover:border-primary"
 value={name}
 onChange={(event) => setName(event.target.value)}
 />
 </label>
 <label className="block space-y-1">
 <span className="text-muted-foreground">Author</span>
 <input
 className="w-full rounded-lg border border-border/40 bg-card px-3 py-2 text-foreground transition-colors focus:border-primary focus:outline-none hover:border-primary"
 value={author}
 onChange={(event) => setAuthor(event.target.value)}
 />
 </label>
 <label className="block space-y-1">
 <span className="text-muted-foreground">
 Nest (optional)
 </span>
 <Select
 value={nestId || '__none__'}
 onValueChange={(v) => setNestId(v === '__none__' ? '' : v)}
 >
 <SelectTrigger>
 <SelectValue placeholder="None" />
 </SelectTrigger>
 <SelectContent>
 <SelectItem value="__none__">None</SelectItem>
 {nests.map((nest) => (
 <SelectItem key={nest.id} value={nest.id}>
 <span className="flex items-center gap-2">
 {nest.icon ? (
 <img
 src={nest.icon}
 alt=""
 className="h-4 w-4 rounded object-cover"
 />
 ) : (
 <span className="flex h-4 w-4 items-center justify-center rounded bg-surface-2 text-[9px] font-bold uppercase text-muted-foreground">
 {nest.name.slice(0, 2)}
 </span>
 )}
 {nest.name}
 </span>
 </SelectItem>
 ))}
 </SelectContent>
 </Select>
 {nests.length === 0 && (
 <p className="mt-1 text-[11px] text-muted-foreground/70">
 No nests available.{' '}
 <Link
 to="/admin/templates"
 onClick={(e) => {
 e.preventDefault();
 window.dispatchEvent(new CustomEvent('catalyst:open-nests-modal', { detail: { returnTo: 'template-edit' } }));
 }}
 className="inline-flex items-center gap-0.5 font-medium text-primary hover:text-primary"
 >
 Create one
 </Link>{' '}
 to group templates by category.
 </p>
 )}
 </label>
 <label className="block space-y-1">
 <span className="text-muted-foreground">
 Version
 </span>
 <input
 className="w-full rounded-lg border border-border/40 bg-card px-3 py-2 text-foreground transition-colors focus:border-primary focus:outline-none hover:border-primary"
 value={version}
 onChange={(event) => setVersion(event.target.value)}
 />
 </label>
 <label className="block space-y-1">
 <span className="text-muted-foreground">
 Icon URL (optional)
 </span>
 <input
 className="w-full rounded-lg border border-border/40 bg-card px-3 py-2 text-foreground transition-colors focus:border-primary focus:outline-none hover:border-primary"
 value={iconUrl}
 onChange={(event) => setIconUrl(event.target.value)}
 placeholder="https://example.com/icon.png"
 />
 </label>
 </div>
 <label className="block space-y-1">
 <span className="text-muted-foreground">
 Description
 </span>
 <textarea
 className="w-full rounded-lg border border-border/40 bg-card px-3 py-2 text-foreground transition-colors focus:border-primary focus:outline-none hover:border-primary"
 rows={2}
 value={description}
 onChange={(event) => setDescription(event.target.value)}
 />
 </label>
 <div className="space-y-3 rounded-2xl border border-border/30 bg-surface-2 p-4 transition-colors">
 <div className="text-sm font-semibold text-foreground">
 Runtime images
 </div>
 <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
 <label className="block space-y-1">
 <span className="text-muted-foreground">
 Container image
 </span>
 <input
 className="w-full rounded-lg border border-border/40 bg-card px-3 py-2 text-foreground transition-colors focus:border-primary focus:outline-none hover:border-primary"
 value={image}
 onChange={(event) => setImage(event.target.value)}
 />
 </label>
 <label className="block space-y-1">
 <span className="text-muted-foreground">
 Default image (optional)
 </span>
 <input
 className="w-full rounded-lg border border-border/40 bg-card px-3 py-2 text-foreground transition-colors focus:border-primary focus:outline-none hover:border-primary"
 value={defaultImage}
 onChange={(event) => setDefaultImage(event.target.value)}
 />
 </label>
 <label className="block space-y-1 md:col-span-2">
 <span className="text-muted-foreground">
 Install image (optional)
 </span>
 <input
 className="w-full rounded-lg border border-border/40 bg-card px-3 py-2 text-foreground transition-colors focus:border-primary focus:outline-none hover:border-primary"
 value={installImage}
 onChange={(event) => setInstallImage(event.target.value)}
 />
 </label>
 </div>
 <div className="space-y-3 rounded-lg border border-border/30 bg-card p-3 transition-colors">
 <div className="flex flex-wrap items-center justify-between gap-2">
 <div className="text-xs font-semibold text-muted-foreground">
 Image variants
 </div>
 <button
 className="rounded-full border border-border/40 px-3 py-1 text-xs font-semibold text-muted-foreground transition-colors hover:border-primary hover:text-foreground"
 onClick={() =>
 setImageOptions((prev) => [...prev, { name: '', label: '', image: '' }])
 }
 type="button"
 >
 Add image
 </button>
 </div>
 {imageOptions.length ? (
 <div className="space-y-2">
 {imageOptions.map((option, index) => (
 <div
 key={`${option.name}-${index}`}
 className="grid grid-cols-1 gap-2 md:grid-cols-[1fr_1fr_1fr_auto] md:items-end"
 >
 <label className="block space-y-1">
 <span className="text-xs text-muted-foreground">
 Name
 </span>
 <input
 className="w-full rounded-md border border-border/40 bg-card px-2 py-1.5 text-xs text-foreground transition-colors focus:border-primary focus:outline-none"
 value={option.name}
 onChange={(event) =>
 setImageOptions((prev) =>
 prev.map((item, itemIndex) =>
 itemIndex === index
 ? { ...item, name: event.target.value }
 : item,
 ),
 )
 }
 />
 </label>
 <label className="block space-y-1">
 <span className="text-xs text-muted-foreground">
 Label
 </span>
 <input
 className="w-full rounded-md border border-border/40 bg-card px-2 py-1.5 text-xs text-foreground transition-colors focus:border-primary focus:outline-none"
 value={option.label ?? ''}
 onChange={(event) =>
 setImageOptions((prev) =>
 prev.map((item, itemIndex) =>
 itemIndex === index
 ? { ...item, label: event.target.value }
 : item,
 ),
 )
 }
 />
 </label>
 <label className="block space-y-1">
 <span className="text-xs text-muted-foreground">
 Image
 </span>
 <input
 className="w-full rounded-md border border-border/40 bg-card px-2 py-1.5 text-xs text-foreground transition-colors focus:border-primary focus:outline-none"
 value={option.image}
 onChange={(event) =>
 setImageOptions((prev) =>
 prev.map((item, itemIndex) =>
 itemIndex === index
 ? { ...item, image: event.target.value }
 : item,
 ),
 )
 }
 />
 </label>
 <button
 className="rounded-full border border-destructive/20 px-2 py-1 text-xs font-semibold text-destructive transition-colors hover:border-destructive"
 onClick={() =>
 setImageOptions((prev) =>
 prev.filter((_, itemIndex) => itemIndex !== index),
 )
 }
 type="button"
 >
 Remove
 </button>
 </div>
 ))}
 </div>
 ) : (
 <p className="text-xs text-muted-foreground">
 Add optional image variants for selectable runtimes.
 </p>
 )}
 </div>
 </div>
 <div className="space-y-3 rounded-2xl border border-border/30 bg-surface-2 p-4 transition-colors">
 <div className="text-sm font-semibold text-foreground">
 Commands & config
 </div>
 <label className="block space-y-1">
 <span className="text-muted-foreground">
 Config file path (optional)
 </span>
 <input
 className="w-full rounded-lg border border-border/40 bg-card px-3 py-2 text-foreground transition-colors focus:border-primary focus:outline-none hover:border-primary"
 value={configFile}
 onChange={(event) => setConfigFile(event.target.value)}
 placeholder="/config/server.properties"
 />
 </label>
 <label className="block space-y-1">
 <span className="text-muted-foreground">
 Config files (optional)
 </span>
 <input
 className="w-full rounded-lg border border-border/40 bg-card px-3 py-2 text-foreground transition-colors focus:border-primary focus:outline-none hover:border-primary"
 value={configFiles.join(', ')}
 onChange={(event) => {
 const next = event.target.value
 .split(',')
 .map((entry) => entry.trim())
 .filter(Boolean);
 setConfigFiles(next);
 }}
 placeholder="/config/server.properties, /config/extra.yml"
 />
 </label>
 <label className="block space-y-1">
 <span className="text-muted-foreground">
 Startup command
 </span>
 <textarea
 className="w-full rounded-lg border border-border/40 bg-card px-3 py-2 text-foreground transition-colors focus:border-primary focus:outline-none hover:border-primary"
 rows={2}
 value={startup}
 onChange={(event) => setStartup(event.target.value)}
 />
 </label>
 <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
 <label className="block space-y-1 md:col-span-2">
 <span className="text-muted-foreground">
 Stop command
 </span>
 <input
 className="w-full rounded-lg border border-border/40 bg-card px-3 py-2 text-foreground transition-colors focus:border-primary focus:outline-none hover:border-primary"
 value={stopCommand}
 onChange={(event) => setStopCommand(event.target.value)}
 />
 </label>
 <label className="block space-y-1">
 <span className="text-muted-foreground">
 Signal
 </span>
 <select
 className="w-full rounded-lg border border-border/40 bg-card px-3 py-2 text-foreground transition-colors focus:border-primary focus:outline-none hover:border-primary"
 value={sendSignalTo}
 onChange={(event) =>
 setSendSignalTo(event.target.value as 'SIGTERM' | 'SIGINT' | 'SIGKILL')
 }
 >
 <option value="SIGTERM">SIGTERM</option>
 <option value="SIGINT">SIGINT</option>
 <option value="SIGKILL">SIGKILL</option>
 </select>
 </label>
 </div>
 <label className="block space-y-1">
 <span className="text-muted-foreground">
 Install script (optional)
 </span>
 <textarea
 className="w-full rounded-lg border border-border/40 bg-card px-3 py-2 text-foreground transition-colors focus:border-primary focus:outline-none hover:border-primary"
 rows={5}
 value={installScript}
 onChange={(event) => setInstallScript(event.target.value)}
 />
 </label>
 </div>
 <div className="space-y-3 rounded-2xl border border-border/30 bg-surface-2 p-4 transition-colors">
 <div className="text-sm font-semibold text-foreground">
 Resources & ports
 </div>
 <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
 <label className="block space-y-1">
 <span className="text-muted-foreground">
 Ports (comma separated)
 </span>
 <input
 className="w-full rounded-lg border border-border/40 bg-card px-3 py-2 text-foreground transition-colors focus:border-primary focus:outline-none hover:border-primary"
 value={supportedPorts}
 onChange={(event) => setSupportedPorts(event.target.value)}
 />
 </label>
 <label className="block space-y-1">
 <span className="text-muted-foreground">
 Allocated memory (MB)
 </span>
 <input
 className="w-full rounded-lg border border-border/40 bg-card px-3 py-2 text-foreground transition-colors focus:border-primary focus:outline-none hover:border-primary"
 type="number"
 min={128}
 value={allocatedMemoryMb}
 onChange={(event) => setAllocatedMemoryMb(event.target.value)}
 />
 </label>
 <label className="block space-y-1">
 <span className="text-muted-foreground">
 Allocated CPU cores
 </span>
 <input
 className="w-full rounded-lg border border-border/40 bg-card px-3 py-2 text-foreground transition-colors focus:border-primary focus:outline-none hover:border-primary"
 type="number"
 min={1}
 step={1}
 value={allocatedCpuCores}
 onChange={(event) => setAllocatedCpuCores(event.target.value)}
 />
 </label>
 </div>
 </div>
 <div className="space-y-3 rounded-2xl border border-border/30 bg-surface-2 p-4 transition-colors">
 <div className="flex flex-wrap items-center justify-between gap-2">
 <h3 className="text-sm font-semibold text-foreground">
 Variables
 </h3>
 <button
 className="rounded-full border border-border/40 px-3 py-1 text-xs font-semibold text-muted-foreground transition-colors hover:border-primary hover:text-foreground"
 onClick={() => setVariables((prev) => [...prev, createVariableDraft()])}
 type="button"
 >
 Add variable
 </button>
 </div>
 {variables.map((variable, index) => (
 <div
 key={`${variable.name}-${index}`}
 className="rounded-xl border border-border/30 bg-card p-3 transition-colors hover:border-primary"
 >
 <div className="flex items-center justify-between gap-2">
 <div className="text-xs font-semibold text-muted-foreground">
 Variable {index + 1}
 </div>
 {variables.length > 1 ? (
 <button
 className="text-xs text-destructive transition-colors hover:text-destructive"
 onClick={() =>
 setVariables((prev) =>
 prev.filter((_, itemIndex) => itemIndex !== index),
 )
 }
 type="button"
 >
 Remove
 </button>
 ) : null}
 </div>
 <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-2">
 <label className="block space-y-1">
 <span className="text-muted-foreground">
 Name
 </span>
 <input
 className="w-full rounded-md border border-border/40 bg-card px-2 py-1.5 text-xs text-foreground transition-colors focus:border-primary focus:outline-none hover:border-primary"
 value={variable.name}
 onChange={(event) =>
 setVariables((prev) =>
 prev.map((item, itemIndex) =>
 itemIndex === index
 ? { ...item, name: event.target.value }
 : item,
 ),
 )
 }
 />
 </label>
 <label className="block space-y-1">
 <span className="text-muted-foreground">
 Default
 </span>
 <input
 className="w-full rounded-md border border-border/40 bg-card px-2 py-1.5 text-xs text-foreground transition-colors focus:border-primary focus:outline-none hover:border-primary"
 value={variable.defaultValue}
 onChange={(event) =>
 setVariables((prev) =>
 prev.map((item, itemIndex) =>
 itemIndex === index
 ? { ...item, defaultValue: event.target.value }
 : item,
 ),
 )
 }
 />
 </label>
 <label className="block space-y-1 md:col-span-2">
 <span className="text-muted-foreground">
 Description
 </span>
 <input
 className="w-full rounded-md border border-border/40 bg-card px-2 py-1.5 text-xs text-foreground transition-colors focus:border-primary focus:outline-none hover:border-primary"
 value={variable.description}
 onChange={(event) =>
 setVariables((prev) =>
 prev.map((item, itemIndex) =>
 itemIndex === index
 ? { ...item, description: event.target.value }
 : item,
 ),
 )
 }
 />
 </label>
 <label className="flex items-center gap-2 text-xs text-muted-foreground">
 <input
 type="checkbox"
 className="rounded border-border bg-card text-primary focus:ring-primary"
 checked={variable.required}
 onChange={(event) =>
 setVariables((prev) =>
 prev.map((item, itemIndex) =>
 itemIndex === index
 ? { ...item, required: event.target.checked }
 : item,
 ),
 )
 }
 />
 Required
 </label>
 <label className="block space-y-1">
 <span className="text-muted-foreground">
 Input type
 </span>
 <select
 className="w-full rounded-md border border-border/40 bg-card px-2 py-1.5 text-xs text-foreground transition-colors focus:border-primary focus:outline-none hover:border-primary"
 value={variable.input}
 onChange={(event) =>
 setVariables((prev) =>
 prev.map((item, itemIndex) =>
 itemIndex === index
 ? {
 ...item,
 input: event.target.value as TemplateVariable['input'],
 }
 : item,
 ),
 )
 }
 >
 <option value="text">Text</option>
 <option value="number">Number</option>
 <option value="password">Password</option>
 <option value="select">Select</option>
 <option value="checkbox">Checkbox</option>
 <option value="textarea">Textarea</option>
 </select>
 </label>
 <label className="block space-y-1 md:col-span-2">
 <span className="text-muted-foreground">
 Rules (semicolon separated)
 </span>
 <input
 className="w-full rounded-md border border-border/40 bg-card px-2 py-1.5 text-xs text-foreground transition-colors focus:border-primary focus:outline-none hover:border-primary"
 value={variable.rules}
 onChange={(event) =>
 setVariables((prev) =>
 prev.map((item, itemIndex) =>
 itemIndex === index
 ? { ...item, rules: event.target.value }
 : item,
 ),
 )
 }
 placeholder="between:512,16384; in:val1,val2"
 />
 </label>
 </div>
 </div>
 ))}
 </div>
 <div className="space-y-3 rounded-2xl border border-border/30 bg-surface-2 p-4 transition-colors">
 <div className="text-sm font-semibold text-foreground">
 Advanced features
 </div>
 <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
 <label className="flex items-center gap-2 text-xs text-muted-foreground">
 <input
 type="checkbox"
 className="rounded border-border bg-card text-primary focus:ring-primary"
 checked={restartOnExit}
 onChange={(event) => setRestartOnExit(event.target.checked)}
 />
 Restart on exit
 </label>
 <label className="block space-y-1">
 <span className="text-muted-foreground">
 Max instances (optional)
 </span>
 <input
 className="w-full rounded-lg border border-border/40 bg-card px-3 py-2 text-foreground transition-colors focus:border-primary focus:outline-none hover:border-primary"
 type="number"
 min={1}
 value={maxInstances}
 onChange={(event) => setMaxInstances(event.target.value)}
 placeholder="Unlimited"
 />
 </label>
 <label className="flex items-center gap-2 text-xs text-muted-foreground">
 <input
 type="checkbox"
 className="rounded border-border bg-card text-primary focus:ring-primary"
 checked={fileEditorEnabled}
 onChange={(event) => setFileEditorEnabled(event.target.checked)}
 />
 Enable file editor
 </label>
 <label className="block space-y-1">
 <span className="text-muted-foreground">
 File editor restricted paths (optional)
 </span>
 <input
 className="w-full rounded-lg border border-border/40 bg-card px-3 py-2 text-foreground transition-colors focus:border-primary focus:outline-none hover:border-primary"
 value={fileEditorRestrictedPaths}
 onChange={(event) => setFileEditorRestrictedPaths(event.target.value)}
 placeholder="/sensitive, /config"
 />
 </label>
 </div>
 <label className="block space-y-1">
 <span className="text-muted-foreground">
 Backup paths (optional)
 </span>
 <input
 className="w-full rounded-lg border border-border/40 bg-card px-3 py-2 text-foreground transition-colors focus:border-primary focus:outline-none hover:border-primary"
 value={backupPaths}
 onChange={(event) => setBackupPaths(event.target.value)}
 placeholder="/world, /plugins, /config"
 />
 </label>
 </div>
 <TemplateProviderEditor
 modManagerEnabled={modManagerEnabled}
 onModManagerEnabledChange={setModManagerEnabled}
 modProviders={modProviders}
 onModProvidersChange={setModProviders}
 pluginManagerEnabled={pluginManagerEnabled}
 onPluginManagerEnabledChange={setPluginManagerEnabled}
 pluginProviders={pluginProviders}
 onPluginProvidersChange={setPluginProviders}
 />
 </div>
 <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border px-6 py-4 text-xs">
 <div className="space-y-1">
 {missingFields.length > 0 ? (
 <div className="text-xs">
 <span className="text-muted-foreground">
 Missing required fields:{' '}
 </span>
 <span className="text-warning font-medium">
 {missingFields.join(', ')}
 </span>
 </div>
 ) : (
 <span className="text-xs text-muted-foreground">
 Changes apply immediately after save.
 </span>
 )}
 </div>
 <div className="flex gap-2">
 <button
 className="rounded-full border border-border/40 px-4 py-2 font-semibold text-muted-foreground transition-colors hover:border-primary hover:text-foreground"
 onClick={() => setOpen(false)}
 >
 Cancel
 </button>
 <button
 className="rounded-full bg-primary px-4 py-2 font-semibold text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-60"
 onClick={() => mutation.mutate()}
 disabled={disableSubmit}
 >
 {mutation.isPending ? 'Saving...' : 'Save changes'}
 </button>
 </div>
 </div>
 </div>
 </div>
 </ModalPortal>
 ) : null}
 </>
 );
}

export default TemplateEditModal;