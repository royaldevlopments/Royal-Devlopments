<?php

namespace App\Traits;

use App\Models\Coupon as CouponModel;
use App\Models\ShopProduct;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use stdClass;

trait Coupon
{
    public function validateCoupon($requestUser, $couponCode, $productId): JsonResponse
    {
        $coupon = CouponModel::where('code', $couponCode)->first();
        $shopProduct = ShopProduct::findOrFail($productId);
        $response = response()->json([
            'isValid' => false,
            'error' => __('This coupon does not exist.')
        ], 404);

        if (!is_null($coupon)) {
            $status = $coupon->getStatus();
            if ($status == 'USES_LIMIT_REACHED' || $status == 'PENDING_LIMIT_REACHED') {
                $response = response()->json([
                    'isValid' => false,
                    'error' => __('This coupon has reached the maximum amount of uses.')
                ], 422);

                return $response;
            }

            if ($status == 'EXPIRED') {
                $response = response()->json([
                    'isValid' => false,
                    'error' => __('This coupon has expired.')
                ], 422);

                return $response;
            }

            if ($coupon->isMaxUsesReached($requestUser)) {
                $response = response()->json([
                    'isValid' => false,
                    'error' => __('You have reached the maximum uses of this coupon.')
                ], 422);

                return $response;
            }

            if ($coupon->min_product_price > 0 && $shopProduct->getTotalPrice() < $coupon->min_product_price) {
                $response = response()->json([
                    'isValid' => false,
                    'error' => __('The product price is too low to use this coupon.')
                ], 422);

                return $response;
            }

            $response = response()->json([
                'isValid' => true,
                'couponCode' => $coupon->code,
                'couponType' => $coupon->type,
                'couponValue' => $coupon->value
            ]);
        }

        return $response;
    }

    public function isCouponValid(string $couponCode, User $user, string $productId): bool
    {
        if (is_null($couponCode)) return false;

        $coupon = CouponModel::where('code', $couponCode)->firstOrFail();
        $shopProduct = ShopProduct::findOrFail($productId);
        $status = $coupon->getStatus();

        if ($status == 'USES_LIMIT_REACHED' || $status == 'PENDING_LIMIT_REACHED') {
            return false;
        }

        if ($status == 'EXPIRED') {
            return false;
        }

        if ($coupon->isMaxUsesReached($user)) {
            return false;
        }

        if ($coupon->min_product_price > 0 && $shopProduct->getTotalPrice() < $coupon->min_product_price) {
            return false;
        }

        return true;
    }

    public function applyCoupon(string $couponCode, int $price)
    {
        $coupon = CouponModel::where('code', $couponCode)->first();

        if ($coupon->type === 'percentage') {
            return $price - ($price * $coupon->value / 100);
        }

        if ($coupon->type === 'amount') {
            return max(0, $price - $coupon->value);
        }

        return $price - $coupon->value;
    }
}
