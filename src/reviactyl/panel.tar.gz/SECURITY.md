# Security Policy

## Supported Versions

The following versions of Reviactyl are receiving active support and maintenance. Any security vulnerabilities discovered must be reproducible in supported versions.

| Panel  | Agent       | Supported          |
|--------|--------------|--------------------|
| 2.2.x | wings@1.12.x | 🟨 |
| 26.x  | agent@26.x | ✅ |



## Reporting a Vulnerability

Please reach out directly to any project team member on Discord when reporting a security vulnerability, or you can email security@reviactyl.dev.

We make every effort to respond as soon as possible, although it may take a day or two for us to sync internally and determine the severity of the report and its impact. Please, _do not_ use a public facing channel or GitHub issues to report sensitive security issues.

As part of our process, we will create a security advisory for the affected versions and disclose it publicly, usually two to four weeks after a releasing a version that addresses it.
