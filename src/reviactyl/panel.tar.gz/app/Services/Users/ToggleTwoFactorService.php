<?php

namespace App\Services\Users;

use App\Contracts\Repository\UserRepositoryInterface;
use App\Exceptions\Service\User\TwoFactorAuthenticationTokenInvalid;
use App\Models\User;
use App\Repositories\Eloquent\RecoveryTokenRepository;
use Carbon\Carbon;
use Illuminate\Contracts\Encryption\Encrypter;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use PragmaRX\Google2FA\Exceptions\IncompatibleWithGoogleAuthenticatorException;
use PragmaRX\Google2FA\Exceptions\InvalidCharactersException;
use PragmaRX\Google2FA\Exceptions\SecretKeyTooShortException;
use PragmaRX\Google2FA\Google2FA;

class ToggleTwoFactorService
{
    /**
     * ToggleTwoFactorService constructor.
     */
    public function __construct(
        private ConnectionInterface $connection,
        private Encrypter $encrypter,
        private Google2FA $google2FA,
        private RecoveryTokenRepository $recoveryTokenRepository,
        private UserRepositoryInterface $repository,
    ) {}

    /**
     * Toggle 2FA on an account only if the token provided is valid.
     *
     * @throws \Throwable
     * @throws IncompatibleWithGoogleAuthenticatorException
     * @throws InvalidCharactersException
     * @throws SecretKeyTooShortException
     * @throws TwoFactorAuthenticationTokenInvalid
     */
    public function handle(User $user, string $token, ?bool $toggleState = null): array
    {
        $secret = $this->encrypter->decrypt($user->totp_secret);

        $isValidToken = $this->google2FA->verifyKey($secret, $token, config()->get('panel.auth.2fa.window'));

        if (! $isValidToken) {
            throw new TwoFactorAuthenticationTokenInvalid();
        }

        return $this->connection->transaction(function () use ($user, $toggleState) {
            // Now that we're enabling 2FA on the account, generate 10 recovery tokens for the account
            // and store them hashed in the database. We'll return them to the caller so that the user
            // can see and save them.
            //
            // If a user is unable to login with a 2FA token they can provide one of these backup codes
            // which will then be marked as deleted from the database and will also bypass 2FA protections
            // on their account.
            $tokens = [];
            if ((! $toggleState && ! $user->use_totp) || $toggleState) {
                $inserts = [];
                for ($i = 0; $i < 10; $i++) {
                    $token = Str::random(10);

                    $inserts[] = [
                        'user_id' => $user->id,
                        'token' => Hash::make($token),
                        // insert() won't actually set the time on the models, so make sure we do this
                        // manually here.
                        'created_at' => Carbon::now(),
                    ];

                    $tokens[] = $token;
                }

                // Before inserting any new records make sure all of the old ones are deleted to avoid
                // any issues or storing an unnecessary number of tokens in the database.
                $this->recoveryTokenRepository->deleteWhere(['user_id' => $user->id]);

                // Bulk insert the hashed tokens.
                $this->recoveryTokenRepository->insert($inserts);
            }

            $this->repository->withoutFreshModel()->update($user->id, [
                'totp_authenticated_at' => null,
                'use_totp' => (is_null($toggleState) ? ! $user->use_totp : $toggleState),
            ]);

            return $tokens;
        });
    }
}
